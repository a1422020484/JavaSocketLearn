/*   1:    */ package proto;
/*   2:    */ 
/*   3:    */ import com.google.protobuf.AbstractParser;
/*   4:    */ import com.google.protobuf.ByteString;
/*   5:    */ import com.google.protobuf.CodedInputStream;
/*   6:    */ import com.google.protobuf.CodedOutputStream;
/*   7:    */ import com.google.protobuf.Descriptors.Descriptor;
/*   8:    */ import com.google.protobuf.Descriptors.FileDescriptor;
/*   9:    */ import com.google.protobuf.Descriptors.FileDescriptor.InternalDescriptorAssigner;
/*  10:    */ import com.google.protobuf.ExtensionRegistry;
/*  11:    */ import com.google.protobuf.ExtensionRegistryLite;
/*  12:    */ import com.google.protobuf.GeneratedMessage;
/*  13:    */ import com.google.protobuf.GeneratedMessage.Builder;
/*  14:    */ import com.google.protobuf.GeneratedMessage.BuilderParent;
/*  15:    */ import com.google.protobuf.GeneratedMessage.FieldAccessorTable;
/*  16:    */ import com.google.protobuf.InvalidProtocolBufferException;
/*  17:    */ import com.google.protobuf.Message;
/*  18:    */ import com.google.protobuf.MessageOrBuilder;
/*  19:    */ import com.google.protobuf.Parser;
/*  20:    */ import com.google.protobuf.UnknownFieldSet;
/*  21:    */ import com.google.protobuf.UnknownFieldSet.Builder;
/*  22:    */ import java.io.IOException;
/*  23:    */ import java.io.InputStream;
/*  24:    */ import java.io.ObjectStreamException;
/*  25:    */ import java.util.List;
/*  26:    */ 
/*  27:    */ public final class ProtocolWeb
/*  28:    */ {
/*  29:    */   public static void registerAllExtensions(ExtensionRegistry registry) {}
/*  30:    */   
/*  31:    */   public static final class ReadPlayerInfoWCS
/*  32:    */     extends GeneratedMessage
/*  33:    */     implements ProtocolWeb.ReadPlayerInfoWCSOrBuilder
/*  34:    */   {
/*  35:    */     private static final ReadPlayerInfoWCS defaultInstance;
/*  36:    */     private final UnknownFieldSet unknownFields;
/*  37:    */     
/*  38:    */     private ReadPlayerInfoWCS(GeneratedMessage.Builder<?> builder)
/*  39:    */     {
/*  40: 54 */       super();
/*  41: 55 */       this.unknownFields = builder.getUnknownFields();
/*  42:    */     }
/*  43:    */     
/*  44:    */     private ReadPlayerInfoWCS(boolean noInit)
/*  45:    */     {
/*  46: 57 */       this.unknownFields = UnknownFieldSet.getDefaultInstance();
/*  47:    */     }
/*  48:    */     
/*  49:    */     public static ReadPlayerInfoWCS getDefaultInstance()
/*  50:    */     {
/*  51: 61 */       return defaultInstance;
/*  52:    */     }
/*  53:    */     
/*  54:    */     public ReadPlayerInfoWCS getDefaultInstanceForType()
/*  55:    */     {
/*  56: 65 */       return defaultInstance;
/*  57:    */     }
/*  58:    */     
/*  59:    */     public final UnknownFieldSet getUnknownFields()
/*  60:    */     {
/*  61: 72 */       return this.unknownFields;
/*  62:    */     }
/*  63:    */     
/*  64:    */     private ReadPlayerInfoWCS(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/*  65:    */       throws InvalidProtocolBufferException
/*  66:    */     {
/*  67: 78 */       initFields();
/*  68: 79 */       int mutable_bitField0_ = 0;
/*  69:    */       
/*  70: 81 */       UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
/*  71:    */       try
/*  72:    */       {
/*  73: 83 */         boolean done = false;
/*  74: 84 */         while (!done)
/*  75:    */         {
/*  76: 85 */           int tag = input.readTag();
/*  77: 86 */           switch (tag)
/*  78:    */           {
/*  79:    */           case 0: 
/*  80: 88 */             done = true;
/*  81: 89 */             break;
/*  82:    */           default: 
/*  83: 91 */             if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
/*  84: 93 */               done = true;
/*  85:    */             }
/*  86:    */             break;
/*  87:    */           case 10: 
/*  88: 98 */             ByteString bs = input.readBytes();
/*  89: 99 */             this.bitField0_ |= 0x1;
/*  90:100 */             this.playerText_ = bs;
/*  91:    */           }
/*  92:    */         }
/*  93:    */       }
/*  94:    */       catch (InvalidProtocolBufferException e)
/*  95:    */       {
/*  96:106 */         throw e.setUnfinishedMessage(this);
/*  97:    */       }
/*  98:    */       catch (IOException e)
/*  99:    */       {
/* 100:109 */         throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
/* 101:    */       }
/* 102:    */       finally
/* 103:    */       {
/* 104:111 */         this.unknownFields = unknownFields.build();
/* 105:112 */         makeExtensionsImmutable();
/* 106:    */       }
/* 107:    */     }
/* 108:    */     
/* 109:    */     public static final Descriptors.Descriptor getDescriptor()
/* 110:    */     {
/* 111:117 */       return ProtocolWeb.internal_static_protocol_ReadPlayerInfoWCS_descriptor;
/* 112:    */     }
/* 113:    */     
/* 114:    */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/* 115:    */     {
/* 116:123 */       return ProtocolWeb.internal_static_protocol_ReadPlayerInfoWCS_fieldAccessorTable.ensureFieldAccessorsInitialized(ReadPlayerInfoWCS.class, Builder.class);
/* 117:    */     }
/* 118:    */     
/* 119:127 */     public static Parser<ReadPlayerInfoWCS> PARSER = new AbstractParser()
/* 120:    */     {
/* 121:    */       public ProtocolWeb.ReadPlayerInfoWCS parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/* 122:    */         throws InvalidProtocolBufferException
/* 123:    */       {
/* 124:133 */         return new ProtocolWeb.ReadPlayerInfoWCS(input, extensionRegistry, null);
/* 125:    */       }
/* 126:    */     };
/* 127:    */     private int bitField0_;
/* 128:    */     public static final int PLAYERTEXT_FIELD_NUMBER = 1;
/* 129:    */     private Object playerText_;
/* 130:    */     
/* 131:    */     public Parser<ReadPlayerInfoWCS> getParserForType()
/* 132:    */     {
/* 133:139 */       return PARSER;
/* 134:    */     }
/* 135:    */     
/* 136:    */     public boolean hasPlayerText()
/* 137:    */     {
/* 138:153 */       return (this.bitField0_ & 0x1) == 1;
/* 139:    */     }
/* 140:    */     
/* 141:    */     public String getPlayerText()
/* 142:    */     {
/* 143:163 */       Object ref = this.playerText_;
/* 144:164 */       if ((ref instanceof String)) {
/* 145:165 */         return (String)ref;
/* 146:    */       }
/* 147:167 */       ByteString bs = (ByteString)ref;
/* 148:    */       
/* 149:169 */       String s = bs.toStringUtf8();
/* 150:170 */       if (bs.isValidUtf8()) {
/* 151:171 */         this.playerText_ = s;
/* 152:    */       }
/* 153:173 */       return s;
/* 154:    */     }
/* 155:    */     
/* 156:    */     public ByteString getPlayerTextBytes()
/* 157:    */     {
/* 158:185 */       Object ref = this.playerText_;
/* 159:186 */       if ((ref instanceof String))
/* 160:    */       {
/* 161:188 */         ByteString b = ByteString.copyFromUtf8((String)ref);
/* 162:    */         
/* 163:190 */         this.playerText_ = b;
/* 164:191 */         return b;
/* 165:    */       }
/* 166:193 */       return (ByteString)ref;
/* 167:    */     }
/* 168:    */     
/* 169:    */     private void initFields()
/* 170:    */     {
/* 171:198 */       this.playerText_ = "";
/* 172:    */     }
/* 173:    */     
/* 174:200 */     private byte memoizedIsInitialized = -1;
/* 175:    */     
/* 176:    */     public final boolean isInitialized()
/* 177:    */     {
/* 178:202 */       byte isInitialized = this.memoizedIsInitialized;
/* 179:203 */       if (isInitialized == 1) {
/* 180:203 */         return true;
/* 181:    */       }
/* 182:204 */       if (isInitialized == 0) {
/* 183:204 */         return false;
/* 184:    */       }
/* 185:206 */       if (!hasPlayerText())
/* 186:    */       {
/* 187:207 */         this.memoizedIsInitialized = 0;
/* 188:208 */         return false;
/* 189:    */       }
/* 190:210 */       this.memoizedIsInitialized = 1;
/* 191:211 */       return true;
/* 192:    */     }
/* 193:    */     
/* 194:    */     public void writeTo(CodedOutputStream output)
/* 195:    */       throws IOException
/* 196:    */     {
/* 197:216 */       getSerializedSize();
/* 198:217 */       if ((this.bitField0_ & 0x1) == 1) {
/* 199:218 */         output.writeBytes(1, getPlayerTextBytes());
/* 200:    */       }
/* 201:220 */       getUnknownFields().writeTo(output);
/* 202:    */     }
/* 203:    */     
/* 204:223 */     private int memoizedSerializedSize = -1;
/* 205:    */     private static final long serialVersionUID = 0L;
/* 206:    */     
/* 207:    */     public int getSerializedSize()
/* 208:    */     {
/* 209:225 */       int size = this.memoizedSerializedSize;
/* 210:226 */       if (size != -1) {
/* 211:226 */         return size;
/* 212:    */       }
/* 213:228 */       size = 0;
/* 214:229 */       if ((this.bitField0_ & 0x1) == 1) {
/* 215:231 */         size = size + CodedOutputStream.computeBytesSize(1, getPlayerTextBytes());
/* 216:    */       }
/* 217:233 */       size += getUnknownFields().getSerializedSize();
/* 218:234 */       this.memoizedSerializedSize = size;
/* 219:235 */       return size;
/* 220:    */     }
/* 221:    */     
/* 222:    */     protected Object writeReplace()
/* 223:    */       throws ObjectStreamException
/* 224:    */     {
/* 225:242 */       return super.writeReplace();
/* 226:    */     }
/* 227:    */     
/* 228:    */     public static ReadPlayerInfoWCS parseFrom(ByteString data)
/* 229:    */       throws InvalidProtocolBufferException
/* 230:    */     {
/* 231:248 */       return (ReadPlayerInfoWCS)PARSER.parseFrom(data);
/* 232:    */     }
/* 233:    */     
/* 234:    */     public static ReadPlayerInfoWCS parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
/* 235:    */       throws InvalidProtocolBufferException
/* 236:    */     {
/* 237:254 */       return (ReadPlayerInfoWCS)PARSER.parseFrom(data, extensionRegistry);
/* 238:    */     }
/* 239:    */     
/* 240:    */     public static ReadPlayerInfoWCS parseFrom(byte[] data)
/* 241:    */       throws InvalidProtocolBufferException
/* 242:    */     {
/* 243:258 */       return (ReadPlayerInfoWCS)PARSER.parseFrom(data);
/* 244:    */     }
/* 245:    */     
/* 246:    */     public static ReadPlayerInfoWCS parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
/* 247:    */       throws InvalidProtocolBufferException
/* 248:    */     {
/* 249:264 */       return (ReadPlayerInfoWCS)PARSER.parseFrom(data, extensionRegistry);
/* 250:    */     }
/* 251:    */     
/* 252:    */     public static ReadPlayerInfoWCS parseFrom(InputStream input)
/* 253:    */       throws IOException
/* 254:    */     {
/* 255:268 */       return (ReadPlayerInfoWCS)PARSER.parseFrom(input);
/* 256:    */     }
/* 257:    */     
/* 258:    */     public static ReadPlayerInfoWCS parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/* 259:    */       throws IOException
/* 260:    */     {
/* 261:274 */       return (ReadPlayerInfoWCS)PARSER.parseFrom(input, extensionRegistry);
/* 262:    */     }
/* 263:    */     
/* 264:    */     public static ReadPlayerInfoWCS parseDelimitedFrom(InputStream input)
/* 265:    */       throws IOException
/* 266:    */     {
/* 267:278 */       return (ReadPlayerInfoWCS)PARSER.parseDelimitedFrom(input);
/* 268:    */     }
/* 269:    */     
/* 270:    */     public static ReadPlayerInfoWCS parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
/* 271:    */       throws IOException
/* 272:    */     {
/* 273:284 */       return (ReadPlayerInfoWCS)PARSER.parseDelimitedFrom(input, extensionRegistry);
/* 274:    */     }
/* 275:    */     
/* 276:    */     public static ReadPlayerInfoWCS parseFrom(CodedInputStream input)
/* 277:    */       throws IOException
/* 278:    */     {
/* 279:289 */       return (ReadPlayerInfoWCS)PARSER.parseFrom(input);
/* 280:    */     }
/* 281:    */     
/* 282:    */     public static ReadPlayerInfoWCS parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/* 283:    */       throws IOException
/* 284:    */     {
/* 285:295 */       return (ReadPlayerInfoWCS)PARSER.parseFrom(input, extensionRegistry);
/* 286:    */     }
/* 287:    */     
/* 288:    */     public static Builder newBuilder()
/* 289:    */     {
/* 290:298 */       return Builder.access$300();
/* 291:    */     }
/* 292:    */     
/* 293:    */     public Builder newBuilderForType()
/* 294:    */     {
/* 295:299 */       return newBuilder();
/* 296:    */     }
/* 297:    */     
/* 298:    */     public static Builder newBuilder(ReadPlayerInfoWCS prototype)
/* 299:    */     {
/* 300:301 */       return newBuilder().mergeFrom(prototype);
/* 301:    */     }
/* 302:    */     
/* 303:    */     public Builder toBuilder()
/* 304:    */     {
/* 305:303 */       return newBuilder(this);
/* 306:    */     }
/* 307:    */     
/* 308:    */     protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
/* 309:    */     {
/* 310:308 */       Builder builder = new Builder(parent, null);
/* 311:309 */       return builder;
/* 312:    */     }
/* 313:    */     
/* 314:    */     public static final class Builder
/* 315:    */       extends GeneratedMessage.Builder<Builder>
/* 316:    */       implements ProtocolWeb.ReadPlayerInfoWCSOrBuilder
/* 317:    */     {
/* 318:    */       private int bitField0_;
/* 319:    */       
/* 320:    */       public static final Descriptors.Descriptor getDescriptor()
/* 321:    */       {
/* 322:324 */         return ProtocolWeb.internal_static_protocol_ReadPlayerInfoWCS_descriptor;
/* 323:    */       }
/* 324:    */       
/* 325:    */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
/* 326:    */       {
/* 327:330 */         return ProtocolWeb.internal_static_protocol_ReadPlayerInfoWCS_fieldAccessorTable.ensureFieldAccessorsInitialized(ProtocolWeb.ReadPlayerInfoWCS.class, Builder.class);
/* 328:    */       }
/* 329:    */       
/* 330:    */       private Builder()
/* 331:    */       {
/* 332:336 */         maybeForceBuilderInitialization();
/* 333:    */       }
/* 334:    */       
/* 335:    */       private Builder(GeneratedMessage.BuilderParent parent)
/* 336:    */       {
/* 337:341 */         super();
/* 338:342 */         maybeForceBuilderInitialization();
/* 339:    */       }
/* 340:    */       
/* 341:    */       private void maybeForceBuilderInitialization()
/* 342:    */       {
/* 343:345 */         if (ProtocolWeb.ReadPlayerInfoWCS.alwaysUseFieldBuilders) {}
/* 344:    */       }
/* 345:    */       
/* 346:    */       private static Builder create()
/* 347:    */       {
/* 348:349 */         return new Builder();
/* 349:    */       }
/* 350:    */       
/* 351:    */       public Builder clear()
/* 352:    */       {
/* 353:353 */         super.clear();
/* 354:354 */         this.playerText_ = "";
/* 355:355 */         this.bitField0_ &= 0xFFFFFFFE;
/* 356:356 */         return this;
/* 357:    */       }
/* 358:    */       
/* 359:    */       public Builder clone()
/* 360:    */       {
/* 361:360 */         return create().mergeFrom(buildPartial());
/* 362:    */       }
/* 363:    */       
/* 364:    */       public Descriptors.Descriptor getDescriptorForType()
/* 365:    */       {
/* 366:365 */         return ProtocolWeb.internal_static_protocol_ReadPlayerInfoWCS_descriptor;
/* 367:    */       }
/* 368:    */       
/* 369:    */       public ProtocolWeb.ReadPlayerInfoWCS getDefaultInstanceForType()
/* 370:    */       {
/* 371:369 */         return ProtocolWeb.ReadPlayerInfoWCS.getDefaultInstance();
/* 372:    */       }
/* 373:    */       
/* 374:    */       public ProtocolWeb.ReadPlayerInfoWCS build()
/* 375:    */       {
/* 376:373 */         ProtocolWeb.ReadPlayerInfoWCS result = buildPartial();
/* 377:374 */         if (!result.isInitialized()) {
/* 378:375 */           throw newUninitializedMessageException(result);
/* 379:    */         }
/* 380:377 */         return result;
/* 381:    */       }
/* 382:    */       
/* 383:    */       public ProtocolWeb.ReadPlayerInfoWCS buildPartial()
/* 384:    */       {
/* 385:381 */         ProtocolWeb.ReadPlayerInfoWCS result = new ProtocolWeb.ReadPlayerInfoWCS(this, null);
/* 386:382 */         int from_bitField0_ = this.bitField0_;
/* 387:383 */         int to_bitField0_ = 0;
/* 388:384 */         if ((from_bitField0_ & 0x1) == 1) {
/* 389:385 */           to_bitField0_ |= 0x1;
/* 390:    */         }
/* 391:387 */         result.playerText_ = this.playerText_;
/* 392:388 */         result.bitField0_ = to_bitField0_;
/* 393:389 */         onBuilt();
/* 394:390 */         return result;
/* 395:    */       }
/* 396:    */       
/* 397:    */       public Builder mergeFrom(Message other)
/* 398:    */       {
/* 399:394 */         if ((other instanceof ProtocolWeb.ReadPlayerInfoWCS)) {
/* 400:395 */           return mergeFrom((ProtocolWeb.ReadPlayerInfoWCS)other);
/* 401:    */         }
/* 402:397 */         super.mergeFrom(other);
/* 403:398 */         return this;
/* 404:    */       }
/* 405:    */       
/* 406:    */       public Builder mergeFrom(ProtocolWeb.ReadPlayerInfoWCS other)
/* 407:    */       {
/* 408:403 */         if (other == ProtocolWeb.ReadPlayerInfoWCS.getDefaultInstance()) {
/* 409:403 */           return this;
/* 410:    */         }
/* 411:404 */         if (other.hasPlayerText())
/* 412:    */         {
/* 413:405 */           this.bitField0_ |= 0x1;
/* 414:406 */           this.playerText_ = other.playerText_;
/* 415:407 */           onChanged();
/* 416:    */         }
/* 417:409 */         mergeUnknownFields(other.getUnknownFields());
/* 418:410 */         return this;
/* 419:    */       }
/* 420:    */       
/* 421:    */       public final boolean isInitialized()
/* 422:    */       {
/* 423:414 */         if (!hasPlayerText()) {
/* 424:416 */           return false;
/* 425:    */         }
/* 426:418 */         return true;
/* 427:    */       }
/* 428:    */       
/* 429:    */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
/* 430:    */         throws IOException
/* 431:    */       {
/* 432:425 */         ProtocolWeb.ReadPlayerInfoWCS parsedMessage = null;
/* 433:    */         try
/* 434:    */         {
/* 435:427 */           parsedMessage = (ProtocolWeb.ReadPlayerInfoWCS)ProtocolWeb.ReadPlayerInfoWCS.PARSER.parsePartialFrom(input, extensionRegistry);
/* 436:    */         }
/* 437:    */         catch (InvalidProtocolBufferException e)
/* 438:    */         {
/* 439:429 */           parsedMessage = (ProtocolWeb.ReadPlayerInfoWCS)e.getUnfinishedMessage();
/* 440:430 */           throw e;
/* 441:    */         }
/* 442:    */         finally
/* 443:    */         {
/* 444:432 */           if (parsedMessage != null) {
/* 445:433 */             mergeFrom(parsedMessage);
/* 446:    */           }
/* 447:    */         }
/* 448:436 */         return this;
/* 449:    */       }
/* 450:    */       
/* 451:440 */       private Object playerText_ = "";
/* 452:    */       
/* 453:    */       public boolean hasPlayerText()
/* 454:    */       {
/* 455:449 */         return (this.bitField0_ & 0x1) == 1;
/* 456:    */       }
/* 457:    */       
/* 458:    */       public String getPlayerText()
/* 459:    */       {
/* 460:459 */         Object ref = this.playerText_;
/* 461:460 */         if (!(ref instanceof String))
/* 462:    */         {
/* 463:461 */           ByteString bs = (ByteString)ref;
/* 464:    */           
/* 465:463 */           String s = bs.toStringUtf8();
/* 466:464 */           if (bs.isValidUtf8()) {
/* 467:465 */             this.playerText_ = s;
/* 468:    */           }
/* 469:467 */           return s;
/* 470:    */         }
/* 471:469 */         return (String)ref;
/* 472:    */       }
/* 473:    */       
/* 474:    */       public ByteString getPlayerTextBytes()
/* 475:    */       {
/* 476:481 */         Object ref = this.playerText_;
/* 477:482 */         if ((ref instanceof String))
/* 478:    */         {
/* 479:484 */           ByteString b = ByteString.copyFromUtf8((String)ref);
/* 480:    */           
/* 481:486 */           this.playerText_ = b;
/* 482:487 */           return b;
/* 483:    */         }
/* 484:489 */         return (ByteString)ref;
/* 485:    */       }
/* 486:    */       
/* 487:    */       public Builder setPlayerText(String value)
/* 488:    */       {
/* 489:501 */         if (value == null) {
/* 490:502 */           throw new NullPointerException();
/* 491:    */         }
/* 492:504 */         this.bitField0_ |= 0x1;
/* 493:505 */         this.playerText_ = value;
/* 494:506 */         onChanged();
/* 495:507 */         return this;
/* 496:    */       }
/* 497:    */       
/* 498:    */       public Builder clearPlayerText()
/* 499:    */       {
/* 500:517 */         this.bitField0_ &= 0xFFFFFFFE;
/* 501:518 */         this.playerText_ = ProtocolWeb.ReadPlayerInfoWCS.getDefaultInstance().getPlayerText();
/* 502:519 */         onChanged();
/* 503:520 */         return this;
/* 504:    */       }
/* 505:    */       
/* 506:    */       public Builder setPlayerTextBytes(ByteString value)
/* 507:    */       {
/* 508:531 */         if (value == null) {
/* 509:532 */           throw new NullPointerException();
/* 510:    */         }
/* 511:534 */         this.bitField0_ |= 0x1;
/* 512:535 */         this.playerText_ = value;
/* 513:536 */         onChanged();
/* 514:537 */         return this;
/* 515:    */       }
/* 516:    */     }
/* 517:    */     
/* 518:    */     static
/* 519:    */     {
/* 520:544 */       defaultInstance = new ReadPlayerInfoWCS(true);
/* 521:545 */       defaultInstance.initFields();
/* 522:    */     }
/* 523:    */   }
/* 524:    */   
/* 525:    */   public static Descriptors.FileDescriptor getDescriptor()
/* 526:    */   {
/* 527:559 */     return descriptor;
/* 528:    */   }
/* 529:    */   
/* 530:    */   static
/* 531:    */   {
/* 532:564 */     String[] descriptorData = { "\n\022protocolWeb2.proto\022\bprotocol\"'\n\021ReadPlayerInfoWCS\022\022\n\nplayerText\030\001 \002(\tB\024\n\005protoB\013ProtocolWeb" };
/* 533:    */     
/* 534:    */ 
/* 535:    */ 
/* 536:    */ 
/* 537:569 */     Descriptors.FileDescriptor.InternalDescriptorAssigner assigner = new Descriptors.FileDescriptor.InternalDescriptorAssigner()
/* 538:    */     {
/* 539:    */       public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor root)
/* 540:    */       {
/* 541:573 */         ProtocolWeb.access$902(root);
/* 542:574 */         return null;
/* 543:    */       }
/* 544:577 */     };
/* 545:578 */     Descriptors.FileDescriptor.internalBuildGeneratedFileFrom(descriptorData, new Descriptors.FileDescriptor[0], assigner);
/* 546:    */   }
/* 547:    */   
/* 548:582 */   private static final Descriptors.Descriptor internal_static_protocol_ReadPlayerInfoWCS_descriptor = (Descriptors.Descriptor)getDescriptor().getMessageTypes().get(0);
/* 549:583 */   private static GeneratedMessage.FieldAccessorTable internal_static_protocol_ReadPlayerInfoWCS_fieldAccessorTable = new GeneratedMessage.FieldAccessorTable(internal_static_protocol_ReadPlayerInfoWCS_descriptor, new String[] { "PlayerText" });
/* 550:    */   private static Descriptors.FileDescriptor descriptor;
/* 551:    */   
/* 552:    */   public static abstract interface ReadPlayerInfoWCSOrBuilder
/* 553:    */     extends MessageOrBuilder
/* 554:    */   {
/* 555:    */     public abstract boolean hasPlayerText();
/* 556:    */     
/* 557:    */     public abstract String getPlayerText();
/* 558:    */     
/* 559:    */     public abstract ByteString getPlayerTextBytes();
/* 560:    */   }
/* 561:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     proto.ProtocolWeb
 * JD-Core Version:    0.7.0.1
 */