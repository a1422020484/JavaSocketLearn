/*  1:   */ package xzj.tool.deploy;
/*  2:   */ 
/*  3:   */ import java.util.Collections;
/*  4:   */ import java.util.List;
/*  5:   */ import javafx.beans.property.SimpleObjectProperty;
/*  6:   */ import javafx.beans.property.SimpleStringProperty;
/*  7:   */ import javafx.scene.control.CheckBox;
/*  8:   */ import xzj.tool.deploy.conf.Game;
/*  9:   */ 
/* 10:   */ public class ServerModel
/* 11:   */ {
/* 12:   */   protected SimpleObjectProperty selected;
/* 13:   */   protected SimpleStringProperty name;
/* 14:   */   protected SimpleStringProperty host;
/* 15:   */   protected SimpleStringProperty address;
/* 16:   */   protected SimpleObjectProperty state;
/* 17:   */   
/* 18:   */   public boolean isSelected()
/* 19:   */   {
/* 20:29 */     CheckBox checkBox = (CheckBox)this.selected.get();
/* 21:30 */     return (checkBox.isSelected()) || (checkBox.isIndeterminate());
/* 22:   */   }
/* 23:   */   
/* 24:   */   public List<Game> getSelectedGames()
/* 25:   */   {
/* 26:38 */     return Collections.emptyList();
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Object getSelected()
/* 30:   */   {
/* 31:43 */     return this.selected.get();
/* 32:   */   }
/* 33:   */   
/* 34:   */   public SimpleObjectProperty selectedProperty()
/* 35:   */   {
/* 36:47 */     return this.selected;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setSelected(Object selected)
/* 40:   */   {
/* 41:51 */     this.selected.set(selected);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getName()
/* 45:   */   {
/* 46:55 */     return this.name.get();
/* 47:   */   }
/* 48:   */   
/* 49:   */   public SimpleStringProperty nameProperty()
/* 50:   */   {
/* 51:59 */     return this.name;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void setName(String name)
/* 55:   */   {
/* 56:63 */     this.name.set(name);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public String getHost()
/* 60:   */   {
/* 61:67 */     return this.host.get();
/* 62:   */   }
/* 63:   */   
/* 64:   */   public SimpleStringProperty hostProperty()
/* 65:   */   {
/* 66:71 */     return this.host;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void setHost(String host)
/* 70:   */   {
/* 71:75 */     this.host.set(host);
/* 72:   */   }
/* 73:   */   
/* 74:   */   public String getAddress()
/* 75:   */   {
/* 76:79 */     return this.address.get();
/* 77:   */   }
/* 78:   */   
/* 79:   */   public SimpleStringProperty addressProperty()
/* 80:   */   {
/* 81:83 */     return this.address;
/* 82:   */   }
/* 83:   */   
/* 84:   */   public void setAddress(String address)
/* 85:   */   {
/* 86:87 */     this.address.set(address);
/* 87:   */   }
/* 88:   */   
/* 89:   */   public Object getState()
/* 90:   */   {
/* 91:91 */     return this.state.get();
/* 92:   */   }
/* 93:   */   
/* 94:   */   public SimpleObjectProperty stateProperty()
/* 95:   */   {
/* 96:95 */     return this.state;
/* 97:   */   }
/* 98:   */   
/* 99:   */   public void setState(Object state)
/* :0:   */   {
/* :1:99 */     this.state.set(state);
/* :2:   */   }
/* :3:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.ServerModel
 * JD-Core Version:    0.7.0.1
 */