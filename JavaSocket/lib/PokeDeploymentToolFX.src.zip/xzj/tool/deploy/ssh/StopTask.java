/*  1:   */ package xzj.tool.deploy.ssh;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import xzj.tool.deploy.TopServerModel;
/*  5:   */ import xzj.tool.deploy.conf.Game;
/*  6:   */ 
/*  7:   */ public class StopTask
/*  8:   */   extends AsyncExecTask
/*  9:   */ {
/* 10:   */   protected String[] getCommand(TopServerModel serverModel)
/* 11:   */   {
/* 12:20 */     List<Game> games = serverModel.getSelectedGames();
/* 13:21 */     String[] commands = new String[games.size()];
/* 14:22 */     for (int i = 0; i < games.size(); i++) {
/* 15:23 */       commands[i] = ((Game)games.get(i)).stopCmd;
/* 16:   */     }
/* 17:25 */     return commands;
/* 18:   */   }
/* 19:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.ssh.StopTask
 * JD-Core Version:    0.7.0.1
 */