/*   1:    */ package xzj.tool.deploy.ssh;
/*   2:    */ 
/*   3:    */ import com.jcraft.jsch.ChannelExec;
/*   4:    */ import com.jcraft.jsch.Session;
/*   5:    */ import java.io.InputStream;
/*   6:    */ import java.io.PrintStream;
/*   7:    */ import xzj.tool.deploy.TopServerModel;
/*   8:    */ import xzj.tool.deploy.conf.Server;
/*   9:    */ 
/*  10:    */ public abstract class ExecTask
/*  11:    */   extends ServerTask
/*  12:    */ {
/*  13:    */   protected void _run(Session session, TopServerModel serverModel)
/*  14:    */   {
/*  15: 22 */     String[] commands = getCommand(serverModel);
/*  16: 23 */     if (commands == null) {
/*  17: 24 */       throw new NullPointerException("commands is null");
/*  18:    */     }
/*  19: 27 */     for (String command : commands) {
/*  20: 28 */       exec(session, serverModel, command);
/*  21:    */     }
/*  22:    */   }
/*  23:    */   
/*  24:    */   protected ExecRs exec(Session session, TopServerModel serverModel, String command)
/*  25:    */   {
/*  26: 33 */     return exec(session, serverModel, command, true);
/*  27:    */   }
/*  28:    */   
/*  29:    */   protected ExecRs exec(Session session, TopServerModel serverModel, String command, boolean printMsg)
/*  30:    */   {
/*  31: 37 */     Server server = serverModel.server;
/*  32: 38 */     ExecRs rs = new ExecRs();
/*  33:    */     try
/*  34:    */     {
/*  35: 40 */       System.out.println("exec " + command);
/*  36: 41 */       ChannelExec channel = (ChannelExec)session.openChannel("exec");
/*  37: 42 */       channel.setCommand(command);
/*  38: 43 */       InputStream in = channel.getInputStream();
/*  39: 44 */       InputStream errIn = channel.getErrStream();
/*  40: 45 */       channel.connect();
/*  41:    */       
/*  42: 47 */       byte[] tmp = new byte[1024];
/*  43: 48 */       byte[] errTmp = new byte[1024];
/*  44: 49 */       StringBuilder inMsg = new StringBuilder(256);
/*  45: 50 */       StringBuilder errMsg = new StringBuilder(256);
/*  46:    */       for (;;)
/*  47:    */       {
/*  48: 52 */         if (in.available() > 0)
/*  49:    */         {
/*  50: 53 */           int i = in.read(tmp, 0, 1024);
/*  51: 54 */           if (i >= 0)
/*  52:    */           {
/*  53: 57 */             String msg = new String(tmp, 0, i);
/*  54: 58 */             inMsg.append(msg);
/*  55: 59 */             continue;
/*  56:    */           }
/*  57:    */         }
/*  58: 60 */         while (errIn.available() > 0)
/*  59:    */         {
/*  60: 61 */           int i = errIn.read(errTmp, 0, 1024);
/*  61: 62 */           if (i < 0) {
/*  62:    */             break;
/*  63:    */           }
/*  64: 65 */           String msg = new String(errTmp, 0, i);
/*  65: 66 */           errMsg.append(msg);
/*  66:    */         }
/*  67: 68 */         if (channel.isClosed())
/*  68:    */         {
/*  69: 69 */           if (in.available() <= 0)
/*  70:    */           {
/*  71: 71 */             System.out.println("exit-status: " + channel.getExitStatus());
/*  72: 72 */             break;
/*  73:    */           }
/*  74:    */         }
/*  75:    */         else {
/*  76:    */           try
/*  77:    */           {
/*  78: 75 */             Thread.sleep(300L);
/*  79:    */           }
/*  80:    */           catch (Exception localException1) {}
/*  81:    */         }
/*  82:    */       }
/*  83: 80 */       in.close();
/*  84: 81 */       errIn.close();
/*  85: 82 */       channel.disconnect();
/*  86: 84 */       if (errMsg.length() > 0)
/*  87:    */       {
/*  88: 85 */         if (printMsg) {
/*  89: 86 */           upMsgln(1, server.host + ">" + command + "\r\n-" + errMsg.toString().trim());
/*  90:    */         }
/*  91: 88 */         rs.errMsg = errMsg.toString();
/*  92:    */       }
/*  93:    */       else
/*  94:    */       {
/*  95: 90 */         if (printMsg) {
/*  96: 91 */           upMsgln(0, server.host + ">" + command + "\r\n-" + inMsg.toString().trim());
/*  97:    */         }
/*  98: 93 */         rs.msg = inMsg.toString();
/*  99:    */       }
/* 100:    */     }
/* 101:    */     catch (Exception e)
/* 102:    */     {
/* 103: 96 */       e.printStackTrace();
/* 104: 97 */       if (printMsg) {
/* 105: 98 */         upMsgln(1, server.host + ">" + command + " 失败!" + e.getMessage());
/* 106:    */       }
/* 107:100 */       rs.errMsg = e.getMessage();
/* 108:    */     }
/* 109:103 */     return rs;
/* 110:    */   }
/* 111:    */   
/* 112:    */   protected abstract String[] getCommand(TopServerModel paramTopServerModel);
/* 113:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.ssh.ExecTask
 * JD-Core Version:    0.7.0.1
 */