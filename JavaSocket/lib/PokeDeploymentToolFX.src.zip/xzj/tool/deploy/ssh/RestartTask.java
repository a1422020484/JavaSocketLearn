/*  1:   */ package xzj.tool.deploy.ssh;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import xzj.tool.deploy.TopServerModel;
/*  5:   */ import xzj.tool.deploy.conf.Game;
/*  6:   */ 
/*  7:   */ public class RestartTask
/*  8:   */   extends AsyncExecTask
/*  9:   */ {
/* 10:   */   protected String[] getCommand(TopServerModel serverModel)
/* 11:   */   {
/* 12:19 */     List<Game> games = serverModel.getSelectedGames();
/* 13:20 */     String[] commands = new String[games.size()];
/* 14:21 */     for (int i = 0; i < games.size(); i++) {
/* 15:22 */       commands[i] = ((Game)games.get(i)).restartCmd;
/* 16:   */     }
/* 17:24 */     return commands;
/* 18:   */   }
/* 19:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.ssh.RestartTask
 * JD-Core Version:    0.7.0.1
 */