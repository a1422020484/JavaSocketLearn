/*  1:   */ package xzj.tool.deploy.ssh;
/*  2:   */ 
/*  3:   */ public class ExecRs
/*  4:   */ {
/*  5:   */   public String msg;
/*  6:   */   public String errMsg;
/*  7:   */   
/*  8:   */   public ExecRs() {}
/*  9:   */   
/* 10:   */   public ExecRs(String msg, String errMsg)
/* 11:   */   {
/* 12:15 */     this.msg = msg;
/* 13:16 */     this.errMsg = errMsg;
/* 14:   */   }
/* 15:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.ssh.ExecRs
 * JD-Core Version:    0.7.0.1
 */