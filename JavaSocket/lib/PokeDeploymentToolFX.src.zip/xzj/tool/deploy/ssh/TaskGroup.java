/*  1:   */ package xzj.tool.deploy.ssh;
/*  2:   */ 
/*  3:   */ import com.jcraft.jsch.Session;
/*  4:   */ import xzj.tool.deploy.TopServerModel;
/*  5:   */ 
/*  6:   */ public abstract class TaskGroup
/*  7:   */   extends ServerTask
/*  8:   */ {
/*  9:   */   public boolean beforeRun()
/* 10:   */   {
/* 11:17 */     for (ServerTask task : getGroup()) {
/* 12:18 */       task.beforeRun();
/* 13:   */     }
/* 14:20 */     return true;
/* 15:   */   }
/* 16:   */   
/* 17:   */   protected void _run(Session session, TopServerModel serverModel)
/* 18:   */   {
/* 19:25 */     for (ServerTask task : getGroup()) {
/* 20:26 */       task._run(session, serverModel);
/* 21:   */     }
/* 22:   */   }
/* 23:   */   
/* 24:   */   protected abstract ServerTask[] getGroup();
/* 25:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.ssh.TaskGroup
 * JD-Core Version:    0.7.0.1
 */