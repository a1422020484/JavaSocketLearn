/*  1:   */ package xzj.tool.deploy.ssh;
/*  2:   */ 
/*  3:   */ public class DeployTask
/*  4:   */   extends TaskGroup
/*  5:   */ {
/*  6: 8 */   ServerTask[] group = { new StopTask(), new UploadTask(), new StartTask() };
/*  7:   */   
/*  8:   */   protected ServerTask[] getGroup()
/*  9:   */   {
/* 10:16 */     return this.group;
/* 11:   */   }
/* 12:   */   
/* 13:   */   public void addListener(ServerTaskListener listener)
/* 14:   */   {
/* 15:21 */     super.addListener(listener);
/* 16:22 */     for (ServerTask serverTask : this.group) {
/* 17:23 */       serverTask.addListener(listener);
/* 18:   */     }
/* 19:   */   }
/* 20:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.ssh.DeployTask
 * JD-Core Version:    0.7.0.1
 */