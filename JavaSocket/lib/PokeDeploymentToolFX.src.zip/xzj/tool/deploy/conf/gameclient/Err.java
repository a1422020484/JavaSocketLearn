/*  1:   */ package xzj.tool.deploy.conf.gameclient;
/*  2:   */ 
/*  3:   */ import xzj.tool.deploy.SubServerModel;
/*  4:   */ 
/*  5:   */ public class Err
/*  6:   */   implements GameClient.ResponseHandler
/*  7:   */ {
/*  8:   */   public SubServerModel subServerModel;
/*  9:   */   
/* 10:   */   public Err(SubServerModel subServerModel)
/* 11:   */   {
/* 12:14 */     this.subServerModel = subServerModel;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public int getHeadId()
/* 16:   */   {
/* 17:19 */     return 0;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void handle(GameClient.Response response)
/* 21:   */     throws Exception
/* 22:   */   {
/* 23:24 */     this.subServerModel.setState("正常");
/* 24:   */   }
/* 25:   */   
/* 26:   */   public boolean isEncrypted()
/* 27:   */   {
/* 28:29 */     return false;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public boolean isSystem()
/* 32:   */   {
/* 33:34 */     return false;
/* 34:   */   }
/* 35:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.conf.gameclient.Err
 * JD-Core Version:    0.7.0.1
 */