/*   1:    */ package xzj.tool.deploy.conf.gameclient;
/*   2:    */ 
/*   3:    */ import com.google.protobuf.MessageLite;
/*   4:    */ import io.netty.buffer.ByteBuf;
/*   5:    */ import io.netty.buffer.Unpooled;
/*   6:    */ import java.io.BufferedInputStream;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.security.KeyStore;
/*  10:    */ import java.security.cert.CertificateException;
/*  11:    */ import java.security.cert.X509Certificate;
/*  12:    */ import java.util.HashMap;
/*  13:    */ import java.util.Map;
/*  14:    */ import javax.net.ssl.SSLContext;
/*  15:    */ import org.apache.http.HttpEntity;
/*  16:    */ import org.apache.http.HttpResponse;
/*  17:    */ import org.apache.http.client.config.RequestConfig;
/*  18:    */ import org.apache.http.client.config.RequestConfig.Builder;
/*  19:    */ import org.apache.http.client.methods.CloseableHttpResponse;
/*  20:    */ import org.apache.http.client.methods.HttpPost;
/*  21:    */ import org.apache.http.client.utils.HttpClientUtils;
/*  22:    */ import org.apache.http.conn.ssl.SSLContextBuilder;
/*  23:    */ import org.apache.http.conn.ssl.SSLContexts;
/*  24:    */ import org.apache.http.conn.ssl.TrustStrategy;
/*  25:    */ import org.apache.http.entity.ByteArrayEntity;
/*  26:    */ import org.apache.http.impl.client.CloseableHttpClient;
/*  27:    */ import org.apache.http.impl.client.HttpClientBuilder;
/*  28:    */ import org.apache.http.impl.client.HttpClients;
/*  29:    */ import xzj.core.util.MsgUtils;
/*  30:    */ import xzj.core.util.RSAUtils;
/*  31:    */ 
/*  32:    */ public class GameClient
/*  33:    */ {
/*  34:    */   private String uri;
/*  35:    */   private String sessionId;
/*  36: 39 */   private Map<Integer, ResponseHandler> handlers = new HashMap();
/*  37:    */   private ResponseHandler errHandler;
/*  38: 42 */   public final int MaxDataLen = 8388608;
/*  39: 43 */   public final int MaxMessageLen = 4194304;
/*  40:    */   
/*  41:    */   public GameClient(String ip, int port)
/*  42:    */   {
/*  43: 48 */     this.uri = ("http://" + ip + ":" + port);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public GameClient(String uri)
/*  47:    */   {
/*  48: 54 */     this.uri = uri;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void send(int headId, MessageLite proto)
/*  52:    */     throws Exception
/*  53:    */   {
/*  54: 58 */     ByteBuf buf = Unpooled.buffer();
/*  55: 60 */     if (this.sessionId != null)
/*  56:    */     {
/*  57: 61 */       byte[] sessionData = this.sessionId.getBytes("utf-8");
/*  58: 62 */       buf.writeByte(sessionData.length);
/*  59: 63 */       buf.writeBytes(sessionData);
/*  60:    */     }
/*  61:    */     else
/*  62:    */     {
/*  63: 65 */       buf.writeByte(0);
/*  64:    */     }
/*  65: 68 */     buf.writeInt(headId);
/*  66: 69 */     if (proto != null)
/*  67:    */     {
/*  68: 70 */       byte[] protodata = proto.toByteArray();
/*  69: 71 */       ResponseHandler handler = (ResponseHandler)this.handlers.get(Integer.valueOf(headId));
/*  70: 72 */       if (handler != null) {
/*  71: 73 */         if (handler.isSystem())
/*  72:    */         {
/*  73: 74 */           protodata = RSAUtils.encryptByPublicKey(protodata);
/*  74:    */         }
/*  75: 75 */         else if ((handler.isEncrypted()) && (this.sessionId != null))
/*  76:    */         {
/*  77: 76 */           byte[] sessionIdEncrypt = this.sessionId.getBytes();
/*  78: 77 */           MsgUtils.encrypt(sessionIdEncrypt, MsgUtils.otherKey);
/*  79: 78 */           MsgUtils.encrypt(protodata, sessionIdEncrypt);
/*  80:    */         }
/*  81:    */       }
/*  82: 81 */       buf.writeBytes(protodata);
/*  83:    */     }
/*  84: 83 */     int len = buf.writerIndex();
/*  85: 84 */     byte[] data = new byte[len];
/*  86: 85 */     buf.getBytes(0, data);
/*  87:    */     
/*  88:    */ 
/*  89: 88 */     CloseableHttpClient e = null;
/*  90: 89 */     if (this.uri.startsWith("https"))
/*  91:    */     {
/*  92: 94 */       SSLContext requestConfig = SSLContexts.custom().loadTrustMaterial((KeyStore)null, new TrustStrategy()
/*  93:    */       {
/*  94:    */         public boolean isTrusted(X509Certificate[] chain, String authType)
/*  95:    */           throws CertificateException
/*  96:    */         {
/*  97: 92 */           return true;
/*  98:    */         }
/*  99: 94 */       }).build();
/* 100: 95 */       e = HttpClients.custom().setSslcontext(requestConfig).build();
/* 101:    */     }
/* 102:    */     else
/* 103:    */     {
/* 104: 97 */       e = HttpClients.createDefault();
/* 105:    */     }
/* 106:100 */     RequestConfig requestConfig1 = RequestConfig.custom().setConnectionRequestTimeout(3000).setConnectTimeout(3000).setSocketTimeout(3000).build();
/* 107:101 */     HttpPost post = new HttpPost(this.uri);
/* 108:102 */     post.setConfig(requestConfig1);
/* 109:103 */     post.setEntity(new ByteArrayEntity(data));
/* 110:104 */     CloseableHttpResponse resp = e.execute(post);
/* 111:105 */     handle(resp);
/* 112:106 */     HttpClientUtils.closeQuietly(resp);
/* 113:107 */     HttpClientUtils.closeQuietly(e);
/* 114:    */   }
/* 115:    */   
/* 116:    */   private void handle(HttpResponse resp)
/* 117:    */     throws Exception
/* 118:    */   {
/* 119:111 */     HttpEntity entity = resp.getEntity();
/* 120:112 */     if (!entity.isStreaming()) {
/* 121:113 */       return;
/* 122:    */     }
/* 123:114 */     int totalLen = (int)entity.getContentLength();
/* 124:115 */     if (totalLen == 0) {
/* 125:116 */       return;
/* 126:    */     }
/* 127:118 */     if (totalLen > 8388608) {
/* 128:119 */       throw new RuntimeException("返回的数据包长度(" + totalLen + ")超过最大长度:" + 8388608);
/* 129:    */     }
/* 130:121 */     byte[] data = new byte[totalLen];
/* 131:122 */     InputStream is = entity.getContent();
/* 132:123 */     BufferedInputStream bis = new BufferedInputStream(is);
/* 133:124 */     int offset = 0;
/* 134:125 */     byte[] temp = new byte[1024];
/* 135:    */     for (;;)
/* 136:    */     {
/* 137:127 */       int size = bis.read(temp);
/* 138:128 */       if (size <= 0) {
/* 139:    */         break;
/* 140:    */       }
/* 141:132 */       System.arraycopy(temp, 0, data, offset, size);
/* 142:133 */       offset += size;
/* 143:    */     }
/* 144:136 */     ByteBuf buf = Unpooled.wrappedBuffer(data);
/* 145:    */     for (;;)
/* 146:    */     {
/* 147:138 */       int partLen = buf.readInt();
/* 148:139 */       byte code = buf.readByte();
/* 149:140 */       int headId = buf.readInt();
/* 150:141 */       if (partLen > 4194304) {
/* 151:142 */         throw new RuntimeException("返回的消息体长度(" + partLen + ")超过最大长度:" + 4194304 + " headId:" + headId);
/* 152:    */       }
/* 153:146 */       byte[] protodata = new byte[partLen - 5];
/* 154:147 */       buf.readBytes(protodata);
/* 155:    */       
/* 156:149 */       ResponseHandler handler = (ResponseHandler)this.handlers.get(Integer.valueOf(headId));
/* 157:150 */       if ((handler != null) && 
/* 158:151 */         (!handler.isSystem())) {
/* 159:153 */         if ((handler.isEncrypted()) && (this.sessionId != null))
/* 160:    */         {
/* 161:154 */           byte[] sessionIdEncrypt = this.sessionId.getBytes();
/* 162:155 */           MsgUtils.encrypt(sessionIdEncrypt, MsgUtils.otherKey);
/* 163:156 */           MsgUtils.encrypt(protodata, sessionIdEncrypt);
/* 164:    */         }
/* 165:    */       }
/* 166:159 */       Response r = new Response(code == 0, headId, protodata);
/* 167:160 */       if (code == 0)
/* 168:    */       {
/* 169:161 */         if (handler != null) {
/* 170:    */           try
/* 171:    */           {
/* 172:163 */             handler.handle(r);
/* 173:    */           }
/* 174:    */           catch (Exception e)
/* 175:    */           {
/* 176:165 */             e.printStackTrace();
/* 177:    */           }
/* 178:    */         } else {
/* 179:168 */           System.err.println("未找到处理器:" + headId);
/* 180:    */         }
/* 181:    */       }
/* 182:171 */       else if (this.errHandler != null) {
/* 183:172 */         this.errHandler.handle(r);
/* 184:    */       }
/* 185:175 */       if (buf.readerIndex() == totalLen) {
/* 186:    */         break;
/* 187:    */       }
/* 188:    */     }
/* 189:    */   }
/* 190:    */   
/* 191:    */   public void setSessionId(String sessionId)
/* 192:    */   {
/* 193:182 */     this.sessionId = sessionId;
/* 194:    */   }
/* 195:    */   
/* 196:    */   public void addHandler(ResponseHandler handler)
/* 197:    */   {
/* 198:191 */     this.handlers.put(Integer.valueOf(handler.getHeadId()), handler);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public void setErrHandler(ResponseHandler errHandler)
/* 202:    */   {
/* 203:200 */     this.errHandler = errHandler;
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static class Response
/* 207:    */   {
/* 208:    */     public boolean isSuccess;
/* 209:    */     public int headId;
/* 210:    */     public byte[] protobufData;
/* 211:    */     
/* 212:    */     public Response(boolean isSuccess, int headId, byte[] protobufData)
/* 213:    */     {
/* 214:210 */       this.isSuccess = isSuccess;
/* 215:211 */       this.headId = headId;
/* 216:212 */       this.protobufData = protobufData;
/* 217:    */     }
/* 218:    */   }
/* 219:    */   
/* 220:    */   public static abstract interface ResponseHandler
/* 221:    */   {
/* 222:    */     public abstract int getHeadId();
/* 223:    */     
/* 224:    */     public abstract void handle(GameClient.Response paramResponse)
/* 225:    */       throws Exception;
/* 226:    */     
/* 227:    */     public abstract boolean isEncrypted();
/* 228:    */     
/* 229:    */     public abstract boolean isSystem();
/* 230:    */   }
/* 231:    */   
/* 232:    */   public static class ResponseHandlerAdaptor
/* 233:    */     implements GameClient.ResponseHandler
/* 234:    */   {
/* 235:    */     public int getHeadId()
/* 236:    */     {
/* 237:229 */       return 0;
/* 238:    */     }
/* 239:    */     
/* 240:    */     public void handle(GameClient.Response r)
/* 241:    */       throws Exception
/* 242:    */     {}
/* 243:    */     
/* 244:    */     public boolean isEncrypted()
/* 245:    */     {
/* 246:239 */       return true;
/* 247:    */     }
/* 248:    */     
/* 249:    */     public boolean isSystem()
/* 250:    */     {
/* 251:244 */       return false;
/* 252:    */     }
/* 253:    */   }
/* 254:    */   
/* 255:    */   public static class SystemResponseHandlerAdaptor
/* 256:    */     implements GameClient.ResponseHandler
/* 257:    */   {
/* 258:    */     public int getHeadId()
/* 259:    */     {
/* 260:251 */       return 0;
/* 261:    */     }
/* 262:    */     
/* 263:    */     public void handle(GameClient.Response r)
/* 264:    */       throws Exception
/* 265:    */     {}
/* 266:    */     
/* 267:    */     public boolean isEncrypted()
/* 268:    */     {
/* 269:261 */       return true;
/* 270:    */     }
/* 271:    */     
/* 272:    */     public boolean isSystem()
/* 273:    */     {
/* 274:266 */       return true;
/* 275:    */     }
/* 276:    */   }
/* 277:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.conf.gameclient.GameClient
 * JD-Core Version:    0.7.0.1
 */