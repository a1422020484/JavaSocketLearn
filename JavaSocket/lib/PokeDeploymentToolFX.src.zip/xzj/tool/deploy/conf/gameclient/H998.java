/*  1:   */ package xzj.tool.deploy.conf.gameclient;
/*  2:   */ 
/*  3:   */ import xzj.tool.deploy.SubServerModel;
/*  4:   */ 
/*  5:   */ public class H998
/*  6:   */   extends GameClient.ResponseHandlerAdaptor
/*  7:   */ {
/*  8:   */   public SubServerModel subServerModel;
/*  9:   */   
/* 10:   */   public H998(SubServerModel subServerModel)
/* 11:   */   {
/* 12:14 */     this.subServerModel = subServerModel;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public int getHeadId()
/* 16:   */   {
/* 17:19 */     return 998;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void handle(GameClient.Response r)
/* 21:   */     throws Exception
/* 22:   */   {
/* 23:25 */     this.subServerModel.setState("正常");
/* 24:   */   }
/* 25:   */   
/* 26:   */   public boolean isEncrypted()
/* 27:   */   {
/* 28:30 */     return true;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public boolean isSystem()
/* 32:   */   {
/* 33:35 */     return true;
/* 34:   */   }
/* 35:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.conf.gameclient.H998
 * JD-Core Version:    0.7.0.1
 */