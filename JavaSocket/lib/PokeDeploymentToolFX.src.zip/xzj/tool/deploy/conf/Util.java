/*  1:   */ package xzj.tool.deploy.conf;
/*  2:   */ 
/*  3:   */ import java.io.File;
/*  4:   */ import java.io.FileInputStream;
/*  5:   */ import java.io.PrintStream;
/*  6:   */ import java.io.UnsupportedEncodingException;
/*  7:   */ import java.net.URL;
/*  8:   */ import java.net.URLDecoder;
/*  9:   */ import org.apache.commons.codec.digest.DigestUtils;
/* 10:   */ import org.slf4j.Logger;
/* 11:   */ import org.slf4j.LoggerFactory;
/* 12:   */ 
/* 13:   */ public class Util
/* 14:   */ {
/* 15:18 */   public static final Logger RUN_LOG = LoggerFactory.getLogger("run");
/* 16:19 */   public static final Logger ERR_LOG = LoggerFactory.getLogger("err");
/* 17:   */   
/* 18:   */   public static String getPwd()
/* 19:   */   {
/* 20:26 */     URL url = ServerManager.class.getResource("/");
/* 21:27 */     String path = url.getPath();
/* 22:   */     try
/* 23:   */     {
/* 24:29 */       path = URLDecoder.decode(path, "utf-8");
/* 25:   */     }
/* 26:   */     catch (UnsupportedEncodingException e)
/* 27:   */     {
/* 28:31 */       e.printStackTrace();
/* 29:   */     }
/* 30:33 */     System.out.println("PATH '/' : " + path);
/* 31:34 */     return path;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static String getFileMD5(File file)
/* 35:   */   {
/* 36:   */     try
/* 37:   */     {
/* 38:44 */       FileInputStream fis = new FileInputStream(file);
/* 39:45 */       return DigestUtils.md5Hex(fis);
/* 40:   */     }
/* 41:   */     catch (Exception e)
/* 42:   */     {
/* 43:47 */       e.printStackTrace();
/* 44:   */     }
/* 45:49 */     return "";
/* 46:   */   }
/* 47:   */   
/* 48:   */   public static void main(String[] args)
/* 49:   */   {
/* 50:53 */     System.out.println(getPwd());
/* 51:54 */     System.out.println(getFileMD5(new File("/Users/xiezuojie/Documents/IdeaWorkspace/Pokemon/PokeDeploymentToolFx/target/classes/servers.xml")));
/* 52:   */   }
/* 53:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.conf.Util
 * JD-Core Version:    0.7.0.1
 */