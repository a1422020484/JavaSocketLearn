/*  1:   */ package xzj.tool.deploy.conf;
/*  2:   */ 
/*  3:   */ public class Game
/*  4:   */ {
/*  5:   */   public String name;
/*  6:   */   public String path;
/*  7:   */   public String socket;
/*  8:   */   public String port;
/*  9:   */   public String startCmd;
/* 10:   */   public String stopCmd;
/* 11:   */   public String restartCmd;
/* 12:   */   public static final String STATE_UNKNOWN = "未知";
/* 13:   */   public static final String STATE_CONNECTING = "连接中";
/* 14:   */   public static final String STATE_SUCCESSFUL = "正常";
/* 15:   */   public static final String STATE_FAILURE = "失败";
/* 16:   */   public Server server;
/* 17:   */   public String address;
/* 18:   */   
/* 19:   */   public String toString()
/* 20:   */   {
/* 21:25 */     return "Game{name='" + this.name + '\'' + ", path='" + this.path + '\'' + ", socket='" + this.socket + '\'' + ", port='" + this.port + '\'' + ", startCmd='" + this.startCmd + '\'' + ", stopCmd='" + this.stopCmd + '\'' + ", restartCmd='" + this.restartCmd + '\'' + '}';
/* 22:   */   }
/* 23:   */   
/* 24:   */   public boolean equals(Object o)
/* 25:   */   {
/* 26:38 */     if (this == o) {
/* 27:38 */       return true;
/* 28:   */     }
/* 29:39 */     if ((o == null) || (getClass() != o.getClass())) {
/* 30:39 */       return false;
/* 31:   */     }
/* 32:41 */     Game game = (Game)o;
/* 33:   */     
/* 34:43 */     return this.name.equals(game.name);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public int hashCode()
/* 38:   */   {
/* 39:49 */     return this.name.hashCode();
/* 40:   */   }
/* 41:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.conf.Game
 * JD-Core Version:    0.7.0.1
 */