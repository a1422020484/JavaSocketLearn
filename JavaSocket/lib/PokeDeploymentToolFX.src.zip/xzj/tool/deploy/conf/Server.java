/*  1:   */ package xzj.tool.deploy.conf;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ 
/*  5:   */ public class Server
/*  6:   */ {
/*  7:   */   public String name;
/*  8:   */   public String user;
/*  9:   */   public String pass;
/* 10:   */   public String host;
/* 11:   */   public int port;
/* 12:   */   public String local;
/* 13:   */   public String games;
/* 14:   */   public String ports;
/* 15:   */   public String uploadPath;
/* 16:   */   public String copyPath;
/* 17:   */   public List<Game> gamesList;
/* 18:   */   
/* 19:   */   public String toString()
/* 20:   */   {
/* 21:24 */     return "Server{name='" + this.name + '\'' + ", user='" + this.user + '\'' + ", pass='" + this.pass + '\'' + ", host='" + this.host + '\'' + ", port=" + this.port + ", local='" + this.local + '\'' + ", games='" + this.games + '\'' + ", ports='" + this.ports + '\'' + ", uploadPath='" + this.uploadPath + '\'' + ", gamesList=" + this.gamesList + '}';
/* 22:   */   }
/* 23:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.conf.Server
 * JD-Core Version:    0.7.0.1
 */