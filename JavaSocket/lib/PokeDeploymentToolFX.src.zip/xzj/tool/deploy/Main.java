/*  1:   */ package xzj.tool.deploy;
/*  2:   */ 
/*  3:   */ import javafx.application.Application;
/*  4:   */ import javafx.fxml.FXMLLoader;
/*  5:   */ import javafx.scene.Parent;
/*  6:   */ import javafx.scene.Scene;
/*  7:   */ import javafx.stage.Stage;
/*  8:   */ import xzj.tool.deploy.conf.ServerManager;
/*  9:   */ 
/* 10:   */ public class Main
/* 11:   */   extends Application
/* 12:   */ {
/* 13:   */   public void start(Stage primaryStage)
/* 14:   */     throws Exception
/* 15:   */   {
/* 16:16 */     ServerManager.loadServers();
/* 17:   */     
/* 18:18 */     Parent root = (Parent)FXMLLoader.load(getClass().getResource("/main.fxml"));
/* 19:19 */     primaryStage.setTitle("上传工具1.0");
/* 20:20 */     primaryStage.setScene(new Scene(root, 1000.0D, 600.0D));
/* 21:21 */     primaryStage.show();
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static void main(String[] args)
/* 25:   */   {
/* 26:28 */     launch(args);
/* 27:   */   }
/* 28:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     xzj.tool.deploy.Main
 * JD-Core Version:    0.7.0.1
 */