/*   1:    */ package org.thehecklers.monologfx;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.net.URL;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.List;
/*   7:    */ import javafx.animation.KeyFrame;
/*   8:    */ import javafx.animation.KeyValue;
/*   9:    */ import javafx.animation.Timeline;
/*  10:    */ import javafx.application.Platform;
/*  11:    */ import javafx.beans.property.DoubleProperty;
/*  12:    */ import javafx.collections.ObservableList;
/*  13:    */ import javafx.event.ActionEvent;
/*  14:    */ import javafx.event.Event;
/*  15:    */ import javafx.event.EventHandler;
/*  16:    */ import javafx.geometry.Insets;
/*  17:    */ import javafx.geometry.Pos;
/*  18:    */ import javafx.geometry.Rectangle2D;
/*  19:    */ import javafx.scene.Node;
/*  20:    */ import javafx.scene.Scene;
/*  21:    */ import javafx.scene.control.Button;
/*  22:    */ import javafx.scene.control.Label;
/*  23:    */ import javafx.scene.image.Image;
/*  24:    */ import javafx.scene.image.ImageView;
/*  25:    */ import javafx.scene.layout.BorderPane;
/*  26:    */ import javafx.scene.layout.HBox;
/*  27:    */ import javafx.stage.Modality;
/*  28:    */ import javafx.stage.Screen;
/*  29:    */ import javafx.stage.Stage;
/*  30:    */ import javafx.stage.StageStyle;
/*  31:    */ import javafx.util.Duration;
/*  32:    */ 
/*  33:    */ public class MonologFX
/*  34:    */ {
/*  35:    */   private Type type;
/*  36:    */   private Scene scene;
/*  37:    */   private Stage stage;
/*  38:    */   
/*  39:    */   public static enum Type
/*  40:    */   {
/*  41: 49 */     ACCEPT,  ERROR,  INFO,  QUESTION;
/*  42:    */     
/*  43:    */     private Type() {}
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static enum ButtonAlignment
/*  47:    */   {
/*  48: 50 */     LEFT,  RIGHT,  CENTER;
/*  49:    */     
/*  50:    */     private ButtonAlignment() {}
/*  51:    */   }
/*  52:    */   
/*  53: 55 */   private final BorderPane pane = new BorderPane();
/*  54: 56 */   private final ImageView icon = new ImageView();
/*  55: 57 */   private final Label message = new Label();
/*  56: 58 */   private final HBox buttonBox = new HBox(10.0D);
/*  57: 59 */   private final List<MonologFXButton> buttons = new ArrayList();
/*  58: 60 */   private int buttonCancel = -1;
/*  59: 61 */   private int buttonSelected = -1;
/*  60: 62 */   private ButtonAlignment buttonAlignment = ButtonAlignment.CENTER;
/*  61: 63 */   private float displayTime = 0.0F;
/*  62:    */   private float fadeInOutTime;
/*  63: 65 */   private final List<String> stylesheets = new ArrayList();
/*  64:    */   
/*  65:    */   public MonologFX()
/*  66:    */   {
/*  67: 73 */     initDialog(Type.INFO);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public MonologFX(Type t)
/*  71:    */   {
/*  72: 84 */     initDialog(t);
/*  73:    */   }
/*  74:    */   
/*  75:    */   private void addOKButton()
/*  76:    */   {
/*  77: 88 */     MonologFXButton okBtn = new MonologFXButton();
/*  78: 89 */     okBtn.setType(MonologFXButton.Type.OK);
/*  79: 90 */     okBtn.setLabel("_OK");
/*  80: 91 */     okBtn.setCancelButton(true);
/*  81: 92 */     okBtn.setDefaultButton(true);
/*  82:    */     
/*  83: 94 */     addButton(okBtn);
/*  84:    */   }
/*  85:    */   
/*  86:    */   private void addYesNoButtons()
/*  87:    */   {
/*  88:105 */     MonologFXButton yesBtn = new MonologFXButton();
/*  89:106 */     yesBtn.setType(MonologFXButton.Type.YES);
/*  90:107 */     yesBtn.setLabel("_Yes");
/*  91:108 */     yesBtn.setCancelButton(false);
/*  92:109 */     yesBtn.setDefaultButton(false);
/*  93:    */     
/*  94:111 */     addButton(yesBtn);
/*  95:    */     
/*  96:113 */     MonologFXButton noBtn = new MonologFXButton();
/*  97:114 */     noBtn.setType(MonologFXButton.Type.NO);
/*  98:115 */     noBtn.setLabel("_No");
/*  99:116 */     noBtn.setCancelButton(false);
/* 100:117 */     noBtn.setDefaultButton(false);
/* 101:    */     
/* 102:119 */     addButton(noBtn);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void addButton(MonologFXButton btnToAdd)
/* 106:    */   {
/* 107:130 */     this.buttons.add(btnToAdd);
/* 108:    */     
/* 109:132 */     final Button btn = new Button();
/* 110:    */     
/* 111:134 */     btn.setMnemonicParsing(true);
/* 112:135 */     btn.setText(btnToAdd.getLabel());
/* 113:137 */     if (btnToAdd.getIcon() != null) {
/* 114:138 */       btn.setGraphic(btnToAdd.getIcon());
/* 115:    */     }
/* 116:141 */     btn.setDefaultButton(btnToAdd.isDefaultButton());
/* 117:142 */     if (btnToAdd.isCancelButton())
/* 118:    */     {
/* 119:143 */       btn.setCancelButton(true);
/* 120:144 */       this.buttonCancel = (this.buttons.size() - 1);
/* 121:    */     }
/* 122:147 */     if (btn.isDefaultButton()) {
/* 123:148 */       Platform.runLater(new Runnable()
/* 124:    */       {
/* 125:    */         public void run()
/* 126:    */         {
/* 127:151 */           btn.requestFocus();
/* 128:    */         }
/* 129:    */       });
/* 130:    */     }
/* 131:156 */     btn.setOnAction(new EventHandler()
/* 132:    */     {
/* 133:    */       public void handle(ActionEvent evt)
/* 134:    */       {
/* 135:160 */         for (int i = 0; i < MonologFX.this.buttons.size(); i++) {
/* 136:161 */           if (((MonologFXButton)MonologFX.this.buttons.get(i)).getLabel().equalsIgnoreCase(((Button)evt.getSource()).getText()))
/* 137:    */           {
/* 138:162 */             MonologFX.this.buttonSelected = i;
/* 139:163 */             break;
/* 140:    */           }
/* 141:    */         }
/* 142:168 */         ((Stage)((Node)evt.getSource()).getScene().getWindow()).close();
/* 143:    */       }
/* 144:171 */     });
/* 145:172 */     this.buttonBox.getChildren().add(btn);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public void addStylesheet(String stylesheet)
/* 149:    */   {
/* 150:    */     try
/* 151:    */     {
/* 152:184 */       String newStyle = getClass().getResource(stylesheet).toExternalForm();
/* 153:185 */       this.stylesheets.add(newStyle);
/* 154:    */     }
/* 155:    */     catch (Exception ex)
/* 156:    */     {
/* 157:187 */       System.err.println("Unable to find specified stylesheet: " + stylesheet);
/* 158:188 */       System.err.println("Error message: " + ex.getMessage());
/* 159:    */     }
/* 160:    */   }
/* 161:    */   
/* 162:    */   private void initDialog(Type t)
/* 163:    */   {
/* 164:193 */     this.stage = new Stage();
/* 165:194 */     this.stage.initStyle(StageStyle.UTILITY);
/* 166:    */     
/* 167:196 */     setType(t);
/* 168:197 */     this.stage.initModality(Modality.APPLICATION_MODAL);
/* 169:198 */     this.stage.setMaxWidth(Screen.getPrimary().getVisualBounds().getWidth() / 2.0D);
/* 170:    */   }
/* 171:    */   
/* 172:    */   private void loadIconFromResource(String fileName)
/* 173:    */   {
/* 174:202 */     Image imgIcon = new Image(getClass().getResourceAsStream(fileName));
/* 175:203 */     this.icon.setPreserveRatio(true);
/* 176:204 */     this.icon.setFitHeight(48.0D);
/* 177:205 */     this.icon.setImage(imgIcon);
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void setButtonAlignment(ButtonAlignment buttonAlignment)
/* 181:    */   {
/* 182:216 */     this.buttonAlignment = buttonAlignment;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void setDisplayTime(int displayTime)
/* 186:    */   {
/* 187:226 */     this.displayTime = displayTime;
/* 188:    */     
/* 189:    */ 
/* 190:229 */     this.fadeInOutTime = Math.min(displayTime / 4.0F, 5.0F);
/* 191:    */   }
/* 192:    */   
/* 193:    */   public void setMessage(String msg)
/* 194:    */   {
/* 195:239 */     this.message.setText(msg);
/* 196:240 */     this.message.setWrapText(true);
/* 197:    */   }
/* 198:    */   
/* 199:    */   public void setModal(boolean isModal)
/* 200:    */   {
/* 201:249 */     this.stage.initModality(isModal ? Modality.APPLICATION_MODAL : Modality.NONE);
/* 202:    */   }
/* 203:    */   
/* 204:    */   public void setTitleText(String title)
/* 205:    */   {
/* 206:258 */     this.stage.setTitle(title);
/* 207:    */   }
/* 208:    */   
/* 209:    */   public void setType(Type typeToSet)
/* 210:    */   {
/* 211:268 */     this.type = typeToSet;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public void setPos(double x, double y)
/* 215:    */   {
/* 216:278 */     this.stage.setX(x);
/* 217:279 */     this.stage.setY(y);
/* 218:    */   }
/* 219:    */   
/* 220:    */   public void setX(double x)
/* 221:    */   {
/* 222:288 */     this.stage.setX(x);
/* 223:    */   }
/* 224:    */   
/* 225:    */   public void setY(double y)
/* 226:    */   {
/* 227:297 */     this.stage.setY(y);
/* 228:    */   }
/* 229:    */   
/* 230:    */   private void populateStage()
/* 231:    */   {
/* 232:    */     String iconFile;
/* 233:    */     String iconFile;
/* 234:303 */     switch (4.$SwitchMap$org$thehecklers$monologfx$MonologFX$Type[this.type.ordinal()])
/* 235:    */     {
/* 236:    */     case 1: 
/* 237:305 */       String iconFile = "Dialog-accept.jpg";
/* 238:307 */       if (this.buttons.isEmpty()) {
/* 239:308 */         addOKButton();
/* 240:    */       }
/* 241:    */       break;
/* 242:    */     case 2: 
/* 243:312 */       String iconFile = "Dialog-error.jpg";
/* 244:314 */       if (this.buttons.isEmpty()) {
/* 245:315 */         addOKButton();
/* 246:    */       }
/* 247:    */       break;
/* 248:    */     case 3: 
/* 249:319 */       String iconFile = "Dialog-info.jpg";
/* 250:321 */       if (this.buttons.isEmpty()) {
/* 251:322 */         addOKButton();
/* 252:    */       }
/* 253:    */       break;
/* 254:    */     case 4: 
/* 255:326 */       iconFile = "Dialog-question.jpg";
/* 256:327 */       break;
/* 257:    */     default: 
/* 258:329 */       iconFile = "Dialog-info.jpg";
/* 259:    */     }
/* 260:    */     try
/* 261:    */     {
/* 262:334 */       loadIconFromResource(iconFile);
/* 263:    */     }
/* 264:    */     catch (Exception ex)
/* 265:    */     {
/* 266:336 */       System.err.println("Exception trying to load icon file: " + ex.getMessage());
/* 267:    */     }
/* 268:339 */     BorderPane.setAlignment(this.icon, Pos.CENTER_LEFT);
/* 269:340 */     BorderPane.setMargin(this.icon, new Insets(5.0D));
/* 270:341 */     this.pane.setLeft(this.icon);
/* 271:    */     
/* 272:343 */     BorderPane.setAlignment(this.message, Pos.CENTER);
/* 273:344 */     BorderPane.setMargin(this.message, new Insets(5.0D));
/* 274:345 */     this.pane.setCenter(this.message);
/* 275:347 */     switch (4.$SwitchMap$org$thehecklers$monologfx$MonologFX$ButtonAlignment[this.buttonAlignment.ordinal()])
/* 276:    */     {
/* 277:    */     case 1: 
/* 278:349 */       this.buttonBox.setAlignment(Pos.CENTER_LEFT);
/* 279:350 */       break;
/* 280:    */     case 2: 
/* 281:352 */       this.buttonBox.setAlignment(Pos.CENTER);
/* 282:353 */       break;
/* 283:    */     case 3: 
/* 284:355 */       this.buttonBox.setAlignment(Pos.CENTER_RIGHT);
/* 285:    */     }
/* 286:359 */     BorderPane.setMargin(this.buttonBox, new Insets(5.0D));
/* 287:360 */     this.pane.setBottom(this.buttonBox);
/* 288:    */     
/* 289:362 */     this.scene = new Scene(this.pane);
/* 290:363 */     for (int i = 0; i < this.stylesheets.size(); i++) {
/* 291:    */       try
/* 292:    */       {
/* 293:365 */         this.scene.getStylesheets().add(this.stylesheets.get(i));
/* 294:    */       }
/* 295:    */       catch (Exception ex)
/* 296:    */       {
/* 297:367 */         System.err.println("Unable to load specified stylesheet: " + (String)this.stylesheets.get(i));
/* 298:368 */         System.err.println(ex.getMessage());
/* 299:    */       }
/* 300:    */     }
/* 301:371 */     this.stage.setScene(this.scene);
/* 302:    */   }
/* 303:    */   
/* 304:    */   /**
/* 305:    */    * @deprecated
/* 306:    */    */
/* 307:    */   public MonologFXButton.Type showDialog()
/* 308:    */   {
/* 309:384 */     return show();
/* 310:    */   }
/* 311:    */   
/* 312:    */   public MonologFXButton.Type show()
/* 313:    */   {
/* 314:395 */     populateStage();
/* 315:396 */     if (this.type == Type.QUESTION) {
/* 316:398 */       if (this.buttons.isEmpty()) {
/* 317:399 */         addYesNoButtons();
/* 318:    */       }
/* 319:    */     }
/* 320:403 */     this.stage.setResizable(false);
/* 321:404 */     this.stage.sizeToScene();
/* 322:406 */     if (this.displayTime <= 0.0F)
/* 323:    */     {
/* 324:409 */       if ((this.stage.getX() <= -1.0D) || (this.stage.getY() <= -1.0D)) {
/* 325:410 */         this.stage.centerOnScreen();
/* 326:    */       }
/* 327:413 */       this.stage.showAndWait();
/* 328:    */     }
/* 329:    */     else
/* 330:    */     {
/* 331:415 */       this.stage.setOpacity(0.0D);
/* 332:416 */       this.stage.show();
/* 333:417 */       final DoubleProperty opacity = this.stage.opacityProperty();
/* 334:    */       
/* 335:    */ 
/* 336:    */ 
/* 337:    */ 
/* 338:    */ 
/* 339:    */ 
/* 340:    */ 
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:    */ 
/* 345:    */ 
/* 346:    */ 
/* 347:    */ 
/* 348:    */ 
/* 349:    */ 
/* 350:    */ 
/* 351:    */ 
/* 352:    */ 
/* 353:    */ 
/* 354:    */ 
/* 355:    */ 
/* 356:    */ 
/* 357:    */ 
/* 358:    */ 
/* 359:    */ 
/* 360:    */ 
/* 361:445 */       Timeline fadeIn = new Timeline(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(opacity, Double.valueOf(0.0D)) }), new KeyFrame(new Duration(this.fadeInOutTime * 1000.0F), new EventHandler()new KeyValue
/* 362:    */       {
/* 363:    */         public void handle(Event t)
/* 364:    */         {
/* 365:442 */           Timeline display = new Timeline(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(opacity, Double.valueOf(1.0D)) }), new KeyFrame(new Duration((MonologFX.this.displayTime - MonologFX.this.fadeInOutTime * 2.0F) * 1000.0F), new EventHandler()new KeyValue
/* 366:    */           {
/* 367:    */             public void handle(Event t)
/* 368:    */             {
/* 369:439 */               Timeline fadeOut = new Timeline(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(MonologFX.3.this.val$opacity, Double.valueOf(1.0D)) }), new KeyFrame(new Duration(MonologFX.this.fadeInOutTime * 1000.0F), new EventHandler()new KeyValue
/* 370:    */               {
/* 371:    */                 public void handle(Event t)
/* 372:    */                 {
/* 373:437 */                   MonologFX.this.stage.hide();
/* 374:    */                 }
/* 375:437 */               }
/* 376:    */               
/* 377:439 */                 , new KeyValue[] { new KeyValue(MonologFX.3.this.val$opacity, Double.valueOf(0.0D)) }) });
/* 378:440 */               fadeOut.play();
/* 379:    */             }
/* 380:440 */           }
/* 381:    */           
/* 382:442 */             , new KeyValue[] { new KeyValue(opacity, Double.valueOf(1.0D)) }) });
/* 383:443 */           display.play();
/* 384:    */         }
/* 385:443 */       }, new KeyValue[] { new KeyValue(opacity, 
/* 386:    */       
/* 387:445 */         Double.valueOf(1.0D)) }) });
/* 388:446 */       fadeIn.play();
/* 389:    */     }
/* 390:449 */     if (this.buttonSelected == -1) {
/* 391:454 */       return this.buttonCancel == -1 ? MonologFXButton.Type.CANCEL : ((MonologFXButton)this.buttons.get(this.buttonCancel)).getType();
/* 392:    */     }
/* 393:456 */     return ((MonologFXButton)this.buttons.get(this.buttonSelected)).getType();
/* 394:    */   }
/* 395:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     org.thehecklers.monologfx.MonologFX
 * JD-Core Version:    0.7.0.1
 */