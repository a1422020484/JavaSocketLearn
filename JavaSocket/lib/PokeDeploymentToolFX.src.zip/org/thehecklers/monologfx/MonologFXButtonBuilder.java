/*   1:    */ package org.thehecklers.monologfx;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import javafx.beans.property.BooleanProperty;
/*   5:    */ import javafx.beans.property.ObjectProperty;
/*   6:    */ import javafx.beans.property.Property;
/*   7:    */ import javafx.beans.property.SimpleBooleanProperty;
/*   8:    */ import javafx.beans.property.SimpleObjectProperty;
/*   9:    */ import javafx.beans.property.SimpleStringProperty;
/*  10:    */ import javafx.beans.property.StringProperty;
/*  11:    */ import javafx.scene.control.ControlBuilder;
/*  12:    */ import javafx.util.Builder;
/*  13:    */ 
/*  14:    */ public class MonologFXButtonBuilder<B extends MonologFXButtonBuilder<B>>
/*  15:    */   extends ControlBuilder<B>
/*  16:    */   implements Builder<MonologFXButton>
/*  17:    */ {
/*  18: 20 */   private HashMap<String, Property> properties = new HashMap();
/*  19:    */   
/*  20:    */   public static MonologFXButtonBuilder create()
/*  21:    */   {
/*  22: 31 */     return new MonologFXButtonBuilder();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public final MonologFXButtonBuilder type(MonologFXButton.Type TYPE)
/*  26:    */   {
/*  27: 42 */     this.properties.put("type", new SimpleObjectProperty(TYPE));
/*  28: 43 */     return this;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public final MonologFXButtonBuilder label(String LABEL)
/*  32:    */   {
/*  33: 55 */     this.properties.put("label", new SimpleStringProperty(LABEL));
/*  34: 56 */     return this;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public final MonologFXButtonBuilder icon(String ICON)
/*  38:    */   {
/*  39: 69 */     this.properties.put("icon", new SimpleStringProperty(ICON));
/*  40: 70 */     return this;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public final MonologFXButtonBuilder defaultButton(boolean DEFAULTBUTTON)
/*  44:    */   {
/*  45: 79 */     this.properties.put("defaultButton", new SimpleBooleanProperty(DEFAULTBUTTON));
/*  46: 80 */     return this;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public final MonologFXButtonBuilder cancelButton(boolean CANCELBUTTON)
/*  50:    */   {
/*  51: 89 */     this.properties.put("cancelButton", new SimpleBooleanProperty(CANCELBUTTON));
/*  52: 90 */     return this;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public MonologFXButton build()
/*  56:    */   {
/*  57:101 */     MonologFXButton CONTROL = new MonologFXButton();
/*  58:103 */     for (String key : this.properties.keySet()) {
/*  59:104 */       switch (key)
/*  60:    */       {
/*  61:    */       case "type": 
/*  62:106 */         CONTROL.setType((MonologFXButton.Type)((ObjectProperty)this.properties.get(key)).get());
/*  63:107 */         break;
/*  64:    */       case "label": 
/*  65:109 */         CONTROL.setLabel((String)((StringProperty)this.properties.get(key)).get());
/*  66:110 */         break;
/*  67:    */       case "icon": 
/*  68:112 */         CONTROL.setIcon((String)((StringProperty)this.properties.get(key)).get());
/*  69:113 */         break;
/*  70:    */       case "defaultButton": 
/*  71:115 */         CONTROL.setDefaultButton(((BooleanProperty)this.properties.get(key)).get());
/*  72:116 */         break;
/*  73:    */       case "cancelButton": 
/*  74:118 */         CONTROL.setCancelButton(((BooleanProperty)this.properties.get(key)).get());
/*  75:    */       }
/*  76:    */     }
/*  77:123 */     return CONTROL;
/*  78:    */   }
/*  79:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     org.thehecklers.monologfx.MonologFXButtonBuilder
 * JD-Core Version:    0.7.0.1
 */