/*   1:    */ package org.thehecklers.monologfx;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Locale;
/*   8:    */ import java.util.ResourceBundle;
/*   9:    */ import javafx.scene.Node;
/*  10:    */ import javafx.scene.image.Image;
/*  11:    */ import javafx.scene.image.ImageView;
/*  12:    */ 
/*  13:    */ public class MonologFXButton
/*  14:    */ {
/*  15:    */   public static enum Type
/*  16:    */   {
/*  17: 18 */     OK,  CANCEL,  ABORT,  RETRY,  IGNORE,  YES,  NO,  CUSTOM1,  CUSTOM2,  CUSTOM3;
/*  18:    */     
/*  19:    */     private Type() {}
/*  20:    */   }
/*  21:    */   
/*  22: 19 */   private List<String> defLabels = Arrays.asList(new String[] { "_OK", "_Cancel", "_Abort", "_Retry", "_Ignore", "_Yes", "_No", "Custom_1", "Custom_2", "Custom_3" });
/*  23: 21 */   private HashMap<Type, String> defaultLabels = new HashMap();
/*  24: 22 */   private Type type = Type.OK;
/*  25: 23 */   private String label = "";
/*  26:    */   private Node icon;
/*  27: 25 */   private boolean defaultButton = false;
/*  28: 26 */   private boolean cancelButton = false;
/*  29:    */   
/*  30:    */   public MonologFXButton()
/*  31:    */   {
/*  32: 34 */     int i = 0;
/*  33: 35 */     for (Type t : Type.values())
/*  34:    */     {
/*  35: 36 */       this.defaultLabels.put(t, this.defLabels.get(i));
/*  36: 37 */       i++;
/*  37:    */     }
/*  38:    */   }
/*  39:    */   
/*  40:    */   public Type getType()
/*  41:    */   {
/*  42: 49 */     return this.type;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setType(Type type)
/*  46:    */   {
/*  47: 60 */     this.type = type;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public String getLabel()
/*  51:    */   {
/*  52: 77 */     if (!this.label.isEmpty()) {
/*  53: 78 */       return this.label;
/*  54:    */     }
/*  55: 80 */     String labelToReturn = (String)this.defaultLabels.get(getType());
/*  56:    */     try
/*  57:    */     {
/*  58: 83 */       ResourceBundle res = ResourceBundle.getBundle("org/thehecklers/monologfx/MonologFXButton", Locale.getDefault());
/*  59: 84 */       if (res != null) {
/*  60: 85 */         labelToReturn = res.getString(labelToReturn.replaceAll("_", "").toUpperCase());
/*  61:    */       }
/*  62:    */     }
/*  63:    */     catch (Exception e)
/*  64:    */     {
/*  65: 88 */       System.err.println(e.getMessage());
/*  66:    */     }
/*  67: 91 */     return labelToReturn;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void setLabel(String label)
/*  71:    */   {
/*  72:104 */     this.label = label;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Node getIcon()
/*  76:    */   {
/*  77:113 */     return this.icon;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void setIcon(String iconFile)
/*  81:    */   {
/*  82:    */     try
/*  83:    */     {
/*  84:127 */       this.icon = new ImageView(new Image(getClass().getResourceAsStream(iconFile)));
/*  85:    */     }
/*  86:    */     catch (Exception e)
/*  87:    */     {
/*  88:129 */       System.err.println("Exception trying to load button icon:" + e.getMessage());
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean isDefaultButton()
/*  93:    */   {
/*  94:139 */     return this.defaultButton;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void setDefaultButton(boolean defaultButton)
/*  98:    */   {
/*  99:148 */     this.defaultButton = defaultButton;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public boolean isCancelButton()
/* 103:    */   {
/* 104:157 */     return this.cancelButton;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setCancelButton(boolean cancelButton)
/* 108:    */   {
/* 109:166 */     this.cancelButton = cancelButton;
/* 110:    */   }
/* 111:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     org.thehecklers.monologfx.MonologFXButton
 * JD-Core Version:    0.7.0.1
 */