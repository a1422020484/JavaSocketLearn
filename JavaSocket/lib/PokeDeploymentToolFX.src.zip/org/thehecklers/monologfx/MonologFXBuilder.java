/*   1:    */ package org.thehecklers.monologfx;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.List;
/*   6:    */ import javafx.beans.property.BooleanProperty;
/*   7:    */ import javafx.beans.property.DoubleProperty;
/*   8:    */ import javafx.beans.property.IntegerProperty;
/*   9:    */ import javafx.beans.property.ObjectProperty;
/*  10:    */ import javafx.beans.property.Property;
/*  11:    */ import javafx.beans.property.SimpleBooleanProperty;
/*  12:    */ import javafx.beans.property.SimpleDoubleProperty;
/*  13:    */ import javafx.beans.property.SimpleIntegerProperty;
/*  14:    */ import javafx.beans.property.SimpleObjectProperty;
/*  15:    */ import javafx.beans.property.SimpleStringProperty;
/*  16:    */ import javafx.beans.property.StringProperty;
/*  17:    */ import javafx.scene.control.ControlBuilder;
/*  18:    */ import javafx.util.Builder;
/*  19:    */ 
/*  20:    */ public class MonologFXBuilder<B extends MonologFXBuilder<B>>
/*  21:    */   extends ControlBuilder<B>
/*  22:    */   implements Builder<MonologFX>
/*  23:    */ {
/*  24: 26 */   private final HashMap<String, Property> properties = new HashMap();
/*  25: 27 */   private final List<MonologFXButton> buttons = new ArrayList();
/*  26: 28 */   private final List<String> stylesheets = new ArrayList();
/*  27:    */   
/*  28:    */   public static MonologFXBuilder create()
/*  29:    */   {
/*  30: 38 */     return new MonologFXBuilder();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public final MonologFXBuilder button(MonologFXButton BUTTON)
/*  34:    */   {
/*  35: 50 */     this.buttons.add(BUTTON);
/*  36: 51 */     return this;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public final MonologFXBuilder displayTime(int DISPLAYTIME)
/*  40:    */   {
/*  41: 62 */     this.properties.put("displayTime", new SimpleIntegerProperty(DISPLAYTIME));
/*  42: 63 */     return this;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public final MonologFXBuilder type(MonologFX.Type TYPE)
/*  46:    */   {
/*  47: 73 */     this.properties.put("type", new SimpleObjectProperty(TYPE));
/*  48: 74 */     return this;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public final MonologFXBuilder buttonAlignment(MonologFX.ButtonAlignment ALIGNBUTTONS)
/*  52:    */   {
/*  53: 85 */     this.properties.put("alignbuttons", new SimpleObjectProperty(ALIGNBUTTONS));
/*  54: 86 */     return this;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public final MonologFXBuilder message(String MESSAGE)
/*  58:    */   {
/*  59: 96 */     this.properties.put("message", new SimpleStringProperty(MESSAGE));
/*  60: 97 */     return this;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public final MonologFXBuilder modal(boolean MODAL)
/*  64:    */   {
/*  65:106 */     this.properties.put("modal", new SimpleBooleanProperty(MODAL));
/*  66:107 */     return this;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public final MonologFXBuilder titleText(String TITLE_TEXT)
/*  70:    */   {
/*  71:116 */     this.properties.put("titleText", new SimpleStringProperty(TITLE_TEXT));
/*  72:117 */     return this;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public final MonologFXBuilder X(double X_COORD)
/*  76:    */   {
/*  77:126 */     this.properties.put("xCoord", new SimpleDoubleProperty(X_COORD));
/*  78:127 */     return this;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public final MonologFXBuilder Y(double Y_COORD)
/*  82:    */   {
/*  83:136 */     this.properties.put("yCoord", new SimpleDoubleProperty(Y_COORD));
/*  84:137 */     return this;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public final MonologFXBuilder stylesheet(String STYLESHEET)
/*  88:    */   {
/*  89:149 */     this.stylesheets.add(STYLESHEET);
/*  90:150 */     return this;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public MonologFX build()
/*  94:    */   {
/*  95:162 */     MonologFX CONTROL = new MonologFX();
/*  96:164 */     for (String key : this.properties.keySet()) {
/*  97:165 */       switch (key)
/*  98:    */       {
/*  99:    */       case "type": 
/* 100:167 */         CONTROL.setType((MonologFX.Type)((ObjectProperty)this.properties.get(key)).get());
/* 101:168 */         break;
/* 102:    */       case "alignbuttons": 
/* 103:170 */         CONTROL.setButtonAlignment((MonologFX.ButtonAlignment)((ObjectProperty)this.properties.get(key)).get());
/* 104:171 */         break;
/* 105:    */       case "displayTime": 
/* 106:173 */         CONTROL.setDisplayTime(((IntegerProperty)this.properties.get(key)).get());
/* 107:174 */         break;
/* 108:    */       case "message": 
/* 109:176 */         CONTROL.setMessage((String)((StringProperty)this.properties.get(key)).get());
/* 110:177 */         break;
/* 111:    */       case "modal": 
/* 112:179 */         CONTROL.setModal(((BooleanProperty)this.properties.get(key)).get());
/* 113:180 */         break;
/* 114:    */       case "titleText": 
/* 115:182 */         CONTROL.setTitleText((String)((StringProperty)this.properties.get(key)).get());
/* 116:183 */         break;
/* 117:    */       case "xCoord": 
/* 118:185 */         CONTROL.setX(((DoubleProperty)this.properties.get(key)).get());
/* 119:186 */         break;
/* 120:    */       case "yCoord": 
/* 121:188 */         CONTROL.setY(((DoubleProperty)this.properties.get(key)).get());
/* 122:    */       }
/* 123:    */     }
/* 124:193 */     for (MonologFXButton mb : this.buttons) {
/* 125:194 */       CONTROL.addButton(mb);
/* 126:    */     }
/* 127:197 */     for (String ss : this.stylesheets) {
/* 128:198 */       CONTROL.addStylesheet(ss);
/* 129:    */     }
/* 130:201 */     return CONTROL;
/* 131:    */   }
/* 132:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     org.thehecklers.monologfx.MonologFXBuilder
 * JD-Core Version:    0.7.0.1
 */