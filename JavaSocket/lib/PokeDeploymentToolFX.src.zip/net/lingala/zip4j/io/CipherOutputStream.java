/*   1:    */ package net.lingala.zip4j.io;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.OutputStream;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.zip.CRC32;
/*   9:    */ import net.lingala.zip4j.core.HeaderWriter;
/*  10:    */ import net.lingala.zip4j.crypto.AESEncrpyter;
/*  11:    */ import net.lingala.zip4j.crypto.IEncrypter;
/*  12:    */ import net.lingala.zip4j.crypto.StandardEncrypter;
/*  13:    */ import net.lingala.zip4j.exception.ZipException;
/*  14:    */ import net.lingala.zip4j.model.AESExtraDataRecord;
/*  15:    */ import net.lingala.zip4j.model.CentralDirectory;
/*  16:    */ import net.lingala.zip4j.model.EndCentralDirRecord;
/*  17:    */ import net.lingala.zip4j.model.FileHeader;
/*  18:    */ import net.lingala.zip4j.model.LocalFileHeader;
/*  19:    */ import net.lingala.zip4j.model.ZipModel;
/*  20:    */ import net.lingala.zip4j.model.ZipParameters;
/*  21:    */ import net.lingala.zip4j.util.Raw;
/*  22:    */ import net.lingala.zip4j.util.Zip4jUtil;
/*  23:    */ 
/*  24:    */ public class CipherOutputStream
/*  25:    */   extends BaseOutputStream
/*  26:    */ {
/*  27:    */   protected OutputStream outputStream;
/*  28:    */   private File sourceFile;
/*  29:    */   protected FileHeader fileHeader;
/*  30:    */   protected LocalFileHeader localFileHeader;
/*  31:    */   private IEncrypter encrypter;
/*  32:    */   protected ZipParameters zipParameters;
/*  33:    */   protected ZipModel zipModel;
/*  34:    */   private long totalBytesWritten;
/*  35:    */   protected CRC32 crc;
/*  36:    */   private long bytesWrittenForThisFile;
/*  37:    */   private byte[] pendingBuffer;
/*  38:    */   private int pendingBufferLength;
/*  39:    */   private long totalBytesRead;
/*  40:    */   
/*  41:    */   public CipherOutputStream(OutputStream outputStream, ZipModel zipModel)
/*  42:    */   {
/*  43: 59 */     this.outputStream = outputStream;
/*  44: 60 */     initZipModel(zipModel);
/*  45: 61 */     this.crc = new CRC32();
/*  46: 62 */     this.totalBytesWritten = 0L;
/*  47: 63 */     this.bytesWrittenForThisFile = 0L;
/*  48: 64 */     this.pendingBuffer = new byte[16];
/*  49: 65 */     this.pendingBufferLength = 0;
/*  50: 66 */     this.totalBytesRead = 0L;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void putNextEntry(File file, ZipParameters zipParameters)
/*  54:    */     throws ZipException
/*  55:    */   {
/*  56: 70 */     if ((!zipParameters.isSourceExternalStream()) && (file == null)) {
/*  57: 71 */       throw new ZipException("input file is null");
/*  58:    */     }
/*  59: 74 */     if ((!zipParameters.isSourceExternalStream()) && (!Zip4jUtil.checkFileExists(file))) {
/*  60: 75 */       throw new ZipException("input file does not exist");
/*  61:    */     }
/*  62:    */     try
/*  63:    */     {
/*  64: 79 */       this.sourceFile = file;
/*  65:    */       
/*  66: 81 */       this.zipParameters = ((ZipParameters)zipParameters.clone());
/*  67: 83 */       if (!zipParameters.isSourceExternalStream())
/*  68:    */       {
/*  69: 84 */         if (this.sourceFile.isDirectory())
/*  70:    */         {
/*  71: 85 */           this.zipParameters.setEncryptFiles(false);
/*  72: 86 */           this.zipParameters.setEncryptionMethod(-1);
/*  73: 87 */           this.zipParameters.setCompressionMethod(0);
/*  74:    */         }
/*  75:    */       }
/*  76:    */       else
/*  77:    */       {
/*  78: 90 */         if (!Zip4jUtil.isStringNotNullAndNotEmpty(this.zipParameters.getFileNameInZip())) {
/*  79: 91 */           throw new ZipException("file name is empty for external stream");
/*  80:    */         }
/*  81: 93 */         if ((this.zipParameters.getFileNameInZip().endsWith("/")) || 
/*  82: 94 */           (this.zipParameters.getFileNameInZip().endsWith("\\")))
/*  83:    */         {
/*  84: 95 */           this.zipParameters.setEncryptFiles(false);
/*  85: 96 */           this.zipParameters.setEncryptionMethod(-1);
/*  86: 97 */           this.zipParameters.setCompressionMethod(0);
/*  87:    */         }
/*  88:    */       }
/*  89:101 */       createFileHeader();
/*  90:102 */       createLocalFileHeader();
/*  91:104 */       if ((this.zipModel.isSplitArchive()) && (
/*  92:105 */         (this.zipModel.getCentralDirectory() == null) || 
/*  93:106 */         (this.zipModel.getCentralDirectory().getFileHeaders() == null) || 
/*  94:107 */         (this.zipModel.getCentralDirectory().getFileHeaders().size() == 0)))
/*  95:    */       {
/*  96:108 */         byte[] intByte = new byte[4];
/*  97:109 */         Raw.writeIntLittleEndian(intByte, 0, 134695760);
/*  98:110 */         this.outputStream.write(intByte);
/*  99:111 */         this.totalBytesWritten += 4L;
/* 100:    */       }
/* 101:115 */       if ((this.outputStream instanceof SplitOutputStream))
/* 102:    */       {
/* 103:116 */         if (this.totalBytesWritten == 4L) {
/* 104:117 */           this.fileHeader.setOffsetLocalHeader(4L);
/* 105:    */         } else {
/* 106:119 */           this.fileHeader.setOffsetLocalHeader(((SplitOutputStream)this.outputStream).getFilePointer());
/* 107:    */         }
/* 108:    */       }
/* 109:122 */       else if (this.totalBytesWritten == 4L) {
/* 110:123 */         this.fileHeader.setOffsetLocalHeader(4L);
/* 111:    */       } else {
/* 112:125 */         this.fileHeader.setOffsetLocalHeader(this.totalBytesWritten);
/* 113:    */       }
/* 114:129 */       HeaderWriter headerWriter = new HeaderWriter();
/* 115:130 */       this.totalBytesWritten += headerWriter.writeLocalFileHeader(this.zipModel, this.localFileHeader, this.outputStream);
/* 116:132 */       if (this.zipParameters.isEncryptFiles())
/* 117:    */       {
/* 118:133 */         initEncrypter();
/* 119:134 */         if (this.encrypter != null) {
/* 120:135 */           if (zipParameters.getEncryptionMethod() == 0)
/* 121:    */           {
/* 122:136 */             byte[] headerBytes = ((StandardEncrypter)this.encrypter).getHeaderBytes();
/* 123:137 */             this.outputStream.write(headerBytes);
/* 124:138 */             this.totalBytesWritten += headerBytes.length;
/* 125:139 */             this.bytesWrittenForThisFile += headerBytes.length;
/* 126:    */           }
/* 127:140 */           else if (zipParameters.getEncryptionMethod() == 99)
/* 128:    */           {
/* 129:141 */             byte[] saltBytes = ((AESEncrpyter)this.encrypter).getSaltBytes();
/* 130:142 */             byte[] passwordVerifier = ((AESEncrpyter)this.encrypter).getDerivedPasswordVerifier();
/* 131:143 */             this.outputStream.write(saltBytes);
/* 132:144 */             this.outputStream.write(passwordVerifier);
/* 133:145 */             this.totalBytesWritten += saltBytes.length + passwordVerifier.length;
/* 134:146 */             this.bytesWrittenForThisFile += saltBytes.length + passwordVerifier.length;
/* 135:    */           }
/* 136:    */         }
/* 137:    */       }
/* 138:151 */       this.crc.reset();
/* 139:    */     }
/* 140:    */     catch (CloneNotSupportedException e)
/* 141:    */     {
/* 142:153 */       throw new ZipException(e);
/* 143:    */     }
/* 144:    */     catch (ZipException e)
/* 145:    */     {
/* 146:155 */       throw e;
/* 147:    */     }
/* 148:    */     catch (Exception e)
/* 149:    */     {
/* 150:157 */       throw new ZipException(e);
/* 151:    */     }
/* 152:    */   }
/* 153:    */   
/* 154:    */   private void initEncrypter()
/* 155:    */     throws ZipException
/* 156:    */   {
/* 157:162 */     if (!this.zipParameters.isEncryptFiles())
/* 158:    */     {
/* 159:163 */       this.encrypter = null;
/* 160:164 */       return;
/* 161:    */     }
/* 162:167 */     switch (this.zipParameters.getEncryptionMethod())
/* 163:    */     {
/* 164:    */     case 0: 
/* 165:170 */       this.encrypter = new StandardEncrypter(this.zipParameters.getPassword(), (this.localFileHeader.getLastModFileTime() & 0xFFFF) << 16);
/* 166:171 */       break;
/* 167:    */     case 99: 
/* 168:173 */       this.encrypter = new AESEncrpyter(this.zipParameters.getPassword(), this.zipParameters.getAesKeyStrength());
/* 169:174 */       break;
/* 170:    */     default: 
/* 171:176 */       throw new ZipException("invalid encprytion method");
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   private void initZipModel(ZipModel zipModel)
/* 176:    */   {
/* 177:181 */     if (zipModel == null) {
/* 178:182 */       this.zipModel = new ZipModel();
/* 179:    */     } else {
/* 180:184 */       this.zipModel = zipModel;
/* 181:    */     }
/* 182:187 */     if (this.zipModel.getEndCentralDirRecord() == null) {
/* 183:188 */       this.zipModel.setEndCentralDirRecord(new EndCentralDirRecord());
/* 184:    */     }
/* 185:190 */     if (this.zipModel.getCentralDirectory() == null) {
/* 186:191 */       this.zipModel.setCentralDirectory(new CentralDirectory());
/* 187:    */     }
/* 188:193 */     if (this.zipModel.getCentralDirectory().getFileHeaders() == null) {
/* 189:194 */       this.zipModel.getCentralDirectory().setFileHeaders(new ArrayList());
/* 190:    */     }
/* 191:196 */     if (this.zipModel.getLocalFileHeaderList() == null) {
/* 192:197 */       this.zipModel.setLocalFileHeaderList(new ArrayList());
/* 193:    */     }
/* 194:199 */     if (((this.outputStream instanceof SplitOutputStream)) && 
/* 195:200 */       (((SplitOutputStream)this.outputStream).isSplitZipFile()))
/* 196:    */     {
/* 197:201 */       this.zipModel.setSplitArchive(true);
/* 198:202 */       this.zipModel.setSplitLength(((SplitOutputStream)this.outputStream).getSplitLength());
/* 199:    */     }
/* 200:206 */     this.zipModel.getEndCentralDirRecord().setSignature(101010256L);
/* 201:    */   }
/* 202:    */   
/* 203:    */   public void write(int bval)
/* 204:    */     throws IOException
/* 205:    */   {
/* 206:210 */     byte[] b = new byte[1];
/* 207:211 */     b[0] = ((byte)bval);
/* 208:212 */     write(b, 0, 1);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public void write(byte[] b)
/* 212:    */     throws IOException
/* 213:    */   {
/* 214:216 */     if (b == null) {
/* 215:217 */       throw new NullPointerException();
/* 216:    */     }
/* 217:219 */     if (b.length == 0) {
/* 218:219 */       return;
/* 219:    */     }
/* 220:221 */     write(b, 0, b.length);
/* 221:    */   }
/* 222:    */   
/* 223:    */   public void write(byte[] b, int off, int len)
/* 224:    */     throws IOException
/* 225:    */   {
/* 226:225 */     if (len == 0) {
/* 227:225 */       return;
/* 228:    */     }
/* 229:227 */     if ((this.zipParameters.isEncryptFiles()) && 
/* 230:228 */       (this.zipParameters.getEncryptionMethod() == 99))
/* 231:    */     {
/* 232:229 */       if (this.pendingBufferLength != 0) {
/* 233:230 */         if (len >= 16 - this.pendingBufferLength)
/* 234:    */         {
/* 235:231 */           System.arraycopy(b, off, this.pendingBuffer, this.pendingBufferLength, 16 - this.pendingBufferLength);
/* 236:    */           
/* 237:233 */           encryptAndWrite(this.pendingBuffer, 0, this.pendingBuffer.length);
/* 238:234 */           off = 16 - this.pendingBufferLength;
/* 239:235 */           len -= off;
/* 240:236 */           this.pendingBufferLength = 0;
/* 241:    */         }
/* 242:    */         else
/* 243:    */         {
/* 244:238 */           System.arraycopy(b, off, this.pendingBuffer, this.pendingBufferLength, len);
/* 245:    */           
/* 246:240 */           this.pendingBufferLength += len;
/* 247:241 */           return;
/* 248:    */         }
/* 249:    */       }
/* 250:244 */       if ((len != 0) && (len % 16 != 0))
/* 251:    */       {
/* 252:245 */         System.arraycopy(b, len + off - len % 16, this.pendingBuffer, 0, len % 16);
/* 253:246 */         this.pendingBufferLength = (len % 16);
/* 254:247 */         len -= this.pendingBufferLength;
/* 255:    */       }
/* 256:    */     }
/* 257:250 */     if (len != 0) {
/* 258:251 */       encryptAndWrite(b, off, len);
/* 259:    */     }
/* 260:    */   }
/* 261:    */   
/* 262:    */   private void encryptAndWrite(byte[] b, int off, int len)
/* 263:    */     throws IOException
/* 264:    */   {
/* 265:255 */     if (this.encrypter != null) {
/* 266:    */       try
/* 267:    */       {
/* 268:257 */         this.encrypter.encryptData(b, off, len);
/* 269:    */       }
/* 270:    */       catch (ZipException e)
/* 271:    */       {
/* 272:259 */         throw new IOException(e.getMessage());
/* 273:    */       }
/* 274:    */     }
/* 275:262 */     this.outputStream.write(b, off, len);
/* 276:263 */     this.totalBytesWritten += len;
/* 277:264 */     this.bytesWrittenForThisFile += len;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public void closeEntry()
/* 281:    */     throws IOException, ZipException
/* 282:    */   {
/* 283:269 */     if (this.pendingBufferLength != 0)
/* 284:    */     {
/* 285:270 */       encryptAndWrite(this.pendingBuffer, 0, this.pendingBufferLength);
/* 286:271 */       this.pendingBufferLength = 0;
/* 287:    */     }
/* 288:274 */     if ((this.zipParameters.isEncryptFiles()) && 
/* 289:275 */       (this.zipParameters.getEncryptionMethod() == 99)) {
/* 290:276 */       if ((this.encrypter instanceof AESEncrpyter))
/* 291:    */       {
/* 292:277 */         this.outputStream.write(((AESEncrpyter)this.encrypter).getFinalMac());
/* 293:278 */         this.bytesWrittenForThisFile += 10L;
/* 294:279 */         this.totalBytesWritten += 10L;
/* 295:    */       }
/* 296:    */       else
/* 297:    */       {
/* 298:281 */         throw new ZipException("invalid encrypter for AES encrypted file");
/* 299:    */       }
/* 300:    */     }
/* 301:284 */     this.fileHeader.setCompressedSize(this.bytesWrittenForThisFile);
/* 302:285 */     this.localFileHeader.setCompressedSize(this.bytesWrittenForThisFile);
/* 303:287 */     if (this.zipParameters.isSourceExternalStream())
/* 304:    */     {
/* 305:288 */       this.fileHeader.setUncompressedSize(this.totalBytesRead);
/* 306:289 */       if (this.localFileHeader.getUncompressedSize() != this.totalBytesRead) {
/* 307:290 */         this.localFileHeader.setUncompressedSize(this.totalBytesRead);
/* 308:    */       }
/* 309:    */     }
/* 310:294 */     long crc32 = this.crc.getValue();
/* 311:295 */     if ((this.fileHeader.isEncrypted()) && 
/* 312:296 */       (this.fileHeader.getEncryptionMethod() == 99)) {
/* 313:297 */       crc32 = 0L;
/* 314:    */     }
/* 315:301 */     if ((this.zipParameters.isEncryptFiles()) && 
/* 316:302 */       (this.zipParameters.getEncryptionMethod() == 99))
/* 317:    */     {
/* 318:303 */       this.fileHeader.setCrc32(0L);
/* 319:304 */       this.localFileHeader.setCrc32(0L);
/* 320:    */     }
/* 321:    */     else
/* 322:    */     {
/* 323:306 */       this.fileHeader.setCrc32(crc32);
/* 324:307 */       this.localFileHeader.setCrc32(crc32);
/* 325:    */     }
/* 326:310 */     this.zipModel.getLocalFileHeaderList().add(this.localFileHeader);
/* 327:311 */     this.zipModel.getCentralDirectory().getFileHeaders().add(this.fileHeader);
/* 328:    */     
/* 329:313 */     HeaderWriter headerWriter = new HeaderWriter();
/* 330:314 */     this.totalBytesWritten += headerWriter.writeExtendedLocalHeader(this.localFileHeader, this.outputStream);
/* 331:    */     
/* 332:316 */     this.crc.reset();
/* 333:317 */     this.bytesWrittenForThisFile = 0L;
/* 334:318 */     this.encrypter = null;
/* 335:319 */     this.totalBytesRead = 0L;
/* 336:    */   }
/* 337:    */   
/* 338:    */   public void finish()
/* 339:    */     throws IOException, ZipException
/* 340:    */   {
/* 341:323 */     this.zipModel.getEndCentralDirRecord().setOffsetOfStartOfCentralDir(this.totalBytesWritten);
/* 342:    */     
/* 343:325 */     HeaderWriter headerWriter = new HeaderWriter();
/* 344:326 */     headerWriter.finalizeZipFile(this.zipModel, this.outputStream);
/* 345:    */   }
/* 346:    */   
/* 347:    */   public void close()
/* 348:    */     throws IOException
/* 349:    */   {
/* 350:330 */     if (this.outputStream != null) {
/* 351:331 */       this.outputStream.close();
/* 352:    */     }
/* 353:    */   }
/* 354:    */   
/* 355:    */   private void createFileHeader()
/* 356:    */     throws ZipException
/* 357:    */   {
/* 358:335 */     this.fileHeader = new FileHeader();
/* 359:336 */     this.fileHeader.setSignature(33639248);
/* 360:337 */     this.fileHeader.setVersionMadeBy(20);
/* 361:338 */     this.fileHeader.setVersionNeededToExtract(20);
/* 362:339 */     if ((this.zipParameters.isEncryptFiles()) && 
/* 363:340 */       (this.zipParameters.getEncryptionMethod() == 99))
/* 364:    */     {
/* 365:341 */       this.fileHeader.setCompressionMethod(99);
/* 366:342 */       this.fileHeader.setAesExtraDataRecord(generateAESExtraDataRecord(this.zipParameters));
/* 367:    */     }
/* 368:    */     else
/* 369:    */     {
/* 370:344 */       this.fileHeader.setCompressionMethod(this.zipParameters.getCompressionMethod());
/* 371:    */     }
/* 372:346 */     if (this.zipParameters.isEncryptFiles())
/* 373:    */     {
/* 374:347 */       this.fileHeader.setEncrypted(true);
/* 375:348 */       this.fileHeader.setEncryptionMethod(this.zipParameters.getEncryptionMethod());
/* 376:    */     }
/* 377:350 */     String fileName = null;
/* 378:351 */     if (this.zipParameters.isSourceExternalStream())
/* 379:    */     {
/* 380:352 */       this.fileHeader.setLastModFileTime((int)Zip4jUtil.javaToDosTime(System.currentTimeMillis()));
/* 381:353 */       if (!Zip4jUtil.isStringNotNullAndNotEmpty(this.zipParameters.getFileNameInZip())) {
/* 382:354 */         throw new ZipException("fileNameInZip is null or empty");
/* 383:    */       }
/* 384:356 */       fileName = this.zipParameters.getFileNameInZip();
/* 385:    */     }
/* 386:    */     else
/* 387:    */     {
/* 388:358 */       this.fileHeader.setLastModFileTime((int)Zip4jUtil.javaToDosTime(Zip4jUtil.getLastModifiedFileTime(this.sourceFile, this.zipParameters
/* 389:359 */         .getTimeZone())));
/* 390:360 */       this.fileHeader.setUncompressedSize(this.sourceFile.length());
/* 391:361 */       fileName = Zip4jUtil.getRelativeFileName(this.sourceFile
/* 392:362 */         .getAbsolutePath(), this.zipParameters.getRootFolderInZip(), this.zipParameters.getDefaultFolderPath());
/* 393:    */     }
/* 394:366 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(fileName)) {
/* 395:367 */       throw new ZipException("fileName is null or empty. unable to create file header");
/* 396:    */     }
/* 397:370 */     this.fileHeader.setFileName(fileName);
/* 398:372 */     if (Zip4jUtil.isStringNotNullAndNotEmpty(this.zipModel.getFileNameCharset())) {
/* 399:373 */       this.fileHeader.setFileNameLength(Zip4jUtil.getEncodedStringLength(fileName, this.zipModel
/* 400:374 */         .getFileNameCharset()));
/* 401:    */     } else {
/* 402:376 */       this.fileHeader.setFileNameLength(Zip4jUtil.getEncodedStringLength(fileName));
/* 403:    */     }
/* 404:379 */     if ((this.outputStream instanceof SplitOutputStream)) {
/* 405:380 */       this.fileHeader.setDiskNumberStart(((SplitOutputStream)this.outputStream).getCurrSplitFileCounter());
/* 406:    */     } else {
/* 407:382 */       this.fileHeader.setDiskNumberStart(0);
/* 408:    */     }
/* 409:385 */     int fileAttrs = 0;
/* 410:386 */     if (!this.zipParameters.isSourceExternalStream()) {
/* 411:387 */       fileAttrs = getFileAttributes(this.sourceFile);
/* 412:    */     }
/* 413:388 */     byte[] externalFileAttrs = { (byte)fileAttrs, 0, 0, 0 };
/* 414:389 */     this.fileHeader.setExternalFileAttr(externalFileAttrs);
/* 415:391 */     if (this.zipParameters.isSourceExternalStream()) {
/* 416:392 */       this.fileHeader.setDirectory((fileName.endsWith("/")) || (fileName.endsWith("\\")));
/* 417:    */     } else {
/* 418:394 */       this.fileHeader.setDirectory(this.sourceFile.isDirectory());
/* 419:    */     }
/* 420:396 */     if (this.fileHeader.isDirectory())
/* 421:    */     {
/* 422:397 */       this.fileHeader.setCompressedSize(0L);
/* 423:398 */       this.fileHeader.setUncompressedSize(0L);
/* 424:    */     }
/* 425:400 */     else if (!this.zipParameters.isSourceExternalStream())
/* 426:    */     {
/* 427:401 */       long fileSize = Zip4jUtil.getFileLengh(this.sourceFile);
/* 428:402 */       if (this.zipParameters.getCompressionMethod() == 0)
/* 429:    */       {
/* 430:403 */         if (this.zipParameters.getEncryptionMethod() == 0)
/* 431:    */         {
/* 432:404 */           this.fileHeader.setCompressedSize(fileSize + 12L);
/* 433:    */         }
/* 434:406 */         else if (this.zipParameters.getEncryptionMethod() == 99)
/* 435:    */         {
/* 436:407 */           int saltLength = 0;
/* 437:408 */           switch (this.zipParameters.getAesKeyStrength())
/* 438:    */           {
/* 439:    */           case 1: 
/* 440:410 */             saltLength = 8;
/* 441:411 */             break;
/* 442:    */           case 3: 
/* 443:413 */             saltLength = 16;
/* 444:414 */             break;
/* 445:    */           default: 
/* 446:416 */             throw new ZipException("invalid aes key strength, cannot determine key sizes");
/* 447:    */           }
/* 448:418 */           this.fileHeader.setCompressedSize(fileSize + saltLength + 10L + 2L);
/* 449:    */         }
/* 450:    */         else
/* 451:    */         {
/* 452:421 */           this.fileHeader.setCompressedSize(0L);
/* 453:    */         }
/* 454:    */       }
/* 455:    */       else {
/* 456:424 */         this.fileHeader.setCompressedSize(0L);
/* 457:    */       }
/* 458:426 */       this.fileHeader.setUncompressedSize(fileSize);
/* 459:    */     }
/* 460:429 */     if ((this.zipParameters.isEncryptFiles()) && 
/* 461:430 */       (this.zipParameters.getEncryptionMethod() == 0)) {
/* 462:431 */       this.fileHeader.setCrc32(this.zipParameters.getSourceFileCRC());
/* 463:    */     }
/* 464:433 */     byte[] shortByte = new byte[2];
/* 465:434 */     shortByte[0] = Raw.bitArrayToByte(generateGeneralPurposeBitArray(this.fileHeader
/* 466:435 */       .isEncrypted(), this.zipParameters.getCompressionMethod()));
/* 467:436 */     boolean isFileNameCharsetSet = Zip4jUtil.isStringNotNullAndNotEmpty(this.zipModel.getFileNameCharset());
/* 468:437 */     if ((!isFileNameCharsetSet) || 
/* 469:438 */       (!this.zipModel.getFileNameCharset().equalsIgnoreCase("UTF8")))
/* 470:    */     {
/* 471:438 */       if (!isFileNameCharsetSet) {
/* 472:440 */         if (!Zip4jUtil.detectCharSet(this.fileHeader.getFileName()).equals("UTF8")) {}
/* 473:    */       }
/* 474:    */     }
/* 475:    */     else
/* 476:    */     {
/* 477:441 */       shortByte[1] = 8;
/* 478:    */       break label814;
/* 479:    */     }
/* 480:443 */     shortByte[1] = 0;
/* 481:    */     label814:
/* 482:445 */     this.fileHeader.setGeneralPurposeFlag(shortByte);
/* 483:    */   }
/* 484:    */   
/* 485:    */   private void createLocalFileHeader()
/* 486:    */     throws ZipException
/* 487:    */   {
/* 488:449 */     if (this.fileHeader == null) {
/* 489:450 */       throw new ZipException("file header is null, cannot create local file header");
/* 490:    */     }
/* 491:452 */     this.localFileHeader = new LocalFileHeader();
/* 492:453 */     this.localFileHeader.setSignature(67324752);
/* 493:454 */     this.localFileHeader.setVersionNeededToExtract(this.fileHeader.getVersionNeededToExtract());
/* 494:455 */     this.localFileHeader.setCompressionMethod(this.fileHeader.getCompressionMethod());
/* 495:456 */     this.localFileHeader.setLastModFileTime(this.fileHeader.getLastModFileTime());
/* 496:457 */     this.localFileHeader.setUncompressedSize(this.fileHeader.getUncompressedSize());
/* 497:458 */     this.localFileHeader.setFileNameLength(this.fileHeader.getFileNameLength());
/* 498:459 */     this.localFileHeader.setFileName(this.fileHeader.getFileName());
/* 499:460 */     this.localFileHeader.setEncrypted(this.fileHeader.isEncrypted());
/* 500:461 */     this.localFileHeader.setEncryptionMethod(this.fileHeader.getEncryptionMethod());
/* 501:462 */     this.localFileHeader.setAesExtraDataRecord(this.fileHeader.getAesExtraDataRecord());
/* 502:463 */     this.localFileHeader.setCrc32(this.fileHeader.getCrc32());
/* 503:464 */     this.localFileHeader.setCompressedSize(this.fileHeader.getCompressedSize());
/* 504:465 */     this.localFileHeader.setGeneralPurposeFlag((byte[])this.fileHeader.getGeneralPurposeFlag().clone());
/* 505:    */   }
/* 506:    */   
/* 507:    */   private int getFileAttributes(File file)
/* 508:    */     throws ZipException
/* 509:    */   {
/* 510:475 */     if (file == null) {
/* 511:476 */       throw new ZipException("input file is null, cannot get file attributes");
/* 512:    */     }
/* 513:479 */     if (!file.exists()) {
/* 514:480 */       return 0;
/* 515:    */     }
/* 516:483 */     if (file.isDirectory())
/* 517:    */     {
/* 518:484 */       if (file.isHidden()) {
/* 519:485 */         return 18;
/* 520:    */       }
/* 521:487 */       return 16;
/* 522:    */     }
/* 523:490 */     if ((!file.canWrite()) && (file.isHidden())) {
/* 524:491 */       return 3;
/* 525:    */     }
/* 526:492 */     if (!file.canWrite()) {
/* 527:493 */       return 1;
/* 528:    */     }
/* 529:494 */     if (file.isHidden()) {
/* 530:495 */       return 2;
/* 531:    */     }
/* 532:497 */     return 0;
/* 533:    */   }
/* 534:    */   
/* 535:    */   private int[] generateGeneralPurposeBitArray(boolean isEncrpyted, int compressionMethod)
/* 536:    */   {
/* 537:504 */     int[] generalPurposeBits = new int[8];
/* 538:505 */     if (isEncrpyted) {
/* 539:506 */       generalPurposeBits[0] = 1;
/* 540:    */     } else {
/* 541:508 */       generalPurposeBits[0] = 0;
/* 542:    */     }
/* 543:511 */     if (compressionMethod != 8)
/* 544:    */     {
/* 545:514 */       generalPurposeBits[1] = 0;
/* 546:515 */       generalPurposeBits[2] = 0;
/* 547:    */     }
/* 548:518 */     generalPurposeBits[3] = 1;
/* 549:    */     
/* 550:520 */     return generalPurposeBits;
/* 551:    */   }
/* 552:    */   
/* 553:    */   private AESExtraDataRecord generateAESExtraDataRecord(ZipParameters parameters)
/* 554:    */     throws ZipException
/* 555:    */   {
/* 556:525 */     if (parameters == null) {
/* 557:526 */       throw new ZipException("zip parameters are null, cannot generate AES Extra Data record");
/* 558:    */     }
/* 559:529 */     AESExtraDataRecord aesDataRecord = new AESExtraDataRecord();
/* 560:530 */     aesDataRecord.setSignature(39169L);
/* 561:531 */     aesDataRecord.setDataSize(7);
/* 562:532 */     aesDataRecord.setVendorID("AE");
/* 563:    */     
/* 564:    */ 
/* 565:    */ 
/* 566:536 */     aesDataRecord.setVersionNumber(2);
/* 567:537 */     if (parameters.getAesKeyStrength() == 1) {
/* 568:538 */       aesDataRecord.setAesStrength(1);
/* 569:539 */     } else if (parameters.getAesKeyStrength() == 3) {
/* 570:540 */       aesDataRecord.setAesStrength(3);
/* 571:    */     } else {
/* 572:542 */       throw new ZipException("invalid AES key strength, cannot generate AES Extra data record");
/* 573:    */     }
/* 574:544 */     aesDataRecord.setCompressionMethod(parameters.getCompressionMethod());
/* 575:    */     
/* 576:546 */     return aesDataRecord;
/* 577:    */   }
/* 578:    */   
/* 579:    */   public void decrementCompressedFileSize(int value)
/* 580:    */   {
/* 581:550 */     if (value <= 0) {
/* 582:550 */       return;
/* 583:    */     }
/* 584:552 */     if (value <= this.bytesWrittenForThisFile) {
/* 585:553 */       this.bytesWrittenForThisFile -= value;
/* 586:    */     }
/* 587:    */   }
/* 588:    */   
/* 589:    */   protected void updateTotalBytesRead(int toUpdate)
/* 590:    */   {
/* 591:558 */     if (toUpdate > 0) {
/* 592:559 */       this.totalBytesRead += toUpdate;
/* 593:    */     }
/* 594:    */   }
/* 595:    */   
/* 596:    */   public void setSourceFile(File sourceFile)
/* 597:    */   {
/* 598:564 */     this.sourceFile = sourceFile;
/* 599:    */   }
/* 600:    */   
/* 601:    */   public File getSourceFile()
/* 602:    */   {
/* 603:568 */     return this.sourceFile;
/* 604:    */   }
/* 605:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.io.CipherOutputStream
 * JD-Core Version:    0.7.0.1
 */