/*  1:   */ package net.lingala.zip4j.io;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.io.OutputStream;
/*  5:   */ import java.util.zip.CRC32;
/*  6:   */ import net.lingala.zip4j.model.ZipModel;
/*  7:   */ 
/*  8:   */ public class ZipOutputStream
/*  9:   */   extends DeflaterOutputStream
/* 10:   */ {
/* 11:   */   public ZipOutputStream(OutputStream outputStream)
/* 12:   */   {
/* 13:11 */     this(outputStream, null);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public ZipOutputStream(OutputStream outputStream, ZipModel zipModel)
/* 17:   */   {
/* 18:15 */     super(outputStream, zipModel);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void write(int bval)
/* 22:   */     throws IOException
/* 23:   */   {
/* 24:19 */     byte[] b = new byte[1];
/* 25:20 */     b[0] = ((byte)bval);
/* 26:21 */     write(b, 0, 1);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void write(byte[] b)
/* 30:   */     throws IOException
/* 31:   */   {
/* 32:25 */     write(b, 0, b.length);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void write(byte[] b, int off, int len)
/* 36:   */     throws IOException
/* 37:   */   {
/* 38:29 */     this.crc.update(b, off, len);
/* 39:30 */     updateTotalBytesRead(len);
/* 40:31 */     super.write(b, off, len);
/* 41:   */   }
/* 42:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.io.ZipOutputStream
 * JD-Core Version:    0.7.0.1
 */