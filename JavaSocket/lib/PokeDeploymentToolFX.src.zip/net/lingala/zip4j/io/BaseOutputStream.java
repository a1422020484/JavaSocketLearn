package net.lingala.zip4j.io;

import java.io.IOException;
import java.io.OutputStream;

public abstract class BaseOutputStream
  extends OutputStream
{
  public void write(int b)
    throws IOException
  {}
}


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.io.BaseOutputStream
 * JD-Core Version:    0.7.0.1
 */