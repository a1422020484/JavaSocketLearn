/*   1:    */ package net.lingala.zip4j.io;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.OutputStream;
/*   6:    */ import java.util.zip.Deflater;
/*   7:    */ import net.lingala.zip4j.exception.ZipException;
/*   8:    */ import net.lingala.zip4j.model.ZipModel;
/*   9:    */ import net.lingala.zip4j.model.ZipParameters;
/*  10:    */ 
/*  11:    */ public class DeflaterOutputStream
/*  12:    */   extends CipherOutputStream
/*  13:    */ {
/*  14:    */   private byte[] buff;
/*  15:    */   protected Deflater deflater;
/*  16:    */   private boolean firstBytesRead;
/*  17:    */   
/*  18:    */   public DeflaterOutputStream(OutputStream outputStream, ZipModel zipModel)
/*  19:    */   {
/*  20: 37 */     super(outputStream, zipModel);
/*  21: 38 */     this.deflater = new Deflater();
/*  22: 39 */     this.buff = new byte[4096];
/*  23: 40 */     this.firstBytesRead = false;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public void putNextEntry(File file, ZipParameters zipParameters)
/*  27:    */     throws ZipException
/*  28:    */   {
/*  29: 45 */     super.putNextEntry(file, zipParameters);
/*  30: 46 */     if (zipParameters.getCompressionMethod() == 8)
/*  31:    */     {
/*  32: 47 */       this.deflater.reset();
/*  33: 48 */       if (((zipParameters.getCompressionLevel() < 0) || 
/*  34: 49 */         (zipParameters.getCompressionLevel() > 9)) && 
/*  35: 50 */         (zipParameters.getCompressionLevel() != -1)) {
/*  36: 51 */         throw new ZipException("invalid compression level for deflater. compression level should be in the range of 0-9");
/*  37:    */       }
/*  38: 54 */       this.deflater.setLevel(zipParameters.getCompressionLevel());
/*  39:    */     }
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void write(byte[] b)
/*  43:    */     throws IOException
/*  44:    */   {
/*  45: 59 */     write(b, 0, b.length);
/*  46:    */   }
/*  47:    */   
/*  48:    */   private void deflate()
/*  49:    */     throws IOException
/*  50:    */   {
/*  51: 63 */     int len = this.deflater.deflate(this.buff, 0, this.buff.length);
/*  52: 64 */     if (len > 0)
/*  53:    */     {
/*  54: 65 */       if (this.deflater.finished())
/*  55:    */       {
/*  56: 66 */         if (len == 4) {
/*  57: 66 */           return;
/*  58:    */         }
/*  59: 67 */         if (len < 4)
/*  60:    */         {
/*  61: 68 */           decrementCompressedFileSize(4 - len);
/*  62: 69 */           return;
/*  63:    */         }
/*  64: 71 */         len -= 4;
/*  65:    */       }
/*  66: 73 */       if (!this.firstBytesRead)
/*  67:    */       {
/*  68: 74 */         super.write(this.buff, 2, len - 2);
/*  69: 75 */         this.firstBytesRead = true;
/*  70:    */       }
/*  71:    */       else
/*  72:    */       {
/*  73: 77 */         super.write(this.buff, 0, len);
/*  74:    */       }
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void write(int bval)
/*  79:    */     throws IOException
/*  80:    */   {
/*  81: 83 */     byte[] b = new byte[1];
/*  82: 84 */     b[0] = ((byte)bval);
/*  83: 85 */     write(b, 0, 1);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void write(byte[] buf, int off, int len)
/*  87:    */     throws IOException
/*  88:    */   {
/*  89: 89 */     if (this.zipParameters.getCompressionMethod() != 8)
/*  90:    */     {
/*  91: 90 */       super.write(buf, off, len);
/*  92:    */     }
/*  93:    */     else
/*  94:    */     {
/*  95: 92 */       this.deflater.setInput(buf, off, len);
/*  96: 93 */       while (!this.deflater.needsInput()) {
/*  97: 94 */         deflate();
/*  98:    */       }
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void closeEntry()
/* 103:    */     throws IOException, ZipException
/* 104:    */   {
/* 105:100 */     if (this.zipParameters.getCompressionMethod() == 8)
/* 106:    */     {
/* 107:101 */       if (!this.deflater.finished())
/* 108:    */       {
/* 109:102 */         this.deflater.finish();
/* 110:103 */         while (!this.deflater.finished()) {
/* 111:104 */           deflate();
/* 112:    */         }
/* 113:    */       }
/* 114:107 */       this.firstBytesRead = false;
/* 115:    */     }
/* 116:109 */     super.closeEntry();
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void finish()
/* 120:    */     throws IOException, ZipException
/* 121:    */   {
/* 122:113 */     super.finish();
/* 123:    */   }
/* 124:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.io.DeflaterOutputStream
 * JD-Core Version:    0.7.0.1
 */