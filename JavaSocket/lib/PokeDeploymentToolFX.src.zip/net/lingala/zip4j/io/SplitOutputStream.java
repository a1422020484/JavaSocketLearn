/*   1:    */ package net.lingala.zip4j.io;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileNotFoundException;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.OutputStream;
/*   7:    */ import java.io.RandomAccessFile;
/*   8:    */ import net.lingala.zip4j.exception.ZipException;
/*   9:    */ import net.lingala.zip4j.util.Raw;
/*  10:    */ import net.lingala.zip4j.util.Zip4jUtil;
/*  11:    */ 
/*  12:    */ public class SplitOutputStream
/*  13:    */   extends OutputStream
/*  14:    */ {
/*  15:    */   private RandomAccessFile raf;
/*  16:    */   private long splitLength;
/*  17:    */   private File zipFile;
/*  18:    */   private File outFile;
/*  19:    */   private int currSplitFileCounter;
/*  20:    */   private long bytesWrittenForThisPart;
/*  21:    */   
/*  22:    */   public SplitOutputStream(String name)
/*  23:    */     throws FileNotFoundException, ZipException
/*  24:    */   {
/*  25: 40 */     this(Zip4jUtil.isStringNotNullAndNotEmpty(name) ? new File(name) : null);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public SplitOutputStream(File file)
/*  29:    */     throws FileNotFoundException, ZipException
/*  30:    */   {
/*  31: 45 */     this(file, -1L);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public SplitOutputStream(String name, long splitLength)
/*  35:    */     throws FileNotFoundException, ZipException
/*  36:    */   {
/*  37: 49 */     this(!Zip4jUtil.isStringNotNullAndNotEmpty(name) ? new File(name) : null, splitLength);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public SplitOutputStream(File file, long splitLength)
/*  41:    */     throws FileNotFoundException, ZipException
/*  42:    */   {
/*  43: 54 */     if ((splitLength >= 0L) && (splitLength < 65536L)) {
/*  44: 55 */       throw new ZipException("split length less than minimum allowed split length of 65536 Bytes");
/*  45:    */     }
/*  46: 57 */     this.raf = new RandomAccessFile(file, "rw");
/*  47: 58 */     this.splitLength = splitLength;
/*  48: 59 */     this.outFile = file;
/*  49: 60 */     this.zipFile = file;
/*  50: 61 */     this.currSplitFileCounter = 0;
/*  51: 62 */     this.bytesWrittenForThisPart = 0L;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void write(int b)
/*  55:    */     throws IOException
/*  56:    */   {
/*  57: 66 */     byte[] buff = new byte[1];
/*  58: 67 */     buff[0] = ((byte)b);
/*  59: 68 */     write(buff, 0, 1);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void write(byte[] b)
/*  63:    */     throws IOException
/*  64:    */   {
/*  65: 72 */     write(b, 0, b.length);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void write(byte[] b, int off, int len)
/*  69:    */     throws IOException
/*  70:    */   {
/*  71: 76 */     if (len <= 0) {
/*  72: 76 */       return;
/*  73:    */     }
/*  74: 78 */     if (this.splitLength != -1L)
/*  75:    */     {
/*  76: 80 */       if (this.splitLength < 65536L) {
/*  77: 81 */         throw new IOException("split length less than minimum allowed split length of 65536 Bytes");
/*  78:    */       }
/*  79: 84 */       if (this.bytesWrittenForThisPart >= this.splitLength)
/*  80:    */       {
/*  81: 85 */         startNextSplitFile();
/*  82: 86 */         this.raf.write(b, off, len);
/*  83: 87 */         this.bytesWrittenForThisPart = len;
/*  84:    */       }
/*  85: 88 */       else if (this.bytesWrittenForThisPart + len > this.splitLength)
/*  86:    */       {
/*  87: 89 */         if (isHeaderData(b))
/*  88:    */         {
/*  89: 90 */           startNextSplitFile();
/*  90: 91 */           this.raf.write(b, off, len);
/*  91: 92 */           this.bytesWrittenForThisPart = len;
/*  92:    */         }
/*  93:    */         else
/*  94:    */         {
/*  95: 94 */           this.raf.write(b, off, (int)(this.splitLength - this.bytesWrittenForThisPart));
/*  96: 95 */           startNextSplitFile();
/*  97: 96 */           this.raf.write(b, off + (int)(this.splitLength - this.bytesWrittenForThisPart), (int)(len - (this.splitLength - this.bytesWrittenForThisPart)));
/*  98: 97 */           this.bytesWrittenForThisPart = (len - (this.splitLength - this.bytesWrittenForThisPart));
/*  99:    */         }
/* 100:    */       }
/* 101:    */       else
/* 102:    */       {
/* 103:100 */         this.raf.write(b, off, len);
/* 104:101 */         this.bytesWrittenForThisPart += len;
/* 105:    */       }
/* 106:    */     }
/* 107:    */     else
/* 108:    */     {
/* 109:105 */       this.raf.write(b, off, len);
/* 110:106 */       this.bytesWrittenForThisPart += len;
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   private void startNextSplitFile()
/* 115:    */     throws IOException
/* 116:    */   {
/* 117:    */     try
/* 118:    */     {
/* 119:113 */       String zipFileWithoutExt = Zip4jUtil.getZipFileNameWithoutExt(this.outFile.getName());
/* 120:114 */       File currSplitFile = null;
/* 121:115 */       String zipFileName = this.zipFile.getAbsolutePath();
/* 122:116 */       String parentPath = this.outFile.getParent() + System.getProperty("file.separator");
/* 123:118 */       if (this.currSplitFileCounter < 9) {
/* 124:119 */         currSplitFile = new File(parentPath + zipFileWithoutExt + ".z0" + (this.currSplitFileCounter + 1));
/* 125:    */       } else {
/* 126:121 */         currSplitFile = new File(parentPath + zipFileWithoutExt + ".z" + (this.currSplitFileCounter + 1));
/* 127:    */       }
/* 128:124 */       this.raf.close();
/* 129:126 */       if (currSplitFile.exists()) {
/* 130:127 */         throw new IOException("split file: " + currSplitFile.getName() + " already exists in the current directory, cannot rename this file");
/* 131:    */       }
/* 132:130 */       if (!this.zipFile.renameTo(currSplitFile)) {
/* 133:131 */         throw new IOException("cannot rename newly created split file");
/* 134:    */       }
/* 135:134 */       this.zipFile = new File(zipFileName);
/* 136:135 */       this.raf = new RandomAccessFile(this.zipFile, "rw");
/* 137:136 */       this.currSplitFileCounter += 1;
/* 138:    */     }
/* 139:    */     catch (ZipException e)
/* 140:    */     {
/* 141:138 */       throw new IOException(e.getMessage());
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   private boolean isHeaderData(byte[] buff)
/* 146:    */   {
/* 147:143 */     if ((buff == null) || (buff.length < 4)) {
/* 148:144 */       return false;
/* 149:    */     }
/* 150:147 */     int signature = Raw.readIntLittleEndian(buff, 0);
/* 151:148 */     long[] allHeaderSignatures = Zip4jUtil.getAllHeaderSignatures();
/* 152:149 */     if ((allHeaderSignatures != null) && (allHeaderSignatures.length > 0)) {
/* 153:150 */       for (int i = 0; i < allHeaderSignatures.length; i++) {
/* 154:152 */         if ((allHeaderSignatures[i] != 134695760L) && (allHeaderSignatures[i] == signature)) {
/* 155:154 */           return true;
/* 156:    */         }
/* 157:    */       }
/* 158:    */     }
/* 159:159 */     return false;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public boolean checkBuffSizeAndStartNextSplitFile(int bufferSize)
/* 163:    */     throws ZipException
/* 164:    */   {
/* 165:170 */     if (bufferSize < 0) {
/* 166:171 */       throw new ZipException("negative buffersize for checkBuffSizeAndStartNextSplitFile");
/* 167:    */     }
/* 168:174 */     if (!isBuffSizeFitForCurrSplitFile(bufferSize)) {
/* 169:    */       try
/* 170:    */       {
/* 171:176 */         startNextSplitFile();
/* 172:177 */         this.bytesWrittenForThisPart = 0L;
/* 173:178 */         return true;
/* 174:    */       }
/* 175:    */       catch (IOException e)
/* 176:    */       {
/* 177:180 */         throw new ZipException(e);
/* 178:    */       }
/* 179:    */     }
/* 180:184 */     return false;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public boolean isBuffSizeFitForCurrSplitFile(int bufferSize)
/* 184:    */     throws ZipException
/* 185:    */   {
/* 186:195 */     if (bufferSize < 0) {
/* 187:196 */       throw new ZipException("negative buffersize for isBuffSizeFitForCurrSplitFile");
/* 188:    */     }
/* 189:199 */     if (this.splitLength >= 65536L) {
/* 190:200 */       return this.bytesWrittenForThisPart + bufferSize <= this.splitLength;
/* 191:    */     }
/* 192:203 */     return true;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void seek(long pos)
/* 196:    */     throws IOException
/* 197:    */   {
/* 198:208 */     this.raf.seek(pos);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public void close()
/* 202:    */     throws IOException
/* 203:    */   {
/* 204:212 */     if (this.raf != null) {
/* 205:213 */       this.raf.close();
/* 206:    */     }
/* 207:    */   }
/* 208:    */   
/* 209:    */   public void flush()
/* 210:    */     throws IOException
/* 211:    */   {}
/* 212:    */   
/* 213:    */   public long getFilePointer()
/* 214:    */     throws IOException
/* 215:    */   {
/* 216:220 */     return this.raf.getFilePointer();
/* 217:    */   }
/* 218:    */   
/* 219:    */   public boolean isSplitZipFile()
/* 220:    */   {
/* 221:224 */     return this.splitLength != -1L;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public long getSplitLength()
/* 225:    */   {
/* 226:228 */     return this.splitLength;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public int getCurrSplitFileCounter()
/* 230:    */   {
/* 231:232 */     return this.currSplitFileCounter;
/* 232:    */   }
/* 233:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.io.SplitOutputStream
 * JD-Core Version:    0.7.0.1
 */