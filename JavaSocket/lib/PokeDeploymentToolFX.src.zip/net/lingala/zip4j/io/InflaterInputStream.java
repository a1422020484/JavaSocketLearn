/*   1:    */ package net.lingala.zip4j.io;
/*   2:    */ 
/*   3:    */ import java.io.EOFException;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.RandomAccessFile;
/*   6:    */ import java.util.zip.DataFormatException;
/*   7:    */ import java.util.zip.Inflater;
/*   8:    */ import net.lingala.zip4j.model.FileHeader;
/*   9:    */ import net.lingala.zip4j.model.LocalFileHeader;
/*  10:    */ import net.lingala.zip4j.unzip.UnzipEngine;
/*  11:    */ 
/*  12:    */ public class InflaterInputStream
/*  13:    */   extends PartInputStream
/*  14:    */ {
/*  15:    */   private Inflater inflater;
/*  16:    */   private byte[] buff;
/*  17: 33 */   private byte[] oneByteBuff = new byte[1];
/*  18:    */   private UnzipEngine unzipEngine;
/*  19:    */   private long bytesWritten;
/*  20:    */   private long uncompressedSize;
/*  21:    */   
/*  22:    */   public InflaterInputStream(RandomAccessFile raf, long start, long len, UnzipEngine unzipEngine)
/*  23:    */   {
/*  24: 39 */     super(raf, start, len, unzipEngine);
/*  25: 40 */     this.inflater = new Inflater(true);
/*  26: 41 */     this.buff = new byte[4096];
/*  27: 42 */     this.unzipEngine = unzipEngine;
/*  28: 43 */     this.bytesWritten = 0L;
/*  29: 44 */     this.uncompressedSize = unzipEngine.getFileHeader().getUncompressedSize();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public int read()
/*  33:    */     throws IOException
/*  34:    */   {
/*  35: 48 */     return read(this.oneByteBuff, 0, 1) == -1 ? -1 : this.oneByteBuff[0] & 0xFF;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public int read(byte[] b)
/*  39:    */     throws IOException
/*  40:    */   {
/*  41: 52 */     if (b == null) {
/*  42: 53 */       throw new NullPointerException("input buffer is null");
/*  43:    */     }
/*  44: 56 */     return read(b, 0, b.length);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int read(byte[] b, int off, int len)
/*  48:    */     throws IOException
/*  49:    */   {
/*  50: 61 */     if (b == null) {
/*  51: 62 */       throw new NullPointerException("input buffer is null");
/*  52:    */     }
/*  53: 63 */     if ((off < 0) || (len < 0) || (len > b.length - off)) {
/*  54: 64 */       throw new IndexOutOfBoundsException();
/*  55:    */     }
/*  56: 65 */     if (len == 0) {
/*  57: 66 */       return 0;
/*  58:    */     }
/*  59:    */     try
/*  60:    */     {
/*  61: 71 */       if (this.bytesWritten >= this.uncompressedSize)
/*  62:    */       {
/*  63: 72 */         finishInflating();
/*  64: 73 */         return -1;
/*  65:    */       }
/*  66:    */       int n;
/*  67: 75 */       while ((n = this.inflater.inflate(b, off, len)) == 0)
/*  68:    */       {
/*  69: 76 */         if ((this.inflater.finished()) || (this.inflater.needsDictionary()))
/*  70:    */         {
/*  71: 77 */           finishInflating();
/*  72: 78 */           return -1;
/*  73:    */         }
/*  74: 80 */         if (this.inflater.needsInput()) {
/*  75: 81 */           fill();
/*  76:    */         }
/*  77:    */       }
/*  78: 84 */       this.bytesWritten += n;
/*  79: 85 */       return n;
/*  80:    */     }
/*  81:    */     catch (DataFormatException e)
/*  82:    */     {
/*  83: 87 */       String s = "Invalid ZLIB data format";
/*  84: 88 */       if (e.getMessage() != null) {
/*  85: 89 */         s = e.getMessage();
/*  86:    */       }
/*  87: 91 */       if ((this.unzipEngine != null) && 
/*  88: 92 */         (this.unzipEngine.getLocalFileHeader().isEncrypted()) && 
/*  89: 93 */         (this.unzipEngine.getLocalFileHeader().getEncryptionMethod() == 0)) {
/*  90: 94 */         s = s + " - Wrong Password?";
/*  91:    */       }
/*  92: 97 */       throw new IOException(s);
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   private void finishInflating()
/*  97:    */     throws IOException
/*  98:    */   {
/*  99:104 */     byte[] b = new byte[1024];
/* 100:105 */     while (super.read(b, 0, 1024) != -1) {}
/* 101:108 */     checkAndReadAESMacBytes();
/* 102:    */   }
/* 103:    */   
/* 104:    */   private void fill()
/* 105:    */     throws IOException
/* 106:    */   {
/* 107:112 */     int len = super.read(this.buff, 0, this.buff.length);
/* 108:113 */     if (len == -1) {
/* 109:114 */       throw new EOFException("Unexpected end of ZLIB input stream");
/* 110:    */     }
/* 111:116 */     this.inflater.setInput(this.buff, 0, len);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public long skip(long n)
/* 115:    */     throws IOException
/* 116:    */   {
/* 117:127 */     if (n < 0L) {
/* 118:128 */       throw new IllegalArgumentException("negative skip length");
/* 119:    */     }
/* 120:130 */     int max = (int)Math.min(n, 2147483647L);
/* 121:131 */     int total = 0;
/* 122:132 */     byte[] b = new byte[512];
/* 123:133 */     while (total < max)
/* 124:    */     {
/* 125:134 */       int len = max - total;
/* 126:135 */       if (len > b.length) {
/* 127:136 */         len = b.length;
/* 128:    */       }
/* 129:138 */       len = read(b, 0, len);
/* 130:139 */       if (len == -1) {
/* 131:    */         break;
/* 132:    */       }
/* 133:142 */       total += len;
/* 134:    */     }
/* 135:144 */     return total;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void seek(long pos)
/* 139:    */     throws IOException
/* 140:    */   {
/* 141:149 */     super.seek(pos);
/* 142:    */   }
/* 143:    */   
/* 144:    */   public int available()
/* 145:    */   {
/* 146:163 */     return this.inflater.finished() ? 0 : 1;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void close()
/* 150:    */     throws IOException
/* 151:    */   {
/* 152:167 */     this.inflater.end();
/* 153:168 */     super.close();
/* 154:    */   }
/* 155:    */   
/* 156:    */   public UnzipEngine getUnzipEngine()
/* 157:    */   {
/* 158:172 */     return super.getUnzipEngine();
/* 159:    */   }
/* 160:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.io.InflaterInputStream
 * JD-Core Version:    0.7.0.1
 */