/*  1:   */ package net.lingala.zip4j.io;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.io.InputStream;
/*  5:   */ import net.lingala.zip4j.exception.ZipException;
/*  6:   */ import net.lingala.zip4j.unzip.UnzipEngine;
/*  7:   */ 
/*  8:   */ public class ZipInputStream
/*  9:   */   extends InputStream
/* 10:   */ {
/* 11:   */   private BaseInputStream is;
/* 12:   */   
/* 13:   */   public ZipInputStream(BaseInputStream is)
/* 14:   */   {
/* 15:29 */     this.is = is;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public int read()
/* 19:   */     throws IOException
/* 20:   */   {
/* 21:33 */     int readByte = this.is.read();
/* 22:34 */     if (readByte != -1) {
/* 23:35 */       this.is.getUnzipEngine().updateCRC(readByte);
/* 24:   */     }
/* 25:37 */     return readByte;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public int read(byte[] b)
/* 29:   */     throws IOException
/* 30:   */   {
/* 31:41 */     return read(b, 0, b.length);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public int read(byte[] b, int off, int len)
/* 35:   */     throws IOException
/* 36:   */   {
/* 37:45 */     int readLen = this.is.read(b, off, len);
/* 38:46 */     if ((readLen > 0) && (this.is.getUnzipEngine() != null)) {
/* 39:47 */       this.is.getUnzipEngine().updateCRC(b, off, readLen);
/* 40:   */     }
/* 41:49 */     return readLen;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void close()
/* 45:   */     throws IOException
/* 46:   */   {
/* 47:60 */     close(false);
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void close(boolean skipCRCCheck)
/* 51:   */     throws IOException
/* 52:   */   {
/* 53:   */     try
/* 54:   */     {
/* 55:72 */       this.is.close();
/* 56:73 */       if ((!skipCRCCheck) && (this.is.getUnzipEngine() != null)) {
/* 57:74 */         this.is.getUnzipEngine().checkCRC();
/* 58:   */       }
/* 59:   */     }
/* 60:   */     catch (ZipException e)
/* 61:   */     {
/* 62:77 */       throw new IOException(e.getMessage());
/* 63:   */     }
/* 64:   */   }
/* 65:   */   
/* 66:   */   public int available()
/* 67:   */     throws IOException
/* 68:   */   {
/* 69:82 */     return this.is.available();
/* 70:   */   }
/* 71:   */   
/* 72:   */   public long skip(long n)
/* 73:   */     throws IOException
/* 74:   */   {
/* 75:86 */     return this.is.skip(n);
/* 76:   */   }
/* 77:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.io.ZipInputStream
 * JD-Core Version:    0.7.0.1
 */