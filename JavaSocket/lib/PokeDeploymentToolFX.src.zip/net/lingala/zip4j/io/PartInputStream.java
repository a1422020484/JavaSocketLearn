/*   1:    */ package net.lingala.zip4j.io;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.RandomAccessFile;
/*   5:    */ import net.lingala.zip4j.crypto.AESDecrypter;
/*   6:    */ import net.lingala.zip4j.crypto.IDecrypter;
/*   7:    */ import net.lingala.zip4j.exception.ZipException;
/*   8:    */ import net.lingala.zip4j.model.FileHeader;
/*   9:    */ import net.lingala.zip4j.model.ZipModel;
/*  10:    */ import net.lingala.zip4j.unzip.UnzipEngine;
/*  11:    */ 
/*  12:    */ public class PartInputStream
/*  13:    */   extends BaseInputStream
/*  14:    */ {
/*  15:    */   private RandomAccessFile raf;
/*  16:    */   private long bytesRead;
/*  17:    */   private long length;
/*  18:    */   private UnzipEngine unzipEngine;
/*  19:    */   private IDecrypter decrypter;
/*  20: 35 */   private byte[] oneByteBuff = new byte[1];
/*  21: 36 */   private byte[] aesBlockByte = new byte[16];
/*  22: 37 */   private int aesBytesReturned = 0;
/*  23: 38 */   private boolean isAESEncryptedFile = false;
/*  24: 39 */   private int count = -1;
/*  25:    */   
/*  26:    */   public PartInputStream(RandomAccessFile raf, long start, long len, UnzipEngine unzipEngine)
/*  27:    */   {
/*  28: 42 */     this.raf = raf;
/*  29: 43 */     this.unzipEngine = unzipEngine;
/*  30: 44 */     this.decrypter = unzipEngine.getDecrypter();
/*  31: 45 */     this.bytesRead = 0L;
/*  32: 46 */     this.length = len;
/*  33:    */     
/*  34: 48 */     this.isAESEncryptedFile = ((unzipEngine.getFileHeader().isEncrypted()) && (unzipEngine.getFileHeader().getEncryptionMethod() == 99));
/*  35:    */   }
/*  36:    */   
/*  37:    */   public int available()
/*  38:    */   {
/*  39: 52 */     long amount = this.length - this.bytesRead;
/*  40: 53 */     if (amount > 2147483647L) {
/*  41: 54 */       return 2147483647;
/*  42:    */     }
/*  43: 55 */     return (int)amount;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public int read()
/*  47:    */     throws IOException
/*  48:    */   {
/*  49: 59 */     if (this.bytesRead >= this.length) {
/*  50: 60 */       return -1;
/*  51:    */     }
/*  52: 62 */     if (this.isAESEncryptedFile)
/*  53:    */     {
/*  54: 63 */       if ((this.aesBytesReturned == 0) || (this.aesBytesReturned == 16))
/*  55:    */       {
/*  56: 64 */         if (read(this.aesBlockByte) == -1) {
/*  57: 65 */           return -1;
/*  58:    */         }
/*  59: 67 */         this.aesBytesReturned = 0;
/*  60:    */       }
/*  61: 69 */       return this.aesBlockByte[(this.aesBytesReturned++)] & 0xFF;
/*  62:    */     }
/*  63: 71 */     return read(this.oneByteBuff, 0, 1) == -1 ? -1 : this.oneByteBuff[0] & 0xFF;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public int read(byte[] b)
/*  67:    */     throws IOException
/*  68:    */   {
/*  69: 76 */     return read(b, 0, b.length);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public int read(byte[] b, int off, int len)
/*  73:    */     throws IOException
/*  74:    */   {
/*  75: 80 */     if (len > this.length - this.bytesRead)
/*  76:    */     {
/*  77: 81 */       len = (int)(this.length - this.bytesRead);
/*  78: 82 */       if (len == 0)
/*  79:    */       {
/*  80: 83 */         checkAndReadAESMacBytes();
/*  81: 84 */         return -1;
/*  82:    */       }
/*  83:    */     }
/*  84: 88 */     if (((this.unzipEngine.getDecrypter() instanceof AESDecrypter)) && 
/*  85: 89 */       (this.bytesRead + len < this.length) && 
/*  86: 90 */       (len % 16 != 0)) {
/*  87: 91 */       len -= len % 16;
/*  88:    */     }
/*  89: 96 */     synchronized (this.raf)
/*  90:    */     {
/*  91: 97 */       this.count = this.raf.read(b, off, len);
/*  92: 98 */       if ((this.count < len) && (this.unzipEngine.getZipModel().isSplitArchive()))
/*  93:    */       {
/*  94: 99 */         this.raf.close();
/*  95:100 */         this.raf = this.unzipEngine.startNextSplitFile();
/*  96:101 */         if (this.count < 0) {
/*  97:101 */           this.count = 0;
/*  98:    */         }
/*  99:102 */         int newlyRead = this.raf.read(b, this.count, len - this.count);
/* 100:103 */         if (newlyRead > 0) {
/* 101:104 */           this.count += newlyRead;
/* 102:    */         }
/* 103:    */       }
/* 104:    */     }
/* 105:108 */     if (this.count > 0)
/* 106:    */     {
/* 107:109 */       if (this.decrypter != null) {
/* 108:    */         try
/* 109:    */         {
/* 110:111 */           this.decrypter.decryptData(b, off, this.count);
/* 111:    */         }
/* 112:    */         catch (ZipException e)
/* 113:    */         {
/* 114:113 */           throw new IOException(e.getMessage());
/* 115:    */         }
/* 116:    */       }
/* 117:116 */       this.bytesRead += this.count;
/* 118:    */     }
/* 119:119 */     if (this.bytesRead >= this.length) {
/* 120:120 */       checkAndReadAESMacBytes();
/* 121:    */     }
/* 122:123 */     return this.count;
/* 123:    */   }
/* 124:    */   
/* 125:    */   protected void checkAndReadAESMacBytes()
/* 126:    */     throws IOException
/* 127:    */   {
/* 128:127 */     if ((this.isAESEncryptedFile) && 
/* 129:128 */       (this.decrypter != null) && ((this.decrypter instanceof AESDecrypter)))
/* 130:    */     {
/* 131:129 */       if (((AESDecrypter)this.decrypter).getStoredMac() != null) {
/* 132:131 */         return;
/* 133:    */       }
/* 134:133 */       byte[] macBytes = new byte[10];
/* 135:134 */       int readLen = -1;
/* 136:135 */       readLen = this.raf.read(macBytes);
/* 137:136 */       if (readLen != 10) {
/* 138:137 */         if (this.unzipEngine.getZipModel().isSplitArchive())
/* 139:    */         {
/* 140:138 */           this.raf.close();
/* 141:139 */           this.raf = this.unzipEngine.startNextSplitFile();
/* 142:140 */           int newlyRead = this.raf.read(macBytes, readLen, 10 - readLen);
/* 143:141 */           readLen += newlyRead;
/* 144:    */         }
/* 145:    */         else
/* 146:    */         {
/* 147:143 */           throw new IOException("Error occured while reading stored AES authentication bytes");
/* 148:    */         }
/* 149:    */       }
/* 150:147 */       ((AESDecrypter)this.unzipEngine.getDecrypter()).setStoredMac(macBytes);
/* 151:    */     }
/* 152:    */   }
/* 153:    */   
/* 154:    */   public long skip(long amount)
/* 155:    */     throws IOException
/* 156:    */   {
/* 157:153 */     if (amount < 0L) {
/* 158:154 */       throw new IllegalArgumentException();
/* 159:    */     }
/* 160:155 */     if (amount > this.length - this.bytesRead) {
/* 161:156 */       amount = this.length - this.bytesRead;
/* 162:    */     }
/* 163:157 */     this.bytesRead += amount;
/* 164:158 */     return amount;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void close()
/* 168:    */     throws IOException
/* 169:    */   {
/* 170:162 */     this.raf.close();
/* 171:    */   }
/* 172:    */   
/* 173:    */   public void seek(long pos)
/* 174:    */     throws IOException
/* 175:    */   {
/* 176:166 */     this.raf.seek(pos);
/* 177:    */   }
/* 178:    */   
/* 179:    */   public UnzipEngine getUnzipEngine()
/* 180:    */   {
/* 181:170 */     return this.unzipEngine;
/* 182:    */   }
/* 183:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.io.PartInputStream
 * JD-Core Version:    0.7.0.1
 */