/*  1:   */ package net.lingala.zip4j.io;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.io.InputStream;
/*  5:   */ import net.lingala.zip4j.unzip.UnzipEngine;
/*  6:   */ 
/*  7:   */ public abstract class BaseInputStream
/*  8:   */   extends InputStream
/*  9:   */ {
/* 10:   */   public int read()
/* 11:   */     throws IOException
/* 12:   */   {
/* 13:11 */     return 0;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void seek(long pos)
/* 17:   */     throws IOException
/* 18:   */   {}
/* 19:   */   
/* 20:   */   public int available()
/* 21:   */     throws IOException
/* 22:   */   {
/* 23:18 */     return 0;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public UnzipEngine getUnzipEngine()
/* 27:   */   {
/* 28:22 */     return null;
/* 29:   */   }
/* 30:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.io.BaseInputStream
 * JD-Core Version:    0.7.0.1
 */