/*   1:    */ package net.lingala.zip4j.unzip;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import net.lingala.zip4j.exception.ZipException;
/*   5:    */ import net.lingala.zip4j.model.FileHeader;
/*   6:    */ import net.lingala.zip4j.model.UnzipParameters;
/*   7:    */ import net.lingala.zip4j.util.Zip4jUtil;
/*   8:    */ 
/*   9:    */ public class UnzipUtil
/*  10:    */ {
/*  11:    */   public static void applyFileAttributes(FileHeader fileHeader, File file)
/*  12:    */     throws ZipException
/*  13:    */   {
/*  14: 14 */     applyFileAttributes(fileHeader, file, null);
/*  15:    */   }
/*  16:    */   
/*  17:    */   public static void applyFileAttributes(FileHeader fileHeader, File file, UnzipParameters unzipParameters)
/*  18:    */     throws ZipException
/*  19:    */   {
/*  20: 20 */     if (fileHeader == null) {
/*  21: 21 */       throw new ZipException("cannot set file properties: file header is null");
/*  22:    */     }
/*  23: 24 */     if (file == null) {
/*  24: 25 */       throw new ZipException("cannot set file properties: output file is null");
/*  25:    */     }
/*  26: 28 */     if (!Zip4jUtil.checkFileExists(file)) {
/*  27: 29 */       throw new ZipException("cannot set file properties: file doesnot exist");
/*  28:    */     }
/*  29: 32 */     if ((unzipParameters == null) || (!unzipParameters.isIgnoreDateTimeAttributes())) {
/*  30: 33 */       setFileLastModifiedTime(fileHeader, file);
/*  31:    */     }
/*  32: 36 */     if (unzipParameters == null) {
/*  33: 37 */       setFileAttributes(fileHeader, file, true, true, true, true);
/*  34: 39 */     } else if (unzipParameters.isIgnoreAllFileAttributes()) {
/*  35: 40 */       setFileAttributes(fileHeader, file, false, false, false, false);
/*  36:    */     } else {
/*  37: 42 */       setFileAttributes(fileHeader, file, !unzipParameters.isIgnoreReadOnlyFileAttribute(), 
/*  38: 43 */         !unzipParameters.isIgnoreHiddenFileAttribute(), 
/*  39: 44 */         !unzipParameters.isIgnoreArchiveFileAttribute(), 
/*  40: 45 */         !unzipParameters.isIgnoreSystemFileAttribute());
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   private static void setFileAttributes(FileHeader fileHeader, File file, boolean setReadOnly, boolean setHidden, boolean setArchive, boolean setSystem)
/*  45:    */     throws ZipException
/*  46:    */   {
/*  47: 52 */     if (fileHeader == null) {
/*  48: 53 */       throw new ZipException("invalid file header. cannot set file attributes");
/*  49:    */     }
/*  50: 56 */     byte[] externalAttrbs = fileHeader.getExternalFileAttr();
/*  51: 57 */     if (externalAttrbs == null) {
/*  52: 58 */       return;
/*  53:    */     }
/*  54: 61 */     int atrrib = externalAttrbs[0];
/*  55: 62 */     switch (atrrib)
/*  56:    */     {
/*  57:    */     case 1: 
/*  58: 64 */       if (setReadOnly) {
/*  59: 64 */         Zip4jUtil.setFileReadOnly(file);
/*  60:    */       }
/*  61:    */       break;
/*  62:    */     case 2: 
/*  63:    */     case 18: 
/*  64: 68 */       if (setHidden) {
/*  65: 68 */         Zip4jUtil.setFileHidden(file);
/*  66:    */       }
/*  67:    */       break;
/*  68:    */     case 32: 
/*  69:    */     case 48: 
/*  70: 72 */       if (setArchive) {
/*  71: 72 */         Zip4jUtil.setFileArchive(file);
/*  72:    */       }
/*  73:    */       break;
/*  74:    */     case 3: 
/*  75: 75 */       if (setReadOnly) {
/*  76: 75 */         Zip4jUtil.setFileReadOnly(file);
/*  77:    */       }
/*  78: 76 */       if (setHidden) {
/*  79: 76 */         Zip4jUtil.setFileHidden(file);
/*  80:    */       }
/*  81:    */       break;
/*  82:    */     case 33: 
/*  83: 79 */       if (setArchive) {
/*  84: 79 */         Zip4jUtil.setFileArchive(file);
/*  85:    */       }
/*  86: 80 */       if (setReadOnly) {
/*  87: 80 */         Zip4jUtil.setFileReadOnly(file);
/*  88:    */       }
/*  89:    */       break;
/*  90:    */     case 34: 
/*  91:    */     case 50: 
/*  92: 84 */       if (setArchive) {
/*  93: 84 */         Zip4jUtil.setFileArchive(file);
/*  94:    */       }
/*  95: 85 */       if (setHidden) {
/*  96: 85 */         Zip4jUtil.setFileHidden(file);
/*  97:    */       }
/*  98:    */       break;
/*  99:    */     case 35: 
/* 100: 88 */       if (setArchive) {
/* 101: 88 */         Zip4jUtil.setFileArchive(file);
/* 102:    */       }
/* 103: 89 */       if (setReadOnly) {
/* 104: 89 */         Zip4jUtil.setFileReadOnly(file);
/* 105:    */       }
/* 106: 90 */       if (setHidden) {
/* 107: 90 */         Zip4jUtil.setFileHidden(file);
/* 108:    */       }
/* 109:    */       break;
/* 110:    */     case 38: 
/* 111: 93 */       if (setReadOnly) {
/* 112: 93 */         Zip4jUtil.setFileReadOnly(file);
/* 113:    */       }
/* 114: 94 */       if (setHidden) {
/* 115: 94 */         Zip4jUtil.setFileHidden(file);
/* 116:    */       }
/* 117: 95 */       if (setSystem) {
/* 118: 95 */         Zip4jUtil.setFileSystemMode(file);
/* 119:    */       }
/* 120:    */       break;
/* 121:    */     }
/* 122:    */   }
/* 123:    */   
/* 124:    */   private static void setFileLastModifiedTime(FileHeader fileHeader, File file)
/* 125:    */     throws ZipException
/* 126:    */   {
/* 127:104 */     if (fileHeader.getLastModFileTime() <= 0) {
/* 128:105 */       return;
/* 129:    */     }
/* 130:108 */     if (file.exists()) {
/* 131:109 */       file.setLastModified(Zip4jUtil.dosToJavaTme(fileHeader.getLastModFileTime()));
/* 132:    */     }
/* 133:    */   }
/* 134:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.unzip.UnzipUtil
 * JD-Core Version:    0.7.0.1
 */