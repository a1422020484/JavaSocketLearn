/*   1:    */ package net.lingala.zip4j.unzip;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.util.ArrayList;
/*   5:    */ import net.lingala.zip4j.exception.ZipException;
/*   6:    */ import net.lingala.zip4j.io.ZipInputStream;
/*   7:    */ import net.lingala.zip4j.model.CentralDirectory;
/*   8:    */ import net.lingala.zip4j.model.FileHeader;
/*   9:    */ import net.lingala.zip4j.model.UnzipParameters;
/*  10:    */ import net.lingala.zip4j.model.Zip64ExtendedInfo;
/*  11:    */ import net.lingala.zip4j.model.ZipModel;
/*  12:    */ import net.lingala.zip4j.progress.ProgressMonitor;
/*  13:    */ import net.lingala.zip4j.util.InternalZipConstants;
/*  14:    */ import net.lingala.zip4j.util.Zip4jUtil;
/*  15:    */ 
/*  16:    */ public class Unzip
/*  17:    */ {
/*  18:    */   private ZipModel zipModel;
/*  19:    */   
/*  20:    */   public Unzip(ZipModel zipModel)
/*  21:    */     throws ZipException
/*  22:    */   {
/*  23: 38 */     if (zipModel == null) {
/*  24: 39 */       throw new ZipException("ZipModel is null");
/*  25:    */     }
/*  26: 42 */     this.zipModel = zipModel;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void extractAll(final UnzipParameters unzipParameters, final String outPath, final ProgressMonitor progressMonitor, boolean runInThread)
/*  30:    */     throws ZipException
/*  31:    */   {
/*  32: 48 */     CentralDirectory centralDirectory = this.zipModel.getCentralDirectory();
/*  33: 50 */     if ((centralDirectory == null) || 
/*  34: 51 */       (centralDirectory.getFileHeaders() == null)) {
/*  35: 52 */       throw new ZipException("invalid central directory in zipModel");
/*  36:    */     }
/*  37: 55 */     final ArrayList fileHeaders = centralDirectory.getFileHeaders();
/*  38:    */     
/*  39: 57 */     progressMonitor.setCurrentOperation(1);
/*  40: 58 */     progressMonitor.setTotalWork(calculateTotalWork(fileHeaders));
/*  41: 59 */     progressMonitor.setState(1);
/*  42: 61 */     if (runInThread)
/*  43:    */     {
/*  44: 62 */       Thread thread = new Thread("Zip4j")
/*  45:    */       {
/*  46:    */         public void run()
/*  47:    */         {
/*  48:    */           try
/*  49:    */           {
/*  50: 65 */             Unzip.this.initExtractAll(fileHeaders, unzipParameters, progressMonitor, outPath);
/*  51: 66 */             progressMonitor.endProgressMonitorSuccess();
/*  52:    */           }
/*  53:    */           catch (ZipException localZipException) {}
/*  54:    */         }
/*  55: 70 */       };
/*  56: 71 */       thread.start();
/*  57:    */     }
/*  58:    */     else
/*  59:    */     {
/*  60: 73 */       initExtractAll(fileHeaders, unzipParameters, progressMonitor, outPath);
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   private void initExtractAll(ArrayList fileHeaders, UnzipParameters unzipParameters, ProgressMonitor progressMonitor, String outPath)
/*  65:    */     throws ZipException
/*  66:    */   {
/*  67: 81 */     for (int i = 0; i < fileHeaders.size(); i++)
/*  68:    */     {
/*  69: 82 */       FileHeader fileHeader = (FileHeader)fileHeaders.get(i);
/*  70: 83 */       initExtractFile(fileHeader, outPath, unzipParameters, null, progressMonitor);
/*  71: 84 */       if (progressMonitor.isCancelAllTasks())
/*  72:    */       {
/*  73: 85 */         progressMonitor.setResult(3);
/*  74: 86 */         progressMonitor.setState(0);
/*  75: 87 */         return;
/*  76:    */       }
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void extractFile(final FileHeader fileHeader, final String outPath, final UnzipParameters unzipParameters, final String newFileName, final ProgressMonitor progressMonitor, boolean runInThread)
/*  81:    */     throws ZipException
/*  82:    */   {
/*  83: 95 */     if (fileHeader == null) {
/*  84: 96 */       throw new ZipException("fileHeader is null");
/*  85:    */     }
/*  86: 99 */     progressMonitor.setCurrentOperation(1);
/*  87:100 */     progressMonitor.setTotalWork(fileHeader.getCompressedSize());
/*  88:101 */     progressMonitor.setState(1);
/*  89:102 */     progressMonitor.setPercentDone(0);
/*  90:103 */     progressMonitor.setFileName(fileHeader.getFileName());
/*  91:105 */     if (runInThread)
/*  92:    */     {
/*  93:106 */       Thread thread = new Thread("Zip4j")
/*  94:    */       {
/*  95:    */         public void run()
/*  96:    */         {
/*  97:    */           try
/*  98:    */           {
/*  99:109 */             Unzip.this.initExtractFile(fileHeader, outPath, unzipParameters, newFileName, progressMonitor);
/* 100:110 */             progressMonitor.endProgressMonitorSuccess();
/* 101:    */           }
/* 102:    */           catch (ZipException localZipException) {}
/* 103:    */         }
/* 104:114 */       };
/* 105:115 */       thread.start();
/* 106:    */     }
/* 107:    */     else
/* 108:    */     {
/* 109:117 */       initExtractFile(fileHeader, outPath, unzipParameters, newFileName, progressMonitor);
/* 110:118 */       progressMonitor.endProgressMonitorSuccess();
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   private void initExtractFile(FileHeader fileHeader, String outPath, UnzipParameters unzipParameters, String newFileName, ProgressMonitor progressMonitor)
/* 115:    */     throws ZipException
/* 116:    */   {
/* 117:126 */     if (fileHeader == null) {
/* 118:127 */       throw new ZipException("fileHeader is null");
/* 119:    */     }
/* 120:    */     try
/* 121:    */     {
/* 122:131 */       progressMonitor.setFileName(fileHeader.getFileName());
/* 123:133 */       if (!outPath.endsWith(InternalZipConstants.FILE_SEPARATOR)) {
/* 124:134 */         outPath = outPath + InternalZipConstants.FILE_SEPARATOR;
/* 125:    */       }
/* 126:139 */       if (fileHeader.isDirectory())
/* 127:    */       {
/* 128:    */         try
/* 129:    */         {
/* 130:141 */           String fileName = fileHeader.getFileName();
/* 131:142 */           if (!Zip4jUtil.isStringNotNullAndNotEmpty(fileName)) {
/* 132:143 */             return;
/* 133:    */           }
/* 134:145 */           String completePath = outPath + fileName;
/* 135:146 */           File file = new File(completePath);
/* 136:147 */           if (!file.exists()) {
/* 137:148 */             file.mkdirs();
/* 138:    */           }
/* 139:    */         }
/* 140:    */         catch (Exception e)
/* 141:    */         {
/* 142:151 */           progressMonitor.endProgressMonitorError(e);
/* 143:152 */           throw new ZipException(e);
/* 144:    */         }
/* 145:    */       }
/* 146:    */       else
/* 147:    */       {
/* 148:156 */         checkOutputDirectoryStructure(fileHeader, outPath, newFileName);
/* 149:    */         
/* 150:158 */         UnzipEngine unzipEngine = new UnzipEngine(this.zipModel, fileHeader);
/* 151:    */         try
/* 152:    */         {
/* 153:160 */           unzipEngine.unzipFile(progressMonitor, outPath, newFileName, unzipParameters);
/* 154:    */         }
/* 155:    */         catch (Exception e)
/* 156:    */         {
/* 157:162 */           progressMonitor.endProgressMonitorError(e);
/* 158:163 */           throw new ZipException(e);
/* 159:    */         }
/* 160:    */       }
/* 161:    */     }
/* 162:    */     catch (ZipException e)
/* 163:    */     {
/* 164:167 */       progressMonitor.endProgressMonitorError(e);
/* 165:168 */       throw e;
/* 166:    */     }
/* 167:    */     catch (Exception e)
/* 168:    */     {
/* 169:170 */       progressMonitor.endProgressMonitorError(e);
/* 170:171 */       throw new ZipException(e);
/* 171:    */     }
/* 172:    */   }
/* 173:    */   
/* 174:    */   public ZipInputStream getInputStream(FileHeader fileHeader)
/* 175:    */     throws ZipException
/* 176:    */   {
/* 177:176 */     UnzipEngine unzipEngine = new UnzipEngine(this.zipModel, fileHeader);
/* 178:177 */     return unzipEngine.getInputStream();
/* 179:    */   }
/* 180:    */   
/* 181:    */   private void checkOutputDirectoryStructure(FileHeader fileHeader, String outPath, String newFileName)
/* 182:    */     throws ZipException
/* 183:    */   {
/* 184:181 */     if ((fileHeader == null) || (!Zip4jUtil.isStringNotNullAndNotEmpty(outPath))) {
/* 185:182 */       throw new ZipException("Cannot check output directory structure...one of the parameters was null");
/* 186:    */     }
/* 187:185 */     String fileName = fileHeader.getFileName();
/* 188:187 */     if (Zip4jUtil.isStringNotNullAndNotEmpty(newFileName)) {
/* 189:188 */       fileName = newFileName;
/* 190:    */     }
/* 191:191 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(fileName)) {
/* 192:193 */       return;
/* 193:    */     }
/* 194:196 */     String compOutPath = outPath + fileName;
/* 195:    */     try
/* 196:    */     {
/* 197:198 */       File file = new File(compOutPath);
/* 198:199 */       String parentDir = file.getParent();
/* 199:200 */       File parentDirFile = new File(parentDir);
/* 200:201 */       if (!parentDirFile.exists()) {
/* 201:202 */         parentDirFile.mkdirs();
/* 202:    */       }
/* 203:    */     }
/* 204:    */     catch (Exception e)
/* 205:    */     {
/* 206:205 */       throw new ZipException(e);
/* 207:    */     }
/* 208:    */   }
/* 209:    */   
/* 210:    */   private long calculateTotalWork(ArrayList fileHeaders)
/* 211:    */     throws ZipException
/* 212:    */   {
/* 213:211 */     if (fileHeaders == null) {
/* 214:212 */       throw new ZipException("fileHeaders is null, cannot calculate total work");
/* 215:    */     }
/* 216:215 */     long totalWork = 0L;
/* 217:217 */     for (int i = 0; i < fileHeaders.size(); i++)
/* 218:    */     {
/* 219:218 */       FileHeader fileHeader = (FileHeader)fileHeaders.get(i);
/* 220:219 */       if ((fileHeader.getZip64ExtendedInfo() != null) && 
/* 221:220 */         (fileHeader.getZip64ExtendedInfo().getUnCompressedSize() > 0L)) {
/* 222:221 */         totalWork += fileHeader.getZip64ExtendedInfo().getCompressedSize();
/* 223:    */       } else {
/* 224:223 */         totalWork += fileHeader.getCompressedSize();
/* 225:    */       }
/* 226:    */     }
/* 227:228 */     return totalWork;
/* 228:    */   }
/* 229:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.unzip.Unzip
 * JD-Core Version:    0.7.0.1
 */