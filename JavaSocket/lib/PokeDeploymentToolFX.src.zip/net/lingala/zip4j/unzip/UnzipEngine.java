/*   1:    */ package net.lingala.zip4j.unzip;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileNotFoundException;
/*   5:    */ import java.io.FileOutputStream;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.OutputStream;
/*   9:    */ import java.io.RandomAccessFile;
/*  10:    */ import java.util.Arrays;
/*  11:    */ import java.util.zip.CRC32;
/*  12:    */ import net.lingala.zip4j.core.HeaderReader;
/*  13:    */ import net.lingala.zip4j.crypto.AESDecrypter;
/*  14:    */ import net.lingala.zip4j.crypto.IDecrypter;
/*  15:    */ import net.lingala.zip4j.crypto.StandardDecrypter;
/*  16:    */ import net.lingala.zip4j.exception.ZipException;
/*  17:    */ import net.lingala.zip4j.io.InflaterInputStream;
/*  18:    */ import net.lingala.zip4j.io.PartInputStream;
/*  19:    */ import net.lingala.zip4j.io.ZipInputStream;
/*  20:    */ import net.lingala.zip4j.model.AESExtraDataRecord;
/*  21:    */ import net.lingala.zip4j.model.EndCentralDirRecord;
/*  22:    */ import net.lingala.zip4j.model.FileHeader;
/*  23:    */ import net.lingala.zip4j.model.LocalFileHeader;
/*  24:    */ import net.lingala.zip4j.model.UnzipParameters;
/*  25:    */ import net.lingala.zip4j.model.ZipModel;
/*  26:    */ import net.lingala.zip4j.progress.ProgressMonitor;
/*  27:    */ import net.lingala.zip4j.util.Raw;
/*  28:    */ import net.lingala.zip4j.util.Zip4jUtil;
/*  29:    */ 
/*  30:    */ public class UnzipEngine
/*  31:    */ {
/*  32:    */   private ZipModel zipModel;
/*  33:    */   private FileHeader fileHeader;
/*  34: 52 */   private int currSplitFileCounter = 0;
/*  35:    */   private LocalFileHeader localFileHeader;
/*  36:    */   private IDecrypter decrypter;
/*  37:    */   private CRC32 crc;
/*  38:    */   
/*  39:    */   public UnzipEngine(ZipModel zipModel, FileHeader fileHeader)
/*  40:    */     throws ZipException
/*  41:    */   {
/*  42: 58 */     if ((zipModel == null) || (fileHeader == null)) {
/*  43: 59 */       throw new ZipException("Invalid parameters passed to StoreUnzip. One or more of the parameters were null");
/*  44:    */     }
/*  45: 62 */     this.zipModel = zipModel;
/*  46: 63 */     this.fileHeader = fileHeader;
/*  47: 64 */     this.crc = new CRC32();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void unzipFile(ProgressMonitor progressMonitor, String outPath, String newFileName, UnzipParameters unzipParameters)
/*  51:    */     throws ZipException
/*  52:    */   {
/*  53: 69 */     if ((this.zipModel == null) || (this.fileHeader == null) || (!Zip4jUtil.isStringNotNullAndNotEmpty(outPath))) {
/*  54: 70 */       throw new ZipException("Invalid parameters passed during unzipping file. One or more of the parameters were null");
/*  55:    */     }
/*  56: 72 */     InputStream is = null;
/*  57: 73 */     OutputStream os = null;
/*  58:    */     try
/*  59:    */     {
/*  60: 75 */       byte[] buff = new byte[4096];
/*  61: 76 */       int readLength = -1;
/*  62:    */       
/*  63: 78 */       is = getInputStream();
/*  64: 79 */       os = getOutputStream(outPath, newFileName);
/*  65: 81 */       while ((readLength = is.read(buff)) != -1)
/*  66:    */       {
/*  67: 82 */         os.write(buff, 0, readLength);
/*  68: 83 */         progressMonitor.updateWorkCompleted(readLength);
/*  69: 84 */         if (progressMonitor.isCancelAllTasks())
/*  70:    */         {
/*  71: 85 */           progressMonitor.setResult(3);
/*  72: 86 */           progressMonitor.setState(0);
/*  73: 87 */           return;
/*  74:    */         }
/*  75:    */       }
/*  76: 91 */       closeStreams(is, os);
/*  77:    */       
/*  78: 93 */       UnzipUtil.applyFileAttributes(this.fileHeader, new File(getOutputFileNameWithPath(outPath, newFileName)), unzipParameters);
/*  79:    */     }
/*  80:    */     catch (IOException e)
/*  81:    */     {
/*  82: 96 */       throw new ZipException(e);
/*  83:    */     }
/*  84:    */     catch (Exception e)
/*  85:    */     {
/*  86: 98 */       throw new ZipException(e);
/*  87:    */     }
/*  88:    */     finally
/*  89:    */     {
/*  90:100 */       closeStreams(is, os);
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   public ZipInputStream getInputStream()
/*  95:    */     throws ZipException
/*  96:    */   {
/*  97:105 */     if (this.fileHeader == null) {
/*  98:106 */       throw new ZipException("file header is null, cannot get inputstream");
/*  99:    */     }
/* 100:109 */     RandomAccessFile raf = null;
/* 101:    */     try
/* 102:    */     {
/* 103:111 */       raf = createFileHandler("r");
/* 104:112 */       String errMsg = "local header and file header do not match";
/* 105:115 */       if (!checkLocalHeader()) {
/* 106:116 */         throw new ZipException(errMsg);
/* 107:    */       }
/* 108:118 */       init(raf);
/* 109:    */       
/* 110:120 */       long comprSize = this.localFileHeader.getCompressedSize();
/* 111:121 */       long offsetStartOfData = this.localFileHeader.getOffsetStartOfData();
/* 112:123 */       if (this.localFileHeader.isEncrypted()) {
/* 113:124 */         if (this.localFileHeader.getEncryptionMethod() == 99)
/* 114:    */         {
/* 115:125 */           if ((this.decrypter instanceof AESDecrypter))
/* 116:    */           {
/* 117:127 */             comprSize = comprSize - (((AESDecrypter)this.decrypter).getSaltLength() + ((AESDecrypter)this.decrypter).getPasswordVerifierLength() + 10);
/* 118:    */             
/* 119:129 */             offsetStartOfData = offsetStartOfData + (((AESDecrypter)this.decrypter).getSaltLength() + ((AESDecrypter)this.decrypter).getPasswordVerifierLength());
/* 120:    */           }
/* 121:    */           else
/* 122:    */           {
/* 123:132 */             throw new ZipException("invalid decryptor when trying to calculate compressed size for AES encrypted file: " + this.fileHeader.getFileName());
/* 124:    */           }
/* 125:    */         }
/* 126:134 */         else if (this.localFileHeader.getEncryptionMethod() == 0)
/* 127:    */         {
/* 128:135 */           comprSize -= 12L;
/* 129:136 */           offsetStartOfData += 12L;
/* 130:    */         }
/* 131:    */       }
/* 132:140 */       int compressionMethod = this.fileHeader.getCompressionMethod();
/* 133:141 */       if (this.fileHeader.getEncryptionMethod() == 99) {
/* 134:142 */         if (this.fileHeader.getAesExtraDataRecord() != null) {
/* 135:143 */           compressionMethod = this.fileHeader.getAesExtraDataRecord().getCompressionMethod();
/* 136:    */         } else {
/* 137:145 */           throw new ZipException("AESExtraDataRecord does not exist for AES encrypted file: " + this.fileHeader.getFileName());
/* 138:    */         }
/* 139:    */       }
/* 140:148 */       raf.seek(offsetStartOfData);
/* 141:149 */       switch (compressionMethod)
/* 142:    */       {
/* 143:    */       case 0: 
/* 144:151 */         return new ZipInputStream(new PartInputStream(raf, offsetStartOfData, comprSize, this));
/* 145:    */       case 8: 
/* 146:153 */         return new ZipInputStream(new InflaterInputStream(raf, offsetStartOfData, comprSize, this));
/* 147:    */       }
/* 148:155 */       throw new ZipException("compression type not supported");
/* 149:    */     }
/* 150:    */     catch (ZipException e)
/* 151:    */     {
/* 152:158 */       if (raf != null) {
/* 153:    */         try
/* 154:    */         {
/* 155:160 */           raf.close();
/* 156:    */         }
/* 157:    */         catch (IOException localIOException) {}
/* 158:    */       }
/* 159:165 */       throw e;
/* 160:    */     }
/* 161:    */     catch (Exception e)
/* 162:    */     {
/* 163:167 */       if (raf != null) {
/* 164:    */         try
/* 165:    */         {
/* 166:169 */           raf.close();
/* 167:    */         }
/* 168:    */         catch (IOException localIOException1) {}
/* 169:    */       }
/* 170:173 */       throw new ZipException(e);
/* 171:    */     }
/* 172:    */   }
/* 173:    */   
/* 174:    */   private void init(RandomAccessFile raf)
/* 175:    */     throws ZipException
/* 176:    */   {
/* 177:180 */     if (this.localFileHeader == null) {
/* 178:181 */       throw new ZipException("local file header is null, cannot initialize input stream");
/* 179:    */     }
/* 180:    */     try
/* 181:    */     {
/* 182:185 */       initDecrypter(raf);
/* 183:    */     }
/* 184:    */     catch (ZipException e)
/* 185:    */     {
/* 186:187 */       throw e;
/* 187:    */     }
/* 188:    */     catch (Exception e)
/* 189:    */     {
/* 190:189 */       throw new ZipException(e);
/* 191:    */     }
/* 192:    */   }
/* 193:    */   
/* 194:    */   private void initDecrypter(RandomAccessFile raf)
/* 195:    */     throws ZipException
/* 196:    */   {
/* 197:194 */     if (this.localFileHeader == null) {
/* 198:195 */       throw new ZipException("local file header is null, cannot init decrypter");
/* 199:    */     }
/* 200:198 */     if (this.localFileHeader.isEncrypted()) {
/* 201:199 */       if (this.localFileHeader.getEncryptionMethod() == 0) {
/* 202:200 */         this.decrypter = new StandardDecrypter(this.fileHeader, getStandardDecrypterHeaderBytes(raf));
/* 203:201 */       } else if (this.localFileHeader.getEncryptionMethod() == 99) {
/* 204:202 */         this.decrypter = new AESDecrypter(this.localFileHeader, getAESSalt(raf), getAESPasswordVerifier(raf));
/* 205:    */       } else {
/* 206:204 */         throw new ZipException("unsupported encryption method");
/* 207:    */       }
/* 208:    */     }
/* 209:    */   }
/* 210:    */   
/* 211:    */   private byte[] getStandardDecrypterHeaderBytes(RandomAccessFile raf)
/* 212:    */     throws ZipException
/* 213:    */   {
/* 214:    */     try
/* 215:    */     {
/* 216:211 */       byte[] headerBytes = new byte[12];
/* 217:212 */       raf.seek(this.localFileHeader.getOffsetStartOfData());
/* 218:213 */       raf.read(headerBytes, 0, 12);
/* 219:214 */       return headerBytes;
/* 220:    */     }
/* 221:    */     catch (IOException e)
/* 222:    */     {
/* 223:216 */       throw new ZipException(e);
/* 224:    */     }
/* 225:    */     catch (Exception e)
/* 226:    */     {
/* 227:218 */       throw new ZipException(e);
/* 228:    */     }
/* 229:    */   }
/* 230:    */   
/* 231:    */   private byte[] getAESSalt(RandomAccessFile raf)
/* 232:    */     throws ZipException
/* 233:    */   {
/* 234:223 */     if (this.localFileHeader.getAesExtraDataRecord() == null) {
/* 235:224 */       return null;
/* 236:    */     }
/* 237:    */     try
/* 238:    */     {
/* 239:227 */       AESExtraDataRecord aesExtraDataRecord = this.localFileHeader.getAesExtraDataRecord();
/* 240:228 */       byte[] saltBytes = new byte[calculateAESSaltLength(aesExtraDataRecord)];
/* 241:229 */       raf.seek(this.localFileHeader.getOffsetStartOfData());
/* 242:230 */       raf.read(saltBytes);
/* 243:231 */       return saltBytes;
/* 244:    */     }
/* 245:    */     catch (IOException e)
/* 246:    */     {
/* 247:233 */       throw new ZipException(e);
/* 248:    */     }
/* 249:    */   }
/* 250:    */   
/* 251:    */   private byte[] getAESPasswordVerifier(RandomAccessFile raf)
/* 252:    */     throws ZipException
/* 253:    */   {
/* 254:    */     try
/* 255:    */     {
/* 256:239 */       byte[] pvBytes = new byte[2];
/* 257:240 */       raf.read(pvBytes);
/* 258:241 */       return pvBytes;
/* 259:    */     }
/* 260:    */     catch (IOException e)
/* 261:    */     {
/* 262:243 */       throw new ZipException(e);
/* 263:    */     }
/* 264:    */   }
/* 265:    */   
/* 266:    */   private int calculateAESSaltLength(AESExtraDataRecord aesExtraDataRecord)
/* 267:    */     throws ZipException
/* 268:    */   {
/* 269:248 */     if (aesExtraDataRecord == null) {
/* 270:249 */       throw new ZipException("unable to determine salt length: AESExtraDataRecord is null");
/* 271:    */     }
/* 272:251 */     switch (aesExtraDataRecord.getAesStrength())
/* 273:    */     {
/* 274:    */     case 1: 
/* 275:253 */       return 8;
/* 276:    */     case 2: 
/* 277:255 */       return 12;
/* 278:    */     case 3: 
/* 279:257 */       return 16;
/* 280:    */     }
/* 281:259 */     throw new ZipException("unable to determine salt length: invalid aes key strength");
/* 282:    */   }
/* 283:    */   
/* 284:    */   public void checkCRC()
/* 285:    */     throws ZipException
/* 286:    */   {
/* 287:264 */     if (this.fileHeader != null) {
/* 288:265 */       if (this.fileHeader.getEncryptionMethod() == 99)
/* 289:    */       {
/* 290:266 */         if ((this.decrypter != null) && ((this.decrypter instanceof AESDecrypter)))
/* 291:    */         {
/* 292:267 */           byte[] tmpMacBytes = ((AESDecrypter)this.decrypter).getCalculatedAuthenticationBytes();
/* 293:268 */           byte[] storedMac = ((AESDecrypter)this.decrypter).getStoredMac();
/* 294:269 */           byte[] calculatedMac = new byte[10];
/* 295:271 */           if ((calculatedMac == null) || (storedMac == null)) {
/* 296:272 */             throw new ZipException("CRC (MAC) check failed for " + this.fileHeader.getFileName());
/* 297:    */           }
/* 298:275 */           System.arraycopy(tmpMacBytes, 0, calculatedMac, 0, 10);
/* 299:277 */           if (!Arrays.equals(calculatedMac, storedMac)) {
/* 300:278 */             throw new ZipException("invalid CRC (MAC) for file: " + this.fileHeader.getFileName());
/* 301:    */           }
/* 302:    */         }
/* 303:    */       }
/* 304:    */       else
/* 305:    */       {
/* 306:282 */         long calculatedCRC = this.crc.getValue() & 0xFFFFFFFF;
/* 307:283 */         if (calculatedCRC != this.fileHeader.getCrc32())
/* 308:    */         {
/* 309:284 */           String errMsg = "invalid CRC for file: " + this.fileHeader.getFileName();
/* 310:285 */           if ((this.localFileHeader.isEncrypted()) && 
/* 311:286 */             (this.localFileHeader.getEncryptionMethod() == 0)) {
/* 312:287 */             errMsg = errMsg + " - Wrong Password?";
/* 313:    */           }
/* 314:289 */           throw new ZipException(errMsg);
/* 315:    */         }
/* 316:    */       }
/* 317:    */     }
/* 318:    */   }
/* 319:    */   
/* 320:    */   private boolean checkLocalHeader()
/* 321:    */     throws ZipException
/* 322:    */   {
/* 323:324 */     RandomAccessFile rafForLH = null;
/* 324:    */     try
/* 325:    */     {
/* 326:326 */       rafForLH = checkSplitFile();
/* 327:328 */       if (rafForLH == null) {
/* 328:329 */         rafForLH = new RandomAccessFile(new File(this.zipModel.getZipFile()), "r");
/* 329:    */       }
/* 330:332 */       HeaderReader headerReader = new HeaderReader(rafForLH);
/* 331:333 */       this.localFileHeader = headerReader.readLocalFileHeader(this.fileHeader);
/* 332:335 */       if (this.localFileHeader == null) {
/* 333:336 */         throw new ZipException("error reading local file header. Is this a valid zip file?");
/* 334:    */       }
/* 335:    */       boolean bool;
/* 336:340 */       if (this.localFileHeader.getCompressionMethod() != this.fileHeader.getCompressionMethod()) {
/* 337:341 */         return false;
/* 338:    */       }
/* 339:344 */       return true;
/* 340:    */     }
/* 341:    */     catch (FileNotFoundException e)
/* 342:    */     {
/* 343:346 */       throw new ZipException(e);
/* 344:    */     }
/* 345:    */     finally
/* 346:    */     {
/* 347:348 */       if (rafForLH != null) {
/* 348:    */         try
/* 349:    */         {
/* 350:350 */           rafForLH.close();
/* 351:    */         }
/* 352:    */         catch (IOException localIOException2) {}catch (Exception localException2) {}
/* 353:    */       }
/* 354:    */     }
/* 355:    */   }
/* 356:    */   
/* 357:    */   private RandomAccessFile checkSplitFile()
/* 358:    */     throws ZipException
/* 359:    */   {
/* 360:361 */     if (this.zipModel.isSplitArchive())
/* 361:    */     {
/* 362:362 */       int diskNumberStartOfFile = this.fileHeader.getDiskNumberStart();
/* 363:363 */       this.currSplitFileCounter = (diskNumberStartOfFile + 1);
/* 364:364 */       String curZipFile = this.zipModel.getZipFile();
/* 365:365 */       String partFile = null;
/* 366:366 */       if (diskNumberStartOfFile == this.zipModel.getEndCentralDirRecord().getNoOfThisDisk()) {
/* 367:367 */         partFile = this.zipModel.getZipFile();
/* 368:369 */       } else if (diskNumberStartOfFile >= 9) {
/* 369:370 */         partFile = curZipFile.substring(0, curZipFile.lastIndexOf(".")) + ".z" + (diskNumberStartOfFile + 1);
/* 370:    */       } else {
/* 371:372 */         partFile = curZipFile.substring(0, curZipFile.lastIndexOf(".")) + ".z0" + (diskNumberStartOfFile + 1);
/* 372:    */       }
/* 373:    */       try
/* 374:    */       {
/* 375:377 */         RandomAccessFile raf = new RandomAccessFile(partFile, "r");
/* 376:379 */         if (this.currSplitFileCounter == 1)
/* 377:    */         {
/* 378:380 */           byte[] splitSig = new byte[4];
/* 379:381 */           raf.read(splitSig);
/* 380:382 */           if (Raw.readIntLittleEndian(splitSig, 0) != 134695760L) {
/* 381:383 */             throw new ZipException("invalid first part split file signature");
/* 382:    */           }
/* 383:    */         }
/* 384:386 */         return raf;
/* 385:    */       }
/* 386:    */       catch (FileNotFoundException e)
/* 387:    */       {
/* 388:388 */         throw new ZipException(e);
/* 389:    */       }
/* 390:    */       catch (IOException e)
/* 391:    */       {
/* 392:390 */         throw new ZipException(e);
/* 393:    */       }
/* 394:    */     }
/* 395:393 */     return null;
/* 396:    */   }
/* 397:    */   
/* 398:    */   private RandomAccessFile createFileHandler(String mode)
/* 399:    */     throws ZipException
/* 400:    */   {
/* 401:397 */     if ((this.zipModel == null) || (!Zip4jUtil.isStringNotNullAndNotEmpty(this.zipModel.getZipFile()))) {
/* 402:398 */       throw new ZipException("input parameter is null in getFilePointer");
/* 403:    */     }
/* 404:    */     try
/* 405:    */     {
/* 406:402 */       RandomAccessFile raf = null;
/* 407:403 */       if (this.zipModel.isSplitArchive()) {
/* 408:404 */         raf = checkSplitFile();
/* 409:    */       }
/* 410:406 */       return new RandomAccessFile(new File(this.zipModel.getZipFile()), mode);
/* 411:    */     }
/* 412:    */     catch (FileNotFoundException e)
/* 413:    */     {
/* 414:410 */       throw new ZipException(e);
/* 415:    */     }
/* 416:    */     catch (Exception e)
/* 417:    */     {
/* 418:412 */       throw new ZipException(e);
/* 419:    */     }
/* 420:    */   }
/* 421:    */   
/* 422:    */   private FileOutputStream getOutputStream(String outPath, String newFileName)
/* 423:    */     throws ZipException
/* 424:    */   {
/* 425:417 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(outPath)) {
/* 426:418 */       throw new ZipException("invalid output path");
/* 427:    */     }
/* 428:    */     try
/* 429:    */     {
/* 430:422 */       File file = new File(getOutputFileNameWithPath(outPath, newFileName));
/* 431:424 */       if (!file.getParentFile().exists()) {
/* 432:425 */         file.getParentFile().mkdirs();
/* 433:    */       }
/* 434:428 */       if (file.exists()) {
/* 435:429 */         file.delete();
/* 436:    */       }
/* 437:432 */       return new FileOutputStream(file);
/* 438:    */     }
/* 439:    */     catch (FileNotFoundException e)
/* 440:    */     {
/* 441:435 */       throw new ZipException(e);
/* 442:    */     }
/* 443:    */   }
/* 444:    */   
/* 445:    */   private String getOutputFileNameWithPath(String outPath, String newFileName)
/* 446:    */     throws ZipException
/* 447:    */   {
/* 448:440 */     String fileName = null;
/* 449:441 */     if (Zip4jUtil.isStringNotNullAndNotEmpty(newFileName)) {
/* 450:442 */       fileName = newFileName;
/* 451:    */     } else {
/* 452:444 */       fileName = this.fileHeader.getFileName();
/* 453:    */     }
/* 454:446 */     return outPath + System.getProperty("file.separator") + fileName;
/* 455:    */   }
/* 456:    */   
/* 457:    */   public RandomAccessFile startNextSplitFile()
/* 458:    */     throws IOException, FileNotFoundException
/* 459:    */   {
/* 460:450 */     String currZipFile = this.zipModel.getZipFile();
/* 461:451 */     String partFile = null;
/* 462:452 */     if (this.currSplitFileCounter == this.zipModel.getEndCentralDirRecord().getNoOfThisDisk()) {
/* 463:453 */       partFile = this.zipModel.getZipFile();
/* 464:455 */     } else if (this.currSplitFileCounter >= 9) {
/* 465:456 */       partFile = currZipFile.substring(0, currZipFile.lastIndexOf(".")) + ".z" + (this.currSplitFileCounter + 1);
/* 466:    */     } else {
/* 467:458 */       partFile = currZipFile.substring(0, currZipFile.lastIndexOf(".")) + ".z0" + (this.currSplitFileCounter + 1);
/* 468:    */     }
/* 469:461 */     this.currSplitFileCounter += 1;
/* 470:    */     try
/* 471:    */     {
/* 472:463 */       if (!Zip4jUtil.checkFileExists(partFile)) {
/* 473:464 */         throw new IOException("zip split file does not exist: " + partFile);
/* 474:    */       }
/* 475:    */     }
/* 476:    */     catch (ZipException e)
/* 477:    */     {
/* 478:467 */       throw new IOException(e.getMessage());
/* 479:    */     }
/* 480:469 */     return new RandomAccessFile(partFile, "r");
/* 481:    */   }
/* 482:    */   
/* 483:    */   private void closeStreams(InputStream is, OutputStream os)
/* 484:    */     throws ZipException
/* 485:    */   {
/* 486:    */     try
/* 487:    */     {
/* 488:474 */       if (is != null)
/* 489:    */       {
/* 490:475 */         is.close();
/* 491:476 */         is = null;
/* 492:    */       }
/* 493:    */       return;
/* 494:    */     }
/* 495:    */     catch (IOException e)
/* 496:    */     {
/* 497:479 */       if ((e != null) && (Zip4jUtil.isStringNotNullAndNotEmpty(e.getMessage())) && 
/* 498:480 */         (e.getMessage().indexOf(" - Wrong Password?") >= 0)) {
/* 499:481 */         throw new ZipException(e.getMessage());
/* 500:    */       }
/* 501:    */     }
/* 502:    */     finally
/* 503:    */     {
/* 504:    */       try
/* 505:    */       {
/* 506:486 */         if (os != null)
/* 507:    */         {
/* 508:487 */           os.close();
/* 509:488 */           os = null;
/* 510:    */         }
/* 511:    */       }
/* 512:    */       catch (IOException localIOException3) {}
/* 513:    */     }
/* 514:    */   }
/* 515:    */   
/* 516:    */   public void updateCRC(int b)
/* 517:    */   {
/* 518:497 */     this.crc.update(b);
/* 519:    */   }
/* 520:    */   
/* 521:    */   public void updateCRC(byte[] buff, int offset, int len)
/* 522:    */   {
/* 523:501 */     if (buff != null) {
/* 524:502 */       this.crc.update(buff, offset, len);
/* 525:    */     }
/* 526:    */   }
/* 527:    */   
/* 528:    */   public FileHeader getFileHeader()
/* 529:    */   {
/* 530:507 */     return this.fileHeader;
/* 531:    */   }
/* 532:    */   
/* 533:    */   public IDecrypter getDecrypter()
/* 534:    */   {
/* 535:511 */     return this.decrypter;
/* 536:    */   }
/* 537:    */   
/* 538:    */   public ZipModel getZipModel()
/* 539:    */   {
/* 540:515 */     return this.zipModel;
/* 541:    */   }
/* 542:    */   
/* 543:    */   public LocalFileHeader getLocalFileHeader()
/* 544:    */   {
/* 545:519 */     return this.localFileHeader;
/* 546:    */   }
/* 547:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.unzip.UnzipEngine
 * JD-Core Version:    0.7.0.1
 */