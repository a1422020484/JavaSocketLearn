/*   1:    */ package net.lingala.zip4j.progress;
/*   2:    */ 
/*   3:    */ import net.lingala.zip4j.exception.ZipException;
/*   4:    */ 
/*   5:    */ public class ProgressMonitor
/*   6:    */ {
/*   7:    */   private int state;
/*   8:    */   private long totalWork;
/*   9:    */   private long workCompleted;
/*  10:    */   private int percentDone;
/*  11:    */   private int currentOperation;
/*  12:    */   private String fileName;
/*  13:    */   private int result;
/*  14:    */   private Throwable exception;
/*  15:    */   private boolean cancelAllTasks;
/*  16:    */   private boolean pause;
/*  17:    */   public static final int STATE_READY = 0;
/*  18:    */   public static final int STATE_BUSY = 1;
/*  19:    */   public static final int RESULT_SUCCESS = 0;
/*  20:    */   public static final int RESULT_WORKING = 1;
/*  21:    */   public static final int RESULT_ERROR = 2;
/*  22:    */   public static final int RESULT_CANCELLED = 3;
/*  23:    */   public static final int OPERATION_NONE = -1;
/*  24:    */   public static final int OPERATION_ADD = 0;
/*  25:    */   public static final int OPERATION_EXTRACT = 1;
/*  26:    */   public static final int OPERATION_REMOVE = 2;
/*  27:    */   public static final int OPERATION_CALC_CRC = 3;
/*  28:    */   public static final int OPERATION_MERGE = 4;
/*  29:    */   
/*  30:    */   public ProgressMonitor()
/*  31:    */   {
/*  32: 57 */     reset();
/*  33: 58 */     this.percentDone = 0;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public int getState()
/*  37:    */   {
/*  38: 62 */     return this.state;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setState(int state)
/*  42:    */   {
/*  43: 66 */     this.state = state;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public long getTotalWork()
/*  47:    */   {
/*  48: 70 */     return this.totalWork;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setTotalWork(long totalWork)
/*  52:    */   {
/*  53: 74 */     this.totalWork = totalWork;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public long getWorkCompleted()
/*  57:    */   {
/*  58: 78 */     return this.workCompleted;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void updateWorkCompleted(long workCompleted)
/*  62:    */   {
/*  63: 82 */     this.workCompleted += workCompleted;
/*  64: 84 */     if (this.totalWork > 0L)
/*  65:    */     {
/*  66: 85 */       this.percentDone = ((int)(this.workCompleted * 100L / this.totalWork));
/*  67: 86 */       if (this.percentDone > 100) {
/*  68: 87 */         this.percentDone = 100;
/*  69:    */       }
/*  70:    */     }
/*  71: 90 */     while (this.pause) {
/*  72:    */       try
/*  73:    */       {
/*  74: 92 */         Thread.sleep(150L);
/*  75:    */       }
/*  76:    */       catch (InterruptedException localInterruptedException) {}
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   public int getPercentDone()
/*  81:    */   {
/*  82:100 */     return this.percentDone;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void setPercentDone(int percentDone)
/*  86:    */   {
/*  87:104 */     this.percentDone = percentDone;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public int getResult()
/*  91:    */   {
/*  92:108 */     return this.result;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void setResult(int result)
/*  96:    */   {
/*  97:112 */     this.result = result;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public String getFileName()
/* 101:    */   {
/* 102:116 */     return this.fileName;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setFileName(String fileName)
/* 106:    */   {
/* 107:120 */     this.fileName = fileName;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public int getCurrentOperation()
/* 111:    */   {
/* 112:124 */     return this.currentOperation;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void setCurrentOperation(int currentOperation)
/* 116:    */   {
/* 117:128 */     this.currentOperation = currentOperation;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public Throwable getException()
/* 121:    */   {
/* 122:132 */     return this.exception;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setException(Throwable exception)
/* 126:    */   {
/* 127:136 */     this.exception = exception;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void endProgressMonitorSuccess()
/* 131:    */     throws ZipException
/* 132:    */   {
/* 133:140 */     reset();
/* 134:141 */     this.result = 0;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void endProgressMonitorError(Throwable e)
/* 138:    */     throws ZipException
/* 139:    */   {
/* 140:145 */     reset();
/* 141:146 */     this.result = 2;
/* 142:147 */     this.exception = e;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void reset()
/* 146:    */   {
/* 147:151 */     this.currentOperation = -1;
/* 148:152 */     this.state = 0;
/* 149:153 */     this.fileName = null;
/* 150:154 */     this.totalWork = 0L;
/* 151:155 */     this.workCompleted = 0L;
/* 152:156 */     this.percentDone = 0;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void fullReset()
/* 156:    */   {
/* 157:160 */     reset();
/* 158:161 */     this.exception = null;
/* 159:162 */     this.result = 0;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public boolean isCancelAllTasks()
/* 163:    */   {
/* 164:166 */     return this.cancelAllTasks;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void cancelAllTasks()
/* 168:    */   {
/* 169:170 */     this.cancelAllTasks = true;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public boolean isPause()
/* 173:    */   {
/* 174:174 */     return this.pause;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public void setPause(boolean pause)
/* 178:    */   {
/* 179:178 */     this.pause = pause;
/* 180:    */   }
/* 181:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.progress.ProgressMonitor
 * JD-Core Version:    0.7.0.1
 */