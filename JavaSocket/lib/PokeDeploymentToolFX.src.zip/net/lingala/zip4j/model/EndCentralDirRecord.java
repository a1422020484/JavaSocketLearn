/*   1:    */ package net.lingala.zip4j.model;
/*   2:    */ 
/*   3:    */ public class EndCentralDirRecord
/*   4:    */ {
/*   5:    */   private long signature;
/*   6:    */   private int noOfThisDisk;
/*   7:    */   private int noOfThisDiskStartOfCentralDir;
/*   8:    */   private int totNoOfEntriesInCentralDirOnThisDisk;
/*   9:    */   private int totNoOfEntriesInCentralDir;
/*  10:    */   private int sizeOfCentralDir;
/*  11:    */   private long offsetOfStartOfCentralDir;
/*  12:    */   private int commentLength;
/*  13:    */   private String comment;
/*  14:    */   private byte[] commentBytes;
/*  15:    */   
/*  16:    */   public long getSignature()
/*  17:    */   {
/*  18: 42 */     return this.signature;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void setSignature(long signature)
/*  22:    */   {
/*  23: 46 */     this.signature = signature;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public int getNoOfThisDisk()
/*  27:    */   {
/*  28: 50 */     return this.noOfThisDisk;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setNoOfThisDisk(int noOfThisDisk)
/*  32:    */   {
/*  33: 54 */     this.noOfThisDisk = noOfThisDisk;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public int getNoOfThisDiskStartOfCentralDir()
/*  37:    */   {
/*  38: 58 */     return this.noOfThisDiskStartOfCentralDir;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setNoOfThisDiskStartOfCentralDir(int noOfThisDiskStartOfCentralDir)
/*  42:    */   {
/*  43: 62 */     this.noOfThisDiskStartOfCentralDir = noOfThisDiskStartOfCentralDir;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public int getTotNoOfEntriesInCentralDirOnThisDisk()
/*  47:    */   {
/*  48: 66 */     return this.totNoOfEntriesInCentralDirOnThisDisk;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setTotNoOfEntriesInCentralDirOnThisDisk(int totNoOfEntriesInCentralDirOnThisDisk)
/*  52:    */   {
/*  53: 71 */     this.totNoOfEntriesInCentralDirOnThisDisk = totNoOfEntriesInCentralDirOnThisDisk;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public int getTotNoOfEntriesInCentralDir()
/*  57:    */   {
/*  58: 75 */     return this.totNoOfEntriesInCentralDir;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setTotNoOfEntriesInCentralDir(int totNoOfEntrisInCentralDir)
/*  62:    */   {
/*  63: 79 */     this.totNoOfEntriesInCentralDir = totNoOfEntrisInCentralDir;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public int getSizeOfCentralDir()
/*  67:    */   {
/*  68: 83 */     return this.sizeOfCentralDir;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setSizeOfCentralDir(int sizeOfCentralDir)
/*  72:    */   {
/*  73: 87 */     this.sizeOfCentralDir = sizeOfCentralDir;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public long getOffsetOfStartOfCentralDir()
/*  77:    */   {
/*  78: 91 */     return this.offsetOfStartOfCentralDir;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setOffsetOfStartOfCentralDir(long offSetOfStartOfCentralDir)
/*  82:    */   {
/*  83: 95 */     this.offsetOfStartOfCentralDir = offSetOfStartOfCentralDir;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public int getCommentLength()
/*  87:    */   {
/*  88: 99 */     return this.commentLength;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setCommentLength(int commentLength)
/*  92:    */   {
/*  93:103 */     this.commentLength = commentLength;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public String getComment()
/*  97:    */   {
/*  98:107 */     return this.comment;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void setComment(String comment)
/* 102:    */   {
/* 103:111 */     this.comment = comment;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public byte[] getCommentBytes()
/* 107:    */   {
/* 108:115 */     return this.commentBytes;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void setCommentBytes(byte[] commentBytes)
/* 112:    */   {
/* 113:119 */     this.commentBytes = commentBytes;
/* 114:    */   }
/* 115:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.EndCentralDirRecord
 * JD-Core Version:    0.7.0.1
 */