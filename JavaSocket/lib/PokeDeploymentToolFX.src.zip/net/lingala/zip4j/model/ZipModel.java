/*   1:    */ package net.lingala.zip4j.model;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ 
/*   5:    */ public class ZipModel
/*   6:    */   implements Cloneable
/*   7:    */ {
/*   8:    */   private List localFileHeaderList;
/*   9:    */   private List dataDescriptorList;
/*  10:    */   private ArchiveExtraDataRecord archiveExtraDataRecord;
/*  11:    */   private CentralDirectory centralDirectory;
/*  12:    */   private EndCentralDirRecord endCentralDirRecord;
/*  13:    */   private Zip64EndCentralDirLocator zip64EndCentralDirLocator;
/*  14:    */   private Zip64EndCentralDirRecord zip64EndCentralDirRecord;
/*  15:    */   private boolean splitArchive;
/*  16:    */   private long splitLength;
/*  17:    */   private String zipFile;
/*  18:    */   private boolean isZip64Format;
/*  19:    */   private boolean isNestedZipFile;
/*  20:    */   private long start;
/*  21:    */   private long end;
/*  22:    */   private String fileNameCharset;
/*  23:    */   
/*  24:    */   public ZipModel()
/*  25:    */   {
/*  26: 54 */     this.splitLength = -1L;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public List getLocalFileHeaderList()
/*  30:    */   {
/*  31: 58 */     return this.localFileHeaderList;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setLocalFileHeaderList(List localFileHeaderList)
/*  35:    */   {
/*  36: 62 */     this.localFileHeaderList = localFileHeaderList;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public List getDataDescriptorList()
/*  40:    */   {
/*  41: 66 */     return this.dataDescriptorList;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setDataDescriptorList(List dataDescriptorList)
/*  45:    */   {
/*  46: 70 */     this.dataDescriptorList = dataDescriptorList;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public CentralDirectory getCentralDirectory()
/*  50:    */   {
/*  51: 74 */     return this.centralDirectory;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setCentralDirectory(CentralDirectory centralDirectory)
/*  55:    */   {
/*  56: 78 */     this.centralDirectory = centralDirectory;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public EndCentralDirRecord getEndCentralDirRecord()
/*  60:    */   {
/*  61: 82 */     return this.endCentralDirRecord;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setEndCentralDirRecord(EndCentralDirRecord endCentralDirRecord)
/*  65:    */   {
/*  66: 86 */     this.endCentralDirRecord = endCentralDirRecord;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public ArchiveExtraDataRecord getArchiveExtraDataRecord()
/*  70:    */   {
/*  71: 90 */     return this.archiveExtraDataRecord;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setArchiveExtraDataRecord(ArchiveExtraDataRecord archiveExtraDataRecord)
/*  75:    */   {
/*  76: 95 */     this.archiveExtraDataRecord = archiveExtraDataRecord;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean isSplitArchive()
/*  80:    */   {
/*  81: 99 */     return this.splitArchive;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void setSplitArchive(boolean splitArchive)
/*  85:    */   {
/*  86:103 */     this.splitArchive = splitArchive;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public String getZipFile()
/*  90:    */   {
/*  91:107 */     return this.zipFile;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setZipFile(String zipFile)
/*  95:    */   {
/*  96:111 */     this.zipFile = zipFile;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public Zip64EndCentralDirLocator getZip64EndCentralDirLocator()
/* 100:    */   {
/* 101:115 */     return this.zip64EndCentralDirLocator;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void setZip64EndCentralDirLocator(Zip64EndCentralDirLocator zip64EndCentralDirLocator)
/* 105:    */   {
/* 106:120 */     this.zip64EndCentralDirLocator = zip64EndCentralDirLocator;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public Zip64EndCentralDirRecord getZip64EndCentralDirRecord()
/* 110:    */   {
/* 111:124 */     return this.zip64EndCentralDirRecord;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setZip64EndCentralDirRecord(Zip64EndCentralDirRecord zip64EndCentralDirRecord)
/* 115:    */   {
/* 116:129 */     this.zip64EndCentralDirRecord = zip64EndCentralDirRecord;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public boolean isZip64Format()
/* 120:    */   {
/* 121:133 */     return this.isZip64Format;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setZip64Format(boolean isZip64Format)
/* 125:    */   {
/* 126:137 */     this.isZip64Format = isZip64Format;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public boolean isNestedZipFile()
/* 130:    */   {
/* 131:141 */     return this.isNestedZipFile;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setNestedZipFile(boolean isNestedZipFile)
/* 135:    */   {
/* 136:145 */     this.isNestedZipFile = isNestedZipFile;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public long getStart()
/* 140:    */   {
/* 141:149 */     return this.start;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setStart(long start)
/* 145:    */   {
/* 146:153 */     this.start = start;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public long getEnd()
/* 150:    */   {
/* 151:157 */     return this.end;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void setEnd(long end)
/* 155:    */   {
/* 156:161 */     this.end = end;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public long getSplitLength()
/* 160:    */   {
/* 161:165 */     return this.splitLength;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void setSplitLength(long splitLength)
/* 165:    */   {
/* 166:169 */     this.splitLength = splitLength;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public Object clone()
/* 170:    */     throws CloneNotSupportedException
/* 171:    */   {
/* 172:173 */     return super.clone();
/* 173:    */   }
/* 174:    */   
/* 175:    */   public String getFileNameCharset()
/* 176:    */   {
/* 177:177 */     return this.fileNameCharset;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void setFileNameCharset(String fileNameCharset)
/* 181:    */   {
/* 182:181 */     this.fileNameCharset = fileNameCharset;
/* 183:    */   }
/* 184:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.ZipModel
 * JD-Core Version:    0.7.0.1
 */