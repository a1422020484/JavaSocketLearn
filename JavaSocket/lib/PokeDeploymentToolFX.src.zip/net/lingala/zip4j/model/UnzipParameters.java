/*  1:   */ package net.lingala.zip4j.model;
/*  2:   */ 
/*  3:   */ public class UnzipParameters
/*  4:   */ {
/*  5:   */   private boolean ignoreReadOnlyFileAttribute;
/*  6:   */   private boolean ignoreHiddenFileAttribute;
/*  7:   */   private boolean ignoreArchiveFileAttribute;
/*  8:   */   private boolean ignoreSystemFileAttribute;
/*  9:   */   private boolean ignoreAllFileAttributes;
/* 10:   */   private boolean ignoreDateTimeAttributes;
/* 11:   */   
/* 12:   */   public boolean isIgnoreReadOnlyFileAttribute()
/* 13:   */   {
/* 14:29 */     return this.ignoreReadOnlyFileAttribute;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setIgnoreReadOnlyFileAttribute(boolean ignoreReadOnlyFileAttribute)
/* 18:   */   {
/* 19:33 */     this.ignoreReadOnlyFileAttribute = ignoreReadOnlyFileAttribute;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean isIgnoreHiddenFileAttribute()
/* 23:   */   {
/* 24:37 */     return this.ignoreHiddenFileAttribute;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setIgnoreHiddenFileAttribute(boolean ignoreHiddenFileAttribute)
/* 28:   */   {
/* 29:41 */     this.ignoreHiddenFileAttribute = ignoreHiddenFileAttribute;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public boolean isIgnoreArchiveFileAttribute()
/* 33:   */   {
/* 34:45 */     return this.ignoreArchiveFileAttribute;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setIgnoreArchiveFileAttribute(boolean ignoreArchiveFileAttribute)
/* 38:   */   {
/* 39:49 */     this.ignoreArchiveFileAttribute = ignoreArchiveFileAttribute;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public boolean isIgnoreSystemFileAttribute()
/* 43:   */   {
/* 44:53 */     return this.ignoreSystemFileAttribute;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setIgnoreSystemFileAttribute(boolean ignoreSystemFileAttribute)
/* 48:   */   {
/* 49:57 */     this.ignoreSystemFileAttribute = ignoreSystemFileAttribute;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public boolean isIgnoreAllFileAttributes()
/* 53:   */   {
/* 54:61 */     return this.ignoreAllFileAttributes;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void setIgnoreAllFileAttributes(boolean ignoreAllFileAttributes)
/* 58:   */   {
/* 59:65 */     this.ignoreAllFileAttributes = ignoreAllFileAttributes;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public boolean isIgnoreDateTimeAttributes()
/* 63:   */   {
/* 64:69 */     return this.ignoreDateTimeAttributes;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void setIgnoreDateTimeAttributes(boolean ignoreDateTimeAttributes)
/* 68:   */   {
/* 69:73 */     this.ignoreDateTimeAttributes = ignoreDateTimeAttributes;
/* 70:   */   }
/* 71:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.UnzipParameters
 * JD-Core Version:    0.7.0.1
 */