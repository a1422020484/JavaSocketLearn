/*  1:   */ package net.lingala.zip4j.model;
/*  2:   */ 
/*  3:   */ import java.io.FileOutputStream;
/*  4:   */ import net.lingala.zip4j.crypto.IDecrypter;
/*  5:   */ import net.lingala.zip4j.unzip.UnzipEngine;
/*  6:   */ 
/*  7:   */ public class UnzipEngineParameters
/*  8:   */ {
/*  9:   */   private ZipModel zipModel;
/* 10:   */   private FileHeader fileHeader;
/* 11:   */   private LocalFileHeader localFileHeader;
/* 12:   */   private IDecrypter iDecryptor;
/* 13:   */   private FileOutputStream outputStream;
/* 14:   */   private UnzipEngine unzipEngine;
/* 15:   */   
/* 16:   */   public ZipModel getZipModel()
/* 17:   */   {
/* 18:39 */     return this.zipModel;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setZipModel(ZipModel zipModel)
/* 22:   */   {
/* 23:43 */     this.zipModel = zipModel;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public FileHeader getFileHeader()
/* 27:   */   {
/* 28:47 */     return this.fileHeader;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setFileHeader(FileHeader fileHeader)
/* 32:   */   {
/* 33:51 */     this.fileHeader = fileHeader;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public LocalFileHeader getLocalFileHeader()
/* 37:   */   {
/* 38:55 */     return this.localFileHeader;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void setLocalFileHeader(LocalFileHeader localFileHeader)
/* 42:   */   {
/* 43:59 */     this.localFileHeader = localFileHeader;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public IDecrypter getIDecryptor()
/* 47:   */   {
/* 48:63 */     return this.iDecryptor;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void setIDecryptor(IDecrypter decrypter)
/* 52:   */   {
/* 53:67 */     this.iDecryptor = decrypter;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public FileOutputStream getOutputStream()
/* 57:   */   {
/* 58:71 */     return this.outputStream;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void setOutputStream(FileOutputStream outputStream)
/* 62:   */   {
/* 63:75 */     this.outputStream = outputStream;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public UnzipEngine getUnzipEngine()
/* 67:   */   {
/* 68:79 */     return this.unzipEngine;
/* 69:   */   }
/* 70:   */   
/* 71:   */   public void setUnzipEngine(UnzipEngine unzipEngine)
/* 72:   */   {
/* 73:83 */     this.unzipEngine = unzipEngine;
/* 74:   */   }
/* 75:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.UnzipEngineParameters
 * JD-Core Version:    0.7.0.1
 */