/*  1:   */ package net.lingala.zip4j.model;
/*  2:   */ 
/*  3:   */ public class Zip64ExtendedInfo
/*  4:   */ {
/*  5:   */   private int header;
/*  6:   */   private int size;
/*  7:   */   private long compressedSize;
/*  8:   */   private long unCompressedSize;
/*  9:   */   private long offsetLocalHeader;
/* 10:   */   private int diskNumberStart;
/* 11:   */   
/* 12:   */   public Zip64ExtendedInfo()
/* 13:   */   {
/* 14:34 */     this.compressedSize = -1L;
/* 15:35 */     this.unCompressedSize = -1L;
/* 16:36 */     this.offsetLocalHeader = -1L;
/* 17:37 */     this.diskNumberStart = -1;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int getHeader()
/* 21:   */   {
/* 22:41 */     return this.header;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setHeader(int header)
/* 26:   */   {
/* 27:45 */     this.header = header;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public int getSize()
/* 31:   */   {
/* 32:49 */     return this.size;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setSize(int size)
/* 36:   */   {
/* 37:53 */     this.size = size;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public long getCompressedSize()
/* 41:   */   {
/* 42:57 */     return this.compressedSize;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void setCompressedSize(long compressedSize)
/* 46:   */   {
/* 47:61 */     this.compressedSize = compressedSize;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public long getUnCompressedSize()
/* 51:   */   {
/* 52:65 */     return this.unCompressedSize;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void setUnCompressedSize(long unCompressedSize)
/* 56:   */   {
/* 57:69 */     this.unCompressedSize = unCompressedSize;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public long getOffsetLocalHeader()
/* 61:   */   {
/* 62:73 */     return this.offsetLocalHeader;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public void setOffsetLocalHeader(long offsetLocalHeader)
/* 66:   */   {
/* 67:77 */     this.offsetLocalHeader = offsetLocalHeader;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public int getDiskNumberStart()
/* 71:   */   {
/* 72:81 */     return this.diskNumberStart;
/* 73:   */   }
/* 74:   */   
/* 75:   */   public void setDiskNumberStart(int diskNumberStart)
/* 76:   */   {
/* 77:85 */     this.diskNumberStart = diskNumberStart;
/* 78:   */   }
/* 79:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.Zip64ExtendedInfo
 * JD-Core Version:    0.7.0.1
 */