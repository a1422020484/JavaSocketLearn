/*   1:    */ package net.lingala.zip4j.model;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import net.lingala.zip4j.exception.ZipException;
/*   5:    */ import net.lingala.zip4j.progress.ProgressMonitor;
/*   6:    */ import net.lingala.zip4j.unzip.Unzip;
/*   7:    */ import net.lingala.zip4j.util.Zip4jUtil;
/*   8:    */ 
/*   9:    */ public class FileHeader
/*  10:    */ {
/*  11:    */   private int signature;
/*  12:    */   private int versionMadeBy;
/*  13:    */   private int versionNeededToExtract;
/*  14:    */   private byte[] generalPurposeFlag;
/*  15:    */   private int compressionMethod;
/*  16:    */   private int lastModFileTime;
/*  17:    */   private long crc32;
/*  18:    */   private byte[] crcBuff;
/*  19:    */   private long compressedSize;
/*  20:    */   private long uncompressedSize;
/*  21:    */   private int fileNameLength;
/*  22:    */   private int extraFieldLength;
/*  23:    */   private int fileCommentLength;
/*  24:    */   private int diskNumberStart;
/*  25:    */   private byte[] internalFileAttr;
/*  26:    */   private byte[] externalFileAttr;
/*  27:    */   private long offsetLocalHeader;
/*  28:    */   private String fileName;
/*  29:    */   private String fileComment;
/*  30:    */   private boolean isDirectory;
/*  31:    */   private boolean isEncrypted;
/*  32:    */   private int encryptionMethod;
/*  33:    */   private char[] password;
/*  34:    */   private boolean dataDescriptorExists;
/*  35:    */   private Zip64ExtendedInfo zip64ExtendedInfo;
/*  36:    */   private AESExtraDataRecord aesExtraDataRecord;
/*  37:    */   private ArrayList extraDataRecords;
/*  38:    */   private boolean fileNameUTF8Encoded;
/*  39:    */   
/*  40:    */   public FileHeader()
/*  41:    */   {
/*  42: 85 */     this.encryptionMethod = -1;
/*  43: 86 */     this.crc32 = 0L;
/*  44: 87 */     this.uncompressedSize = 0L;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int getSignature()
/*  48:    */   {
/*  49: 91 */     return this.signature;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setSignature(int signature)
/*  53:    */   {
/*  54: 95 */     this.signature = signature;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public int getVersionMadeBy()
/*  58:    */   {
/*  59: 99 */     return this.versionMadeBy;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setVersionMadeBy(int versionMadeBy)
/*  63:    */   {
/*  64:103 */     this.versionMadeBy = versionMadeBy;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public int getVersionNeededToExtract()
/*  68:    */   {
/*  69:107 */     return this.versionNeededToExtract;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setVersionNeededToExtract(int versionNeededToExtract)
/*  73:    */   {
/*  74:111 */     this.versionNeededToExtract = versionNeededToExtract;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public byte[] getGeneralPurposeFlag()
/*  78:    */   {
/*  79:115 */     return this.generalPurposeFlag;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setGeneralPurposeFlag(byte[] generalPurposeFlag)
/*  83:    */   {
/*  84:119 */     this.generalPurposeFlag = generalPurposeFlag;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public int getCompressionMethod()
/*  88:    */   {
/*  89:123 */     return this.compressionMethod;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void setCompressionMethod(int compressionMethod)
/*  93:    */   {
/*  94:127 */     this.compressionMethod = compressionMethod;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public int getLastModFileTime()
/*  98:    */   {
/*  99:131 */     return this.lastModFileTime;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setLastModFileTime(int lastModFileTime)
/* 103:    */   {
/* 104:135 */     this.lastModFileTime = lastModFileTime;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public long getCrc32()
/* 108:    */   {
/* 109:139 */     return this.crc32 & 0xFFFFFFFF;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setCrc32(long crc32)
/* 113:    */   {
/* 114:143 */     this.crc32 = crc32;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public long getCompressedSize()
/* 118:    */   {
/* 119:147 */     return this.compressedSize;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setCompressedSize(long compressedSize)
/* 123:    */   {
/* 124:151 */     this.compressedSize = compressedSize;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public long getUncompressedSize()
/* 128:    */   {
/* 129:155 */     return this.uncompressedSize;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void setUncompressedSize(long uncompressedSize)
/* 133:    */   {
/* 134:159 */     this.uncompressedSize = uncompressedSize;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public int getFileNameLength()
/* 138:    */   {
/* 139:163 */     return this.fileNameLength;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setFileNameLength(int fileNameLength)
/* 143:    */   {
/* 144:167 */     this.fileNameLength = fileNameLength;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public int getExtraFieldLength()
/* 148:    */   {
/* 149:171 */     return this.extraFieldLength;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void setExtraFieldLength(int extraFieldLength)
/* 153:    */   {
/* 154:175 */     this.extraFieldLength = extraFieldLength;
/* 155:    */   }
/* 156:    */   
/* 157:    */   public int getFileCommentLength()
/* 158:    */   {
/* 159:179 */     return this.fileCommentLength;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void setFileCommentLength(int fileCommentLength)
/* 163:    */   {
/* 164:183 */     this.fileCommentLength = fileCommentLength;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public int getDiskNumberStart()
/* 168:    */   {
/* 169:187 */     return this.diskNumberStart;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void setDiskNumberStart(int diskNumberStart)
/* 173:    */   {
/* 174:191 */     this.diskNumberStart = diskNumberStart;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public byte[] getInternalFileAttr()
/* 178:    */   {
/* 179:195 */     return this.internalFileAttr;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setInternalFileAttr(byte[] internalFileAttr)
/* 183:    */   {
/* 184:199 */     this.internalFileAttr = internalFileAttr;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public byte[] getExternalFileAttr()
/* 188:    */   {
/* 189:203 */     return this.externalFileAttr;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void setExternalFileAttr(byte[] externalFileAttr)
/* 193:    */   {
/* 194:207 */     this.externalFileAttr = externalFileAttr;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public long getOffsetLocalHeader()
/* 198:    */   {
/* 199:211 */     return this.offsetLocalHeader;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public void setOffsetLocalHeader(long offsetLocalHeader)
/* 203:    */   {
/* 204:215 */     this.offsetLocalHeader = offsetLocalHeader;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public String getFileName()
/* 208:    */   {
/* 209:219 */     return this.fileName;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public void setFileName(String fileName)
/* 213:    */   {
/* 214:223 */     this.fileName = fileName;
/* 215:    */   }
/* 216:    */   
/* 217:    */   public String getFileComment()
/* 218:    */   {
/* 219:227 */     return this.fileComment;
/* 220:    */   }
/* 221:    */   
/* 222:    */   public void setFileComment(String fileComment)
/* 223:    */   {
/* 224:231 */     this.fileComment = fileComment;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public boolean isDirectory()
/* 228:    */   {
/* 229:235 */     return this.isDirectory;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public void setDirectory(boolean isDirectory)
/* 233:    */   {
/* 234:239 */     this.isDirectory = isDirectory;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public void extractFile(ZipModel zipModel, String outPath, ProgressMonitor progressMonitor, boolean runInThread)
/* 238:    */     throws ZipException
/* 239:    */   {
/* 240:250 */     extractFile(zipModel, outPath, null, progressMonitor, runInThread);
/* 241:    */   }
/* 242:    */   
/* 243:    */   public void extractFile(ZipModel zipModel, String outPath, UnzipParameters unzipParameters, ProgressMonitor progressMonitor, boolean runInThread)
/* 244:    */     throws ZipException
/* 245:    */   {
/* 246:263 */     extractFile(zipModel, outPath, unzipParameters, null, progressMonitor, runInThread);
/* 247:    */   }
/* 248:    */   
/* 249:    */   public void extractFile(ZipModel zipModel, String outPath, UnzipParameters unzipParameters, String newFileName, ProgressMonitor progressMonitor, boolean runInThread)
/* 250:    */     throws ZipException
/* 251:    */   {
/* 252:280 */     if (zipModel == null) {
/* 253:281 */       throw new ZipException("input zipModel is null");
/* 254:    */     }
/* 255:284 */     if (!Zip4jUtil.checkOutputFolder(outPath)) {
/* 256:285 */       throw new ZipException("Invalid output path");
/* 257:    */     }
/* 258:288 */     if (this == null) {
/* 259:289 */       throw new ZipException("invalid file header");
/* 260:    */     }
/* 261:291 */     Unzip unzip = new Unzip(zipModel);
/* 262:292 */     unzip.extractFile(this, outPath, unzipParameters, newFileName, progressMonitor, runInThread);
/* 263:    */   }
/* 264:    */   
/* 265:    */   public boolean isEncrypted()
/* 266:    */   {
/* 267:296 */     return this.isEncrypted;
/* 268:    */   }
/* 269:    */   
/* 270:    */   public void setEncrypted(boolean isEncrypted)
/* 271:    */   {
/* 272:300 */     this.isEncrypted = isEncrypted;
/* 273:    */   }
/* 274:    */   
/* 275:    */   public int getEncryptionMethod()
/* 276:    */   {
/* 277:304 */     return this.encryptionMethod;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public void setEncryptionMethod(int encryptionMethod)
/* 281:    */   {
/* 282:308 */     this.encryptionMethod = encryptionMethod;
/* 283:    */   }
/* 284:    */   
/* 285:    */   public char[] getPassword()
/* 286:    */   {
/* 287:312 */     return this.password;
/* 288:    */   }
/* 289:    */   
/* 290:    */   public void setPassword(char[] password)
/* 291:    */   {
/* 292:316 */     this.password = password;
/* 293:    */   }
/* 294:    */   
/* 295:    */   public byte[] getCrcBuff()
/* 296:    */   {
/* 297:320 */     return this.crcBuff;
/* 298:    */   }
/* 299:    */   
/* 300:    */   public void setCrcBuff(byte[] crcBuff)
/* 301:    */   {
/* 302:324 */     this.crcBuff = crcBuff;
/* 303:    */   }
/* 304:    */   
/* 305:    */   public ArrayList getExtraDataRecords()
/* 306:    */   {
/* 307:328 */     return this.extraDataRecords;
/* 308:    */   }
/* 309:    */   
/* 310:    */   public void setExtraDataRecords(ArrayList extraDataRecords)
/* 311:    */   {
/* 312:332 */     this.extraDataRecords = extraDataRecords;
/* 313:    */   }
/* 314:    */   
/* 315:    */   public boolean isDataDescriptorExists()
/* 316:    */   {
/* 317:336 */     return this.dataDescriptorExists;
/* 318:    */   }
/* 319:    */   
/* 320:    */   public void setDataDescriptorExists(boolean dataDescriptorExists)
/* 321:    */   {
/* 322:340 */     this.dataDescriptorExists = dataDescriptorExists;
/* 323:    */   }
/* 324:    */   
/* 325:    */   public Zip64ExtendedInfo getZip64ExtendedInfo()
/* 326:    */   {
/* 327:344 */     return this.zip64ExtendedInfo;
/* 328:    */   }
/* 329:    */   
/* 330:    */   public void setZip64ExtendedInfo(Zip64ExtendedInfo zip64ExtendedInfo)
/* 331:    */   {
/* 332:348 */     this.zip64ExtendedInfo = zip64ExtendedInfo;
/* 333:    */   }
/* 334:    */   
/* 335:    */   public AESExtraDataRecord getAesExtraDataRecord()
/* 336:    */   {
/* 337:352 */     return this.aesExtraDataRecord;
/* 338:    */   }
/* 339:    */   
/* 340:    */   public void setAesExtraDataRecord(AESExtraDataRecord aesExtraDataRecord)
/* 341:    */   {
/* 342:356 */     this.aesExtraDataRecord = aesExtraDataRecord;
/* 343:    */   }
/* 344:    */   
/* 345:    */   public boolean isFileNameUTF8Encoded()
/* 346:    */   {
/* 347:360 */     return this.fileNameUTF8Encoded;
/* 348:    */   }
/* 349:    */   
/* 350:    */   public void setFileNameUTF8Encoded(boolean fileNameUTF8Encoded)
/* 351:    */   {
/* 352:364 */     this.fileNameUTF8Encoded = fileNameUTF8Encoded;
/* 353:    */   }
/* 354:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.FileHeader
 * JD-Core Version:    0.7.0.1
 */