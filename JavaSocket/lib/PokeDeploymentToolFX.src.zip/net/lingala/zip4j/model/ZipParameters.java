/*   1:    */ package net.lingala.zip4j.model;
/*   2:    */ 
/*   3:    */ import java.util.TimeZone;
/*   4:    */ import net.lingala.zip4j.util.InternalZipConstants;
/*   5:    */ import net.lingala.zip4j.util.Zip4jUtil;
/*   6:    */ 
/*   7:    */ public class ZipParameters
/*   8:    */   implements Cloneable
/*   9:    */ {
/*  10:    */   private int compressionMethod;
/*  11:    */   private int compressionLevel;
/*  12:    */   private boolean encryptFiles;
/*  13:    */   private int encryptionMethod;
/*  14:    */   private boolean readHiddenFiles;
/*  15:    */   private char[] password;
/*  16:    */   private int aesKeyStrength;
/*  17:    */   private boolean includeRootFolder;
/*  18:    */   private String rootFolderInZip;
/*  19:    */   private TimeZone timeZone;
/*  20:    */   private int sourceFileCRC;
/*  21:    */   private String defaultFolderPath;
/*  22:    */   private String fileNameInZip;
/*  23:    */   private boolean isSourceExternalStream;
/*  24:    */   
/*  25:    */   public ZipParameters()
/*  26:    */   {
/*  27: 43 */     this.compressionMethod = 8;
/*  28: 44 */     this.encryptFiles = false;
/*  29: 45 */     this.readHiddenFiles = true;
/*  30: 46 */     this.encryptionMethod = -1;
/*  31: 47 */     this.aesKeyStrength = -1;
/*  32: 48 */     this.includeRootFolder = true;
/*  33: 49 */     this.timeZone = TimeZone.getDefault();
/*  34:    */   }
/*  35:    */   
/*  36:    */   public int getCompressionMethod()
/*  37:    */   {
/*  38: 53 */     return this.compressionMethod;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setCompressionMethod(int compressionMethod)
/*  42:    */   {
/*  43: 57 */     this.compressionMethod = compressionMethod;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean isEncryptFiles()
/*  47:    */   {
/*  48: 61 */     return this.encryptFiles;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setEncryptFiles(boolean encryptFiles)
/*  52:    */   {
/*  53: 65 */     this.encryptFiles = encryptFiles;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public int getEncryptionMethod()
/*  57:    */   {
/*  58: 69 */     return this.encryptionMethod;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setEncryptionMethod(int encryptionMethod)
/*  62:    */   {
/*  63: 73 */     this.encryptionMethod = encryptionMethod;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public int getCompressionLevel()
/*  67:    */   {
/*  68: 77 */     return this.compressionLevel;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setCompressionLevel(int compressionLevel)
/*  72:    */   {
/*  73: 81 */     this.compressionLevel = compressionLevel;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public boolean isReadHiddenFiles()
/*  77:    */   {
/*  78: 85 */     return this.readHiddenFiles;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setReadHiddenFiles(boolean readHiddenFiles)
/*  82:    */   {
/*  83: 89 */     this.readHiddenFiles = readHiddenFiles;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public Object clone()
/*  87:    */     throws CloneNotSupportedException
/*  88:    */   {
/*  89: 93 */     return super.clone();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public char[] getPassword()
/*  93:    */   {
/*  94: 97 */     return this.password;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void setPassword(String password)
/*  98:    */   {
/*  99:110 */     if (password == null) {
/* 100:110 */       return;
/* 101:    */     }
/* 102:111 */     setPassword(password.toCharArray());
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setPassword(char[] password)
/* 106:    */   {
/* 107:115 */     this.password = password;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public int getAesKeyStrength()
/* 111:    */   {
/* 112:119 */     return this.aesKeyStrength;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void setAesKeyStrength(int aesKeyStrength)
/* 116:    */   {
/* 117:123 */     this.aesKeyStrength = aesKeyStrength;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public boolean isIncludeRootFolder()
/* 121:    */   {
/* 122:127 */     return this.includeRootFolder;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setIncludeRootFolder(boolean includeRootFolder)
/* 126:    */   {
/* 127:131 */     this.includeRootFolder = includeRootFolder;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public String getRootFolderInZip()
/* 131:    */   {
/* 132:135 */     return this.rootFolderInZip;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void setRootFolderInZip(String rootFolderInZip)
/* 136:    */   {
/* 137:139 */     if (Zip4jUtil.isStringNotNullAndNotEmpty(rootFolderInZip))
/* 138:    */     {
/* 139:141 */       if ((!rootFolderInZip.endsWith("\\")) && (!rootFolderInZip.endsWith("/"))) {
/* 140:142 */         rootFolderInZip = rootFolderInZip + InternalZipConstants.FILE_SEPARATOR;
/* 141:    */       }
/* 142:145 */       rootFolderInZip = rootFolderInZip.replaceAll("\\\\", "/");
/* 143:    */     }
/* 144:152 */     this.rootFolderInZip = rootFolderInZip;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public TimeZone getTimeZone()
/* 148:    */   {
/* 149:156 */     return this.timeZone;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void setTimeZone(TimeZone timeZone)
/* 153:    */   {
/* 154:160 */     this.timeZone = timeZone;
/* 155:    */   }
/* 156:    */   
/* 157:    */   public int getSourceFileCRC()
/* 158:    */   {
/* 159:164 */     return this.sourceFileCRC;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void setSourceFileCRC(int sourceFileCRC)
/* 163:    */   {
/* 164:168 */     this.sourceFileCRC = sourceFileCRC;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public String getDefaultFolderPath()
/* 168:    */   {
/* 169:172 */     return this.defaultFolderPath;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void setDefaultFolderPath(String defaultFolderPath)
/* 173:    */   {
/* 174:176 */     this.defaultFolderPath = defaultFolderPath;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public String getFileNameInZip()
/* 178:    */   {
/* 179:180 */     return this.fileNameInZip;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setFileNameInZip(String fileNameInZip)
/* 183:    */   {
/* 184:184 */     this.fileNameInZip = fileNameInZip;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public boolean isSourceExternalStream()
/* 188:    */   {
/* 189:188 */     return this.isSourceExternalStream;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void setSourceExternalStream(boolean isSourceExternalStream)
/* 193:    */   {
/* 194:192 */     this.isSourceExternalStream = isSourceExternalStream;
/* 195:    */   }
/* 196:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.ZipParameters
 * JD-Core Version:    0.7.0.1
 */