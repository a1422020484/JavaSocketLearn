/*   1:    */ package net.lingala.zip4j.model;
/*   2:    */ 
/*   3:    */ public class Zip64EndCentralDirRecord
/*   4:    */ {
/*   5:    */   private long signature;
/*   6:    */   private long sizeOfZip64EndCentralDirRec;
/*   7:    */   private int versionMadeBy;
/*   8:    */   private int versionNeededToExtract;
/*   9:    */   private int noOfThisDisk;
/*  10:    */   private int noOfThisDiskStartOfCentralDir;
/*  11:    */   private long totNoOfEntriesInCentralDirOnThisDisk;
/*  12:    */   private long totNoOfEntriesInCentralDir;
/*  13:    */   private long sizeOfCentralDir;
/*  14:    */   private long offsetStartCenDirWRTStartDiskNo;
/*  15:    */   private byte[] extensibleDataSector;
/*  16:    */   
/*  17:    */   public long getSignature()
/*  18:    */   {
/*  19: 44 */     return this.signature;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void setSignature(long signature)
/*  23:    */   {
/*  24: 48 */     this.signature = signature;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public long getSizeOfZip64EndCentralDirRec()
/*  28:    */   {
/*  29: 52 */     return this.sizeOfZip64EndCentralDirRec;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setSizeOfZip64EndCentralDirRec(long sizeOfZip64EndCentralDirRec)
/*  33:    */   {
/*  34: 56 */     this.sizeOfZip64EndCentralDirRec = sizeOfZip64EndCentralDirRec;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public int getVersionMadeBy()
/*  38:    */   {
/*  39: 60 */     return this.versionMadeBy;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setVersionMadeBy(int versionMadeBy)
/*  43:    */   {
/*  44: 64 */     this.versionMadeBy = versionMadeBy;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int getVersionNeededToExtract()
/*  48:    */   {
/*  49: 68 */     return this.versionNeededToExtract;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setVersionNeededToExtract(int versionNeededToExtract)
/*  53:    */   {
/*  54: 72 */     this.versionNeededToExtract = versionNeededToExtract;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public int getNoOfThisDisk()
/*  58:    */   {
/*  59: 76 */     return this.noOfThisDisk;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setNoOfThisDisk(int noOfThisDisk)
/*  63:    */   {
/*  64: 80 */     this.noOfThisDisk = noOfThisDisk;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public int getNoOfThisDiskStartOfCentralDir()
/*  68:    */   {
/*  69: 84 */     return this.noOfThisDiskStartOfCentralDir;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setNoOfThisDiskStartOfCentralDir(int noOfThisDiskStartOfCentralDir)
/*  73:    */   {
/*  74: 88 */     this.noOfThisDiskStartOfCentralDir = noOfThisDiskStartOfCentralDir;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public long getTotNoOfEntriesInCentralDirOnThisDisk()
/*  78:    */   {
/*  79: 92 */     return this.totNoOfEntriesInCentralDirOnThisDisk;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setTotNoOfEntriesInCentralDirOnThisDisk(long totNoOfEntriesInCentralDirOnThisDisk)
/*  83:    */   {
/*  84: 97 */     this.totNoOfEntriesInCentralDirOnThisDisk = totNoOfEntriesInCentralDirOnThisDisk;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public long getTotNoOfEntriesInCentralDir()
/*  88:    */   {
/*  89:101 */     return this.totNoOfEntriesInCentralDir;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void setTotNoOfEntriesInCentralDir(long totNoOfEntriesInCentralDir)
/*  93:    */   {
/*  94:105 */     this.totNoOfEntriesInCentralDir = totNoOfEntriesInCentralDir;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public long getSizeOfCentralDir()
/*  98:    */   {
/*  99:109 */     return this.sizeOfCentralDir;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setSizeOfCentralDir(long sizeOfCentralDir)
/* 103:    */   {
/* 104:113 */     this.sizeOfCentralDir = sizeOfCentralDir;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public long getOffsetStartCenDirWRTStartDiskNo()
/* 108:    */   {
/* 109:117 */     return this.offsetStartCenDirWRTStartDiskNo;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setOffsetStartCenDirWRTStartDiskNo(long offsetStartCenDirWRTStartDiskNo)
/* 113:    */   {
/* 114:122 */     this.offsetStartCenDirWRTStartDiskNo = offsetStartCenDirWRTStartDiskNo;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public byte[] getExtensibleDataSector()
/* 118:    */   {
/* 119:126 */     return this.extensibleDataSector;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setExtensibleDataSector(byte[] extensibleDataSector)
/* 123:    */   {
/* 124:130 */     this.extensibleDataSector = extensibleDataSector;
/* 125:    */   }
/* 126:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.Zip64EndCentralDirRecord
 * JD-Core Version:    0.7.0.1
 */