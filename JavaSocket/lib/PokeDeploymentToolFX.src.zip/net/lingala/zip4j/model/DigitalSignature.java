/*  1:   */ package net.lingala.zip4j.model;
/*  2:   */ 
/*  3:   */ public class DigitalSignature
/*  4:   */ {
/*  5:   */   private int headerSignature;
/*  6:   */   private int sizeOfData;
/*  7:   */   private String signatureData;
/*  8:   */   
/*  9:   */   public int getHeaderSignature()
/* 10:   */   {
/* 11:28 */     return this.headerSignature;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void setHeaderSignature(int headerSignature)
/* 15:   */   {
/* 16:32 */     this.headerSignature = headerSignature;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getSizeOfData()
/* 20:   */   {
/* 21:36 */     return this.sizeOfData;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setSizeOfData(int sizeOfData)
/* 25:   */   {
/* 26:40 */     this.sizeOfData = sizeOfData;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getSignatureData()
/* 30:   */   {
/* 31:44 */     return this.signatureData;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setSignatureData(String signatureData)
/* 35:   */   {
/* 36:48 */     this.signatureData = signatureData;
/* 37:   */   }
/* 38:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.DigitalSignature
 * JD-Core Version:    0.7.0.1
 */