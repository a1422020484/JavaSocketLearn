/*   1:    */ package net.lingala.zip4j.model;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ 
/*   5:    */ public class LocalFileHeader
/*   6:    */ {
/*   7:    */   private int signature;
/*   8:    */   private int versionNeededToExtract;
/*   9:    */   private byte[] generalPurposeFlag;
/*  10:    */   private int compressionMethod;
/*  11:    */   private int lastModFileTime;
/*  12:    */   private long crc32;
/*  13:    */   private byte[] crcBuff;
/*  14:    */   private long compressedSize;
/*  15:    */   private long uncompressedSize;
/*  16:    */   private int fileNameLength;
/*  17:    */   private int extraFieldLength;
/*  18:    */   private String fileName;
/*  19:    */   private byte[] extraField;
/*  20:    */   private long offsetStartOfData;
/*  21:    */   private boolean isEncrypted;
/*  22:    */   private int encryptionMethod;
/*  23:    */   private char[] password;
/*  24:    */   private ArrayList extraDataRecords;
/*  25:    */   private Zip64ExtendedInfo zip64ExtendedInfo;
/*  26:    */   private AESExtraDataRecord aesExtraDataRecord;
/*  27:    */   private boolean dataDescriptorExists;
/*  28:    */   private boolean writeComprSizeInZip64ExtraRecord;
/*  29:    */   private boolean fileNameUTF8Encoded;
/*  30:    */   
/*  31:    */   public LocalFileHeader()
/*  32:    */   {
/*  33: 70 */     this.encryptionMethod = -1;
/*  34: 71 */     this.writeComprSizeInZip64ExtraRecord = false;
/*  35: 72 */     this.crc32 = 0L;
/*  36: 73 */     this.uncompressedSize = 0L;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public int getSignature()
/*  40:    */   {
/*  41: 77 */     return this.signature;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setSignature(int signature)
/*  45:    */   {
/*  46: 81 */     this.signature = signature;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public int getVersionNeededToExtract()
/*  50:    */   {
/*  51: 85 */     return this.versionNeededToExtract;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setVersionNeededToExtract(int versionNeededToExtract)
/*  55:    */   {
/*  56: 89 */     this.versionNeededToExtract = versionNeededToExtract;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public byte[] getGeneralPurposeFlag()
/*  60:    */   {
/*  61: 93 */     return this.generalPurposeFlag;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setGeneralPurposeFlag(byte[] generalPurposeFlag)
/*  65:    */   {
/*  66: 97 */     this.generalPurposeFlag = generalPurposeFlag;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public int getCompressionMethod()
/*  70:    */   {
/*  71:101 */     return this.compressionMethod;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setCompressionMethod(int compressionMethod)
/*  75:    */   {
/*  76:105 */     this.compressionMethod = compressionMethod;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public int getLastModFileTime()
/*  80:    */   {
/*  81:109 */     return this.lastModFileTime;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void setLastModFileTime(int lastModFileTime)
/*  85:    */   {
/*  86:113 */     this.lastModFileTime = lastModFileTime;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public long getCrc32()
/*  90:    */   {
/*  91:117 */     return this.crc32;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setCrc32(long crc32)
/*  95:    */   {
/*  96:121 */     this.crc32 = crc32;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public long getCompressedSize()
/* 100:    */   {
/* 101:125 */     return this.compressedSize;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void setCompressedSize(long compressedSize)
/* 105:    */   {
/* 106:129 */     this.compressedSize = compressedSize;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public long getUncompressedSize()
/* 110:    */   {
/* 111:133 */     return this.uncompressedSize;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setUncompressedSize(long uncompressedSize)
/* 115:    */   {
/* 116:137 */     this.uncompressedSize = uncompressedSize;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public int getFileNameLength()
/* 120:    */   {
/* 121:141 */     return this.fileNameLength;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setFileNameLength(int fileNameLength)
/* 125:    */   {
/* 126:145 */     this.fileNameLength = fileNameLength;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public int getExtraFieldLength()
/* 130:    */   {
/* 131:149 */     return this.extraFieldLength;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setExtraFieldLength(int extraFieldLength)
/* 135:    */   {
/* 136:153 */     this.extraFieldLength = extraFieldLength;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public String getFileName()
/* 140:    */   {
/* 141:157 */     return this.fileName;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setFileName(String fileName)
/* 145:    */   {
/* 146:161 */     this.fileName = fileName;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public byte[] getExtraField()
/* 150:    */   {
/* 151:165 */     return this.extraField;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void setExtraField(byte[] extraField)
/* 155:    */   {
/* 156:169 */     this.extraField = extraField;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public long getOffsetStartOfData()
/* 160:    */   {
/* 161:173 */     return this.offsetStartOfData;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void setOffsetStartOfData(long offsetStartOfData)
/* 165:    */   {
/* 166:177 */     this.offsetStartOfData = offsetStartOfData;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public boolean isEncrypted()
/* 170:    */   {
/* 171:181 */     return this.isEncrypted;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public void setEncrypted(boolean isEncrypted)
/* 175:    */   {
/* 176:185 */     this.isEncrypted = isEncrypted;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public int getEncryptionMethod()
/* 180:    */   {
/* 181:189 */     return this.encryptionMethod;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public void setEncryptionMethod(int encryptionMethod)
/* 185:    */   {
/* 186:193 */     this.encryptionMethod = encryptionMethod;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public byte[] getCrcBuff()
/* 190:    */   {
/* 191:197 */     return this.crcBuff;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public void setCrcBuff(byte[] crcBuff)
/* 195:    */   {
/* 196:201 */     this.crcBuff = crcBuff;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public char[] getPassword()
/* 200:    */   {
/* 201:205 */     return this.password;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public void setPassword(char[] password)
/* 205:    */   {
/* 206:209 */     this.password = password;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public ArrayList getExtraDataRecords()
/* 210:    */   {
/* 211:213 */     return this.extraDataRecords;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public void setExtraDataRecords(ArrayList extraDataRecords)
/* 215:    */   {
/* 216:217 */     this.extraDataRecords = extraDataRecords;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public boolean isDataDescriptorExists()
/* 220:    */   {
/* 221:221 */     return this.dataDescriptorExists;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public void setDataDescriptorExists(boolean dataDescriptorExists)
/* 225:    */   {
/* 226:225 */     this.dataDescriptorExists = dataDescriptorExists;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public Zip64ExtendedInfo getZip64ExtendedInfo()
/* 230:    */   {
/* 231:229 */     return this.zip64ExtendedInfo;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public void setZip64ExtendedInfo(Zip64ExtendedInfo zip64ExtendedInfo)
/* 235:    */   {
/* 236:233 */     this.zip64ExtendedInfo = zip64ExtendedInfo;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public AESExtraDataRecord getAesExtraDataRecord()
/* 240:    */   {
/* 241:237 */     return this.aesExtraDataRecord;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public void setAesExtraDataRecord(AESExtraDataRecord aesExtraDataRecord)
/* 245:    */   {
/* 246:241 */     this.aesExtraDataRecord = aesExtraDataRecord;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public boolean isWriteComprSizeInZip64ExtraRecord()
/* 250:    */   {
/* 251:245 */     return this.writeComprSizeInZip64ExtraRecord;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public void setWriteComprSizeInZip64ExtraRecord(boolean writeComprSizeInZip64ExtraRecord)
/* 255:    */   {
/* 256:250 */     this.writeComprSizeInZip64ExtraRecord = writeComprSizeInZip64ExtraRecord;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public boolean isFileNameUTF8Encoded()
/* 260:    */   {
/* 261:254 */     return this.fileNameUTF8Encoded;
/* 262:    */   }
/* 263:    */   
/* 264:    */   public void setFileNameUTF8Encoded(boolean fileNameUTF8Encoded)
/* 265:    */   {
/* 266:258 */     this.fileNameUTF8Encoded = fileNameUTF8Encoded;
/* 267:    */   }
/* 268:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.LocalFileHeader
 * JD-Core Version:    0.7.0.1
 */