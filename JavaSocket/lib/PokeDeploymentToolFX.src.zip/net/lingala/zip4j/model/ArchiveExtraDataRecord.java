/*  1:   */ package net.lingala.zip4j.model;
/*  2:   */ 
/*  3:   */ public class ArchiveExtraDataRecord
/*  4:   */ {
/*  5:   */   private int signature;
/*  6:   */   private int extraFieldLength;
/*  7:   */   private String extraFieldData;
/*  8:   */   
/*  9:   */   public int getSignature()
/* 10:   */   {
/* 11:28 */     return this.signature;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void setSignature(int signature)
/* 15:   */   {
/* 16:32 */     this.signature = signature;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getExtraFieldLength()
/* 20:   */   {
/* 21:36 */     return this.extraFieldLength;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setExtraFieldLength(int extraFieldLength)
/* 25:   */   {
/* 26:40 */     this.extraFieldLength = extraFieldLength;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public String getExtraFieldData()
/* 30:   */   {
/* 31:44 */     return this.extraFieldData;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setExtraFieldData(String extraFieldData)
/* 35:   */   {
/* 36:48 */     this.extraFieldData = extraFieldData;
/* 37:   */   }
/* 38:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.ArchiveExtraDataRecord
 * JD-Core Version:    0.7.0.1
 */