/*  1:   */ package net.lingala.zip4j.model;
/*  2:   */ 
/*  3:   */ public class ExtraDataRecord
/*  4:   */ {
/*  5:   */   private long header;
/*  6:   */   private int sizeOfData;
/*  7:   */   private byte[] data;
/*  8:   */   
/*  9:   */   public long getHeader()
/* 10:   */   {
/* 11:28 */     return this.header;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void setHeader(long header)
/* 15:   */   {
/* 16:32 */     this.header = header;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getSizeOfData()
/* 20:   */   {
/* 21:36 */     return this.sizeOfData;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setSizeOfData(int sizeOfData)
/* 25:   */   {
/* 26:40 */     this.sizeOfData = sizeOfData;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public byte[] getData()
/* 30:   */   {
/* 31:44 */     return this.data;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setData(byte[] data)
/* 35:   */   {
/* 36:48 */     this.data = data;
/* 37:   */   }
/* 38:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.ExtraDataRecord
 * JD-Core Version:    0.7.0.1
 */