/*  1:   */ package net.lingala.zip4j.model;
/*  2:   */ 
/*  3:   */ public class AESExtraDataRecord
/*  4:   */ {
/*  5:   */   private long signature;
/*  6:   */   private int dataSize;
/*  7:   */   private int versionNumber;
/*  8:   */   private String vendorID;
/*  9:   */   private int aesStrength;
/* 10:   */   private int compressionMethod;
/* 11:   */   
/* 12:   */   public AESExtraDataRecord()
/* 13:   */   {
/* 14:29 */     this.signature = -1L;
/* 15:30 */     this.dataSize = -1;
/* 16:31 */     this.versionNumber = -1;
/* 17:32 */     this.vendorID = null;
/* 18:33 */     this.aesStrength = -1;
/* 19:34 */     this.compressionMethod = -1;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public long getSignature()
/* 23:   */   {
/* 24:39 */     return this.signature;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setSignature(long signature)
/* 28:   */   {
/* 29:44 */     this.signature = signature;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public int getDataSize()
/* 33:   */   {
/* 34:49 */     return this.dataSize;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setDataSize(int dataSize)
/* 38:   */   {
/* 39:54 */     this.dataSize = dataSize;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public int getVersionNumber()
/* 43:   */   {
/* 44:59 */     return this.versionNumber;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setVersionNumber(int versionNumber)
/* 48:   */   {
/* 49:64 */     this.versionNumber = versionNumber;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public String getVendorID()
/* 53:   */   {
/* 54:69 */     return this.vendorID;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void setVendorID(String vendorID)
/* 58:   */   {
/* 59:74 */     this.vendorID = vendorID;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public int getAesStrength()
/* 63:   */   {
/* 64:79 */     return this.aesStrength;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void setAesStrength(int aesStrength)
/* 68:   */   {
/* 69:84 */     this.aesStrength = aesStrength;
/* 70:   */   }
/* 71:   */   
/* 72:   */   public int getCompressionMethod()
/* 73:   */   {
/* 74:89 */     return this.compressionMethod;
/* 75:   */   }
/* 76:   */   
/* 77:   */   public void setCompressionMethod(int compressionMethod)
/* 78:   */   {
/* 79:94 */     this.compressionMethod = compressionMethod;
/* 80:   */   }
/* 81:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.AESExtraDataRecord
 * JD-Core Version:    0.7.0.1
 */