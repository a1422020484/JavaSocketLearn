/*  1:   */ package net.lingala.zip4j.model;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ 
/*  5:   */ public class CentralDirectory
/*  6:   */ {
/*  7:   */   private ArrayList fileHeaders;
/*  8:   */   private DigitalSignature digitalSignature;
/*  9:   */   
/* 10:   */   public ArrayList getFileHeaders()
/* 11:   */   {
/* 12:28 */     return this.fileHeaders;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setFileHeaders(ArrayList fileHeaders)
/* 16:   */   {
/* 17:32 */     this.fileHeaders = fileHeaders;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public DigitalSignature getDigitalSignature()
/* 21:   */   {
/* 22:36 */     return this.digitalSignature;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setDigitalSignature(DigitalSignature digitalSignature)
/* 26:   */   {
/* 27:40 */     this.digitalSignature = digitalSignature;
/* 28:   */   }
/* 29:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.CentralDirectory
 * JD-Core Version:    0.7.0.1
 */