/*  1:   */ package net.lingala.zip4j.model;
/*  2:   */ 
/*  3:   */ public class Zip64EndCentralDirLocator
/*  4:   */ {
/*  5:   */   private long signature;
/*  6:   */   private int noOfDiskStartOfZip64EndOfCentralDirRec;
/*  7:   */   private long offsetZip64EndOfCentralDirRec;
/*  8:   */   private int totNumberOfDiscs;
/*  9:   */   
/* 10:   */   public long getSignature()
/* 11:   */   {
/* 12:30 */     return this.signature;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setSignature(long signature)
/* 16:   */   {
/* 17:34 */     this.signature = signature;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int getNoOfDiskStartOfZip64EndOfCentralDirRec()
/* 21:   */   {
/* 22:38 */     return this.noOfDiskStartOfZip64EndOfCentralDirRec;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setNoOfDiskStartOfZip64EndOfCentralDirRec(int noOfDiskStartOfZip64EndOfCentralDirRec)
/* 26:   */   {
/* 27:43 */     this.noOfDiskStartOfZip64EndOfCentralDirRec = noOfDiskStartOfZip64EndOfCentralDirRec;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public long getOffsetZip64EndOfCentralDirRec()
/* 31:   */   {
/* 32:47 */     return this.offsetZip64EndOfCentralDirRec;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setOffsetZip64EndOfCentralDirRec(long offsetZip64EndOfCentralDirRec)
/* 36:   */   {
/* 37:51 */     this.offsetZip64EndOfCentralDirRec = offsetZip64EndOfCentralDirRec;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public int getTotNumberOfDiscs()
/* 41:   */   {
/* 42:55 */     return this.totNumberOfDiscs;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void setTotNumberOfDiscs(int totNumberOfDiscs)
/* 46:   */   {
/* 47:59 */     this.totNumberOfDiscs = totNumberOfDiscs;
/* 48:   */   }
/* 49:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.Zip64EndCentralDirLocator
 * JD-Core Version:    0.7.0.1
 */