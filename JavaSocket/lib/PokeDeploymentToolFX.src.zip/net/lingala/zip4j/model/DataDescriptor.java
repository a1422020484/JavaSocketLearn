/*  1:   */ package net.lingala.zip4j.model;
/*  2:   */ 
/*  3:   */ public class DataDescriptor
/*  4:   */ {
/*  5:   */   private String crc32;
/*  6:   */   private int compressedSize;
/*  7:   */   private int uncompressedSize;
/*  8:   */   
/*  9:   */   public String getCrc32()
/* 10:   */   {
/* 11:28 */     return this.crc32;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void setCrc32(String crc32)
/* 15:   */   {
/* 16:32 */     this.crc32 = crc32;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getCompressedSize()
/* 20:   */   {
/* 21:36 */     return this.compressedSize;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void setCompressedSize(int compressedSize)
/* 25:   */   {
/* 26:40 */     this.compressedSize = compressedSize;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public int getUncompressedSize()
/* 30:   */   {
/* 31:44 */     return this.uncompressedSize;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setUncompressedSize(int uncompressedSize)
/* 35:   */   {
/* 36:48 */     this.uncompressedSize = uncompressedSize;
/* 37:   */   }
/* 38:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.model.DataDescriptor
 * JD-Core Version:    0.7.0.1
 */