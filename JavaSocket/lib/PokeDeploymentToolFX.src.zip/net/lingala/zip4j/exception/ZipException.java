/*  1:   */ package net.lingala.zip4j.exception;
/*  2:   */ 
/*  3:   */ public class ZipException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:23 */   private int code = -1;
/*  8:   */   
/*  9:   */   public ZipException() {}
/* 10:   */   
/* 11:   */   public ZipException(String msg)
/* 12:   */   {
/* 13:29 */     super(msg);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public ZipException(String message, Throwable cause)
/* 17:   */   {
/* 18:33 */     super(message, cause);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public ZipException(String msg, int code)
/* 22:   */   {
/* 23:37 */     super(msg);
/* 24:38 */     this.code = code;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public ZipException(String message, Throwable cause, int code)
/* 28:   */   {
/* 29:42 */     super(message, cause);
/* 30:43 */     this.code = code;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public ZipException(Throwable cause)
/* 34:   */   {
/* 35:47 */     super(cause);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public ZipException(Throwable cause, int code)
/* 39:   */   {
/* 40:51 */     super(cause);
/* 41:52 */     this.code = code;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public int getCode()
/* 45:   */   {
/* 46:56 */     return this.code;
/* 47:   */   }
/* 48:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.exception.ZipException
 * JD-Core Version:    0.7.0.1
 */