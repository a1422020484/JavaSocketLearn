package net.lingala.zip4j.exception;

public abstract interface ZipExceptionConstants
{
  public static final int inputZipParamIsNull = 1;
  public static final int constuctorFileNotFoundException = 2;
  public static final int randomAccessFileNull = 3;
  public static final int notZipFile = 4;
  public static final int WRONG_PASSWORD = 5;
}


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.exception.ZipExceptionConstants
 * JD-Core Version:    0.7.0.1
 */