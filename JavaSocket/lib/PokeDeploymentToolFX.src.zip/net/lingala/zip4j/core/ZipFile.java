/*    1:     */ package net.lingala.zip4j.core;
/*    2:     */ 
/*    3:     */ import java.io.File;
/*    4:     */ import java.io.FileNotFoundException;
/*    5:     */ import java.io.IOException;
/*    6:     */ import java.io.InputStream;
/*    7:     */ import java.io.RandomAccessFile;
/*    8:     */ import java.io.UnsupportedEncodingException;
/*    9:     */ import java.util.ArrayList;
/*   10:     */ import java.util.List;
/*   11:     */ import net.lingala.zip4j.exception.ZipException;
/*   12:     */ import net.lingala.zip4j.io.ZipInputStream;
/*   13:     */ import net.lingala.zip4j.model.CentralDirectory;
/*   14:     */ import net.lingala.zip4j.model.EndCentralDirRecord;
/*   15:     */ import net.lingala.zip4j.model.FileHeader;
/*   16:     */ import net.lingala.zip4j.model.UnzipParameters;
/*   17:     */ import net.lingala.zip4j.model.ZipModel;
/*   18:     */ import net.lingala.zip4j.model.ZipParameters;
/*   19:     */ import net.lingala.zip4j.progress.ProgressMonitor;
/*   20:     */ import net.lingala.zip4j.unzip.Unzip;
/*   21:     */ import net.lingala.zip4j.util.ArchiveMaintainer;
/*   22:     */ import net.lingala.zip4j.util.InternalZipConstants;
/*   23:     */ import net.lingala.zip4j.util.Zip4jUtil;
/*   24:     */ import net.lingala.zip4j.zip.ZipEngine;
/*   25:     */ 
/*   26:     */ public class ZipFile
/*   27:     */ {
/*   28:     */   private String file;
/*   29:     */   private int mode;
/*   30:     */   private ZipModel zipModel;
/*   31:     */   private boolean isEncrypted;
/*   32:     */   private ProgressMonitor progressMonitor;
/*   33:     */   private boolean runInThread;
/*   34:     */   private String fileNameCharset;
/*   35:     */   
/*   36:     */   public ZipFile(String zipFile)
/*   37:     */     throws ZipException
/*   38:     */   {
/*   39:  72 */     this(new File(zipFile));
/*   40:     */   }
/*   41:     */   
/*   42:     */   public ZipFile(File zipFile)
/*   43:     */     throws ZipException
/*   44:     */   {
/*   45:  82 */     if (zipFile == null) {
/*   46:  83 */       throw new ZipException("Input zip file parameter is not null", 1);
/*   47:     */     }
/*   48:  87 */     this.file = zipFile.getPath();
/*   49:  88 */     this.mode = 2;
/*   50:  89 */     this.progressMonitor = new ProgressMonitor();
/*   51:  90 */     this.runInThread = false;
/*   52:     */   }
/*   53:     */   
/*   54:     */   public void createZipFile(File sourceFile, ZipParameters parameters)
/*   55:     */     throws ZipException
/*   56:     */   {
/*   57: 102 */     ArrayList sourceFileList = new ArrayList();
/*   58: 103 */     sourceFileList.add(sourceFile);
/*   59: 104 */     createZipFile(sourceFileList, parameters, false, -1L);
/*   60:     */   }
/*   61:     */   
/*   62:     */   public void createZipFile(File sourceFile, ZipParameters parameters, boolean splitArchive, long splitLength)
/*   63:     */     throws ZipException
/*   64:     */   {
/*   65: 123 */     ArrayList sourceFileList = new ArrayList();
/*   66: 124 */     sourceFileList.add(sourceFile);
/*   67: 125 */     createZipFile(sourceFileList, parameters, splitArchive, splitLength);
/*   68:     */   }
/*   69:     */   
/*   70:     */   public void createZipFile(ArrayList sourceFileList, ZipParameters parameters)
/*   71:     */     throws ZipException
/*   72:     */   {
/*   73: 138 */     createZipFile(sourceFileList, parameters, false, -1L);
/*   74:     */   }
/*   75:     */   
/*   76:     */   public void createZipFile(ArrayList sourceFileList, ZipParameters parameters, boolean splitArchive, long splitLength)
/*   77:     */     throws ZipException
/*   78:     */   {
/*   79: 157 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(this.file)) {
/*   80: 158 */       throw new ZipException("zip file path is empty");
/*   81:     */     }
/*   82: 161 */     if (Zip4jUtil.checkFileExists(this.file)) {
/*   83: 162 */       throw new ZipException("zip file: " + this.file + " already exists. To add files to existing zip file use addFile method");
/*   84:     */     }
/*   85: 165 */     if (sourceFileList == null) {
/*   86: 166 */       throw new ZipException("input file ArrayList is null, cannot create zip file");
/*   87:     */     }
/*   88: 169 */     if (!Zip4jUtil.checkArrayListTypes(sourceFileList, 1)) {
/*   89: 170 */       throw new ZipException("One or more elements in the input ArrayList is not of type File");
/*   90:     */     }
/*   91: 173 */     createNewZipModel();
/*   92: 174 */     this.zipModel.setSplitArchive(splitArchive);
/*   93: 175 */     this.zipModel.setSplitLength(splitLength);
/*   94: 176 */     addFiles(sourceFileList, parameters);
/*   95:     */   }
/*   96:     */   
/*   97:     */   public void createZipFileFromFolder(String folderToAdd, ZipParameters parameters, boolean splitArchive, long splitLength)
/*   98:     */     throws ZipException
/*   99:     */   {
/*  100: 195 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(folderToAdd)) {
/*  101: 196 */       throw new ZipException("folderToAdd is empty or null, cannot create Zip File from folder");
/*  102:     */     }
/*  103: 199 */     createZipFileFromFolder(new File(folderToAdd), parameters, splitArchive, splitLength);
/*  104:     */   }
/*  105:     */   
/*  106:     */   public void createZipFileFromFolder(File folderToAdd, ZipParameters parameters, boolean splitArchive, long splitLength)
/*  107:     */     throws ZipException
/*  108:     */   {
/*  109: 219 */     if (folderToAdd == null) {
/*  110: 220 */       throw new ZipException("folderToAdd is null, cannot create zip file from folder");
/*  111:     */     }
/*  112: 223 */     if (parameters == null) {
/*  113: 224 */       throw new ZipException("input parameters are null, cannot create zip file from folder");
/*  114:     */     }
/*  115: 227 */     if (Zip4jUtil.checkFileExists(this.file)) {
/*  116: 228 */       throw new ZipException("zip file: " + this.file + " already exists. To add files to existing zip file use addFolder method");
/*  117:     */     }
/*  118: 231 */     createNewZipModel();
/*  119: 232 */     this.zipModel.setSplitArchive(splitArchive);
/*  120: 233 */     if (splitArchive) {
/*  121: 234 */       this.zipModel.setSplitLength(splitLength);
/*  122:     */     }
/*  123: 236 */     addFolder(folderToAdd, parameters, false);
/*  124:     */   }
/*  125:     */   
/*  126:     */   public void addFile(File sourceFile, ZipParameters parameters)
/*  127:     */     throws ZipException
/*  128:     */   {
/*  129: 248 */     ArrayList sourceFileList = new ArrayList();
/*  130: 249 */     sourceFileList.add(sourceFile);
/*  131: 250 */     addFiles(sourceFileList, parameters);
/*  132:     */   }
/*  133:     */   
/*  134:     */   public void addFiles(ArrayList sourceFileList, ZipParameters parameters)
/*  135:     */     throws ZipException
/*  136:     */   {
/*  137: 263 */     checkZipModel();
/*  138: 265 */     if (this.zipModel == null) {
/*  139: 266 */       throw new ZipException("internal error: zip model is null");
/*  140:     */     }
/*  141: 269 */     if (sourceFileList == null) {
/*  142: 270 */       throw new ZipException("input file ArrayList is null, cannot add files");
/*  143:     */     }
/*  144: 273 */     if (!Zip4jUtil.checkArrayListTypes(sourceFileList, 1)) {
/*  145: 274 */       throw new ZipException("One or more elements in the input ArrayList is not of type File");
/*  146:     */     }
/*  147: 277 */     if (parameters == null) {
/*  148: 278 */       throw new ZipException("input parameters are null, cannot add files to zip");
/*  149:     */     }
/*  150: 281 */     if (this.progressMonitor.getState() == 1) {
/*  151: 282 */       throw new ZipException("invalid operation - Zip4j is in busy state");
/*  152:     */     }
/*  153: 285 */     if ((Zip4jUtil.checkFileExists(this.file)) && 
/*  154: 286 */       (this.zipModel.isSplitArchive())) {
/*  155: 287 */       throw new ZipException("Zip file already exists. Zip file format does not allow updating split/spanned files");
/*  156:     */     }
/*  157: 291 */     ZipEngine zipEngine = new ZipEngine(this.zipModel);
/*  158: 292 */     zipEngine.addFiles(sourceFileList, parameters, this.progressMonitor, this.runInThread);
/*  159:     */   }
/*  160:     */   
/*  161:     */   public void addFolder(String path, ZipParameters parameters)
/*  162:     */     throws ZipException
/*  163:     */   {
/*  164: 305 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(path)) {
/*  165: 306 */       throw new ZipException("input path is null or empty, cannot add folder to zip file");
/*  166:     */     }
/*  167: 309 */     addFolder(new File(path), parameters);
/*  168:     */   }
/*  169:     */   
/*  170:     */   public void addFolder(File path, ZipParameters parameters)
/*  171:     */     throws ZipException
/*  172:     */   {
/*  173: 322 */     if (path == null) {
/*  174: 323 */       throw new ZipException("input path is null, cannot add folder to zip file");
/*  175:     */     }
/*  176: 326 */     if (parameters == null) {
/*  177: 327 */       throw new ZipException("input parameters are null, cannot add folder to zip file");
/*  178:     */     }
/*  179: 330 */     addFolder(path, parameters, true);
/*  180:     */   }
/*  181:     */   
/*  182:     */   private void addFolder(File path, ZipParameters parameters, boolean checkSplitArchive)
/*  183:     */     throws ZipException
/*  184:     */   {
/*  185: 343 */     checkZipModel();
/*  186: 345 */     if (this.zipModel == null) {
/*  187: 346 */       throw new ZipException("internal error: zip model is null");
/*  188:     */     }
/*  189: 349 */     if ((checkSplitArchive) && 
/*  190: 350 */       (this.zipModel.isSplitArchive())) {
/*  191: 351 */       throw new ZipException("This is a split archive. Zip file format does not allow updating split/spanned files");
/*  192:     */     }
/*  193: 355 */     ZipEngine zipEngine = new ZipEngine(this.zipModel);
/*  194: 356 */     zipEngine.addFolderToZip(path, parameters, this.progressMonitor, this.runInThread);
/*  195:     */   }
/*  196:     */   
/*  197:     */   public void addStream(InputStream inputStream, ZipParameters parameters)
/*  198:     */     throws ZipException
/*  199:     */   {
/*  200: 372 */     if (inputStream == null) {
/*  201: 373 */       throw new ZipException("inputstream is null, cannot add file to zip");
/*  202:     */     }
/*  203: 376 */     if (parameters == null) {
/*  204: 377 */       throw new ZipException("zip parameters are null");
/*  205:     */     }
/*  206: 380 */     setRunInThread(false);
/*  207:     */     
/*  208: 382 */     checkZipModel();
/*  209: 384 */     if (this.zipModel == null) {
/*  210: 385 */       throw new ZipException("internal error: zip model is null");
/*  211:     */     }
/*  212: 388 */     if ((Zip4jUtil.checkFileExists(this.file)) && 
/*  213: 389 */       (this.zipModel.isSplitArchive())) {
/*  214: 390 */       throw new ZipException("Zip file already exists. Zip file format does not allow updating split/spanned files");
/*  215:     */     }
/*  216: 394 */     ZipEngine zipEngine = new ZipEngine(this.zipModel);
/*  217: 395 */     zipEngine.addStreamToZip(inputStream, parameters);
/*  218:     */   }
/*  219:     */   
/*  220:     */   private void readZipInfo()
/*  221:     */     throws ZipException
/*  222:     */   {
/*  223: 406 */     if (!Zip4jUtil.checkFileExists(this.file)) {
/*  224: 407 */       throw new ZipException("zip file does not exist");
/*  225:     */     }
/*  226: 410 */     if (!Zip4jUtil.checkFileReadAccess(this.file)) {
/*  227: 411 */       throw new ZipException("no read access for the input zip file");
/*  228:     */     }
/*  229: 414 */     if (this.mode != 2) {
/*  230: 415 */       throw new ZipException("Invalid mode");
/*  231:     */     }
/*  232: 418 */     RandomAccessFile raf = null;
/*  233:     */     try
/*  234:     */     {
/*  235: 420 */       raf = new RandomAccessFile(new File(this.file), "r");
/*  236: 422 */       if (this.zipModel == null)
/*  237:     */       {
/*  238: 424 */         HeaderReader headerReader = new HeaderReader(raf);
/*  239: 425 */         this.zipModel = headerReader.readAllHeaders(this.fileNameCharset);
/*  240: 426 */         if (this.zipModel != null) {
/*  241: 427 */           this.zipModel.setZipFile(this.file);
/*  242:     */         }
/*  243:     */       }
/*  244:     */       return;
/*  245:     */     }
/*  246:     */     catch (FileNotFoundException e)
/*  247:     */     {
/*  248: 431 */       throw new ZipException(e);
/*  249:     */     }
/*  250:     */     finally
/*  251:     */     {
/*  252: 433 */       if (raf != null) {
/*  253:     */         try
/*  254:     */         {
/*  255: 435 */           raf.close();
/*  256:     */         }
/*  257:     */         catch (IOException localIOException1) {}
/*  258:     */       }
/*  259:     */     }
/*  260:     */   }
/*  261:     */   
/*  262:     */   public void extractAll(String destPath)
/*  263:     */     throws ZipException
/*  264:     */   {
/*  265: 451 */     extractAll(destPath, null);
/*  266:     */   }
/*  267:     */   
/*  268:     */   public void extractAll(String destPath, UnzipParameters unzipParameters)
/*  269:     */     throws ZipException
/*  270:     */   {
/*  271: 466 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(destPath)) {
/*  272: 467 */       throw new ZipException("output path is null or invalid");
/*  273:     */     }
/*  274: 470 */     if (!Zip4jUtil.checkOutputFolder(destPath)) {
/*  275: 471 */       throw new ZipException("invalid output path");
/*  276:     */     }
/*  277: 474 */     if (this.zipModel == null) {
/*  278: 475 */       readZipInfo();
/*  279:     */     }
/*  280: 479 */     if (this.zipModel == null) {
/*  281: 480 */       throw new ZipException("Internal error occurred when extracting zip file");
/*  282:     */     }
/*  283: 483 */     if (this.progressMonitor.getState() == 1) {
/*  284: 484 */       throw new ZipException("invalid operation - Zip4j is in busy state");
/*  285:     */     }
/*  286: 487 */     Unzip unzip = new Unzip(this.zipModel);
/*  287: 488 */     unzip.extractAll(unzipParameters, destPath, this.progressMonitor, this.runInThread);
/*  288:     */   }
/*  289:     */   
/*  290:     */   public void extractFile(FileHeader fileHeader, String destPath)
/*  291:     */     throws ZipException
/*  292:     */   {
/*  293: 500 */     extractFile(fileHeader, destPath, null);
/*  294:     */   }
/*  295:     */   
/*  296:     */   public void extractFile(FileHeader fileHeader, String destPath, UnzipParameters unzipParameters)
/*  297:     */     throws ZipException
/*  298:     */   {
/*  299: 517 */     extractFile(fileHeader, destPath, unzipParameters, null);
/*  300:     */   }
/*  301:     */   
/*  302:     */   public void extractFile(FileHeader fileHeader, String destPath, UnzipParameters unzipParameters, String newFileName)
/*  303:     */     throws ZipException
/*  304:     */   {
/*  305: 532 */     if (fileHeader == null) {
/*  306: 533 */       throw new ZipException("input file header is null, cannot extract file");
/*  307:     */     }
/*  308: 536 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(destPath)) {
/*  309: 537 */       throw new ZipException("destination path is empty or null, cannot extract file");
/*  310:     */     }
/*  311: 540 */     readZipInfo();
/*  312: 542 */     if (this.progressMonitor.getState() == 1) {
/*  313: 543 */       throw new ZipException("invalid operation - Zip4j is in busy state");
/*  314:     */     }
/*  315: 546 */     fileHeader.extractFile(this.zipModel, destPath, unzipParameters, newFileName, this.progressMonitor, this.runInThread);
/*  316:     */   }
/*  317:     */   
/*  318:     */   public void extractFile(String fileName, String destPath)
/*  319:     */     throws ZipException
/*  320:     */   {
/*  321: 566 */     extractFile(fileName, destPath, null);
/*  322:     */   }
/*  323:     */   
/*  324:     */   public void extractFile(String fileName, String destPath, UnzipParameters unzipParameters)
/*  325:     */     throws ZipException
/*  326:     */   {
/*  327: 587 */     extractFile(fileName, destPath, unzipParameters, null);
/*  328:     */   }
/*  329:     */   
/*  330:     */   public void extractFile(String fileName, String destPath, UnzipParameters unzipParameters, String newFileName)
/*  331:     */     throws ZipException
/*  332:     */   {
/*  333: 614 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(fileName)) {
/*  334: 615 */       throw new ZipException("file to extract is null or empty, cannot extract file");
/*  335:     */     }
/*  336: 618 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(destPath)) {
/*  337: 619 */       throw new ZipException("destination string path is empty or null, cannot extract file");
/*  338:     */     }
/*  339: 622 */     readZipInfo();
/*  340:     */     
/*  341: 624 */     FileHeader fileHeader = Zip4jUtil.getFileHeader(this.zipModel, fileName);
/*  342: 626 */     if (fileHeader == null) {
/*  343: 627 */       throw new ZipException("file header not found for given file name, cannot extract file");
/*  344:     */     }
/*  345: 630 */     if (this.progressMonitor.getState() == 1) {
/*  346: 631 */       throw new ZipException("invalid operation - Zip4j is in busy state");
/*  347:     */     }
/*  348: 634 */     fileHeader.extractFile(this.zipModel, destPath, unzipParameters, newFileName, this.progressMonitor, this.runInThread);
/*  349:     */   }
/*  350:     */   
/*  351:     */   public void setPassword(String password)
/*  352:     */     throws ZipException
/*  353:     */   {
/*  354: 649 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(password)) {
/*  355: 650 */       throw new NullPointerException();
/*  356:     */     }
/*  357: 652 */     setPassword(password.toCharArray());
/*  358:     */   }
/*  359:     */   
/*  360:     */   public void setPassword(char[] password)
/*  361:     */     throws ZipException
/*  362:     */   {
/*  363: 661 */     if (this.zipModel == null)
/*  364:     */     {
/*  365: 662 */       readZipInfo();
/*  366: 663 */       if (this.zipModel == null) {
/*  367: 664 */         throw new ZipException("Zip Model is null");
/*  368:     */       }
/*  369:     */     }
/*  370: 668 */     if ((this.zipModel.getCentralDirectory() == null) || (this.zipModel.getCentralDirectory().getFileHeaders() == null)) {
/*  371: 669 */       throw new ZipException("invalid zip file");
/*  372:     */     }
/*  373: 672 */     for (int i = 0; i < this.zipModel.getCentralDirectory().getFileHeaders().size(); i++) {
/*  374: 673 */       if ((this.zipModel.getCentralDirectory().getFileHeaders().get(i) != null) && 
/*  375: 674 */         (((FileHeader)this.zipModel.getCentralDirectory().getFileHeaders().get(i)).isEncrypted())) {
/*  376: 675 */         ((FileHeader)this.zipModel.getCentralDirectory().getFileHeaders().get(i)).setPassword(password);
/*  377:     */       }
/*  378:     */     }
/*  379:     */   }
/*  380:     */   
/*  381:     */   public List getFileHeaders()
/*  382:     */     throws ZipException
/*  383:     */   {
/*  384: 688 */     readZipInfo();
/*  385: 689 */     if ((this.zipModel == null) || (this.zipModel.getCentralDirectory() == null)) {
/*  386: 690 */       return null;
/*  387:     */     }
/*  388: 692 */     return this.zipModel.getCentralDirectory().getFileHeaders();
/*  389:     */   }
/*  390:     */   
/*  391:     */   public FileHeader getFileHeader(String fileName)
/*  392:     */     throws ZipException
/*  393:     */   {
/*  394: 703 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(fileName)) {
/*  395: 704 */       throw new ZipException("input file name is emtpy or null, cannot get FileHeader");
/*  396:     */     }
/*  397: 707 */     readZipInfo();
/*  398: 708 */     if ((this.zipModel == null) || (this.zipModel.getCentralDirectory() == null)) {
/*  399: 709 */       return null;
/*  400:     */     }
/*  401: 712 */     return Zip4jUtil.getFileHeader(this.zipModel, fileName);
/*  402:     */   }
/*  403:     */   
/*  404:     */   public boolean isEncrypted()
/*  405:     */     throws ZipException
/*  406:     */   {
/*  407: 721 */     if (this.zipModel == null)
/*  408:     */     {
/*  409: 722 */       readZipInfo();
/*  410: 723 */       if (this.zipModel == null) {
/*  411: 724 */         throw new ZipException("Zip Model is null");
/*  412:     */       }
/*  413:     */     }
/*  414: 728 */     if ((this.zipModel.getCentralDirectory() == null) || (this.zipModel.getCentralDirectory().getFileHeaders() == null)) {
/*  415: 729 */       throw new ZipException("invalid zip file");
/*  416:     */     }
/*  417: 732 */     ArrayList fileHeaderList = this.zipModel.getCentralDirectory().getFileHeaders();
/*  418: 733 */     for (int i = 0; i < fileHeaderList.size(); i++)
/*  419:     */     {
/*  420: 734 */       FileHeader fileHeader = (FileHeader)fileHeaderList.get(i);
/*  421: 735 */       if ((fileHeader != null) && 
/*  422: 736 */         (fileHeader.isEncrypted()))
/*  423:     */       {
/*  424: 737 */         this.isEncrypted = true;
/*  425: 738 */         break;
/*  426:     */       }
/*  427:     */     }
/*  428: 743 */     return this.isEncrypted;
/*  429:     */   }
/*  430:     */   
/*  431:     */   public boolean isSplitArchive()
/*  432:     */     throws ZipException
/*  433:     */   {
/*  434: 753 */     if (this.zipModel == null)
/*  435:     */     {
/*  436: 754 */       readZipInfo();
/*  437: 755 */       if (this.zipModel == null) {
/*  438: 756 */         throw new ZipException("Zip Model is null");
/*  439:     */       }
/*  440:     */     }
/*  441: 760 */     return this.zipModel.isSplitArchive();
/*  442:     */   }
/*  443:     */   
/*  444:     */   public void removeFile(String fileName)
/*  445:     */     throws ZipException
/*  446:     */   {
/*  447: 775 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(fileName)) {
/*  448: 776 */       throw new ZipException("file name is empty or null, cannot remove file");
/*  449:     */     }
/*  450: 779 */     if ((this.zipModel == null) && 
/*  451: 780 */       (Zip4jUtil.checkFileExists(this.file))) {
/*  452: 781 */       readZipInfo();
/*  453:     */     }
/*  454: 785 */     if (this.zipModel.isSplitArchive()) {
/*  455: 786 */       throw new ZipException("Zip file format does not allow updating split/spanned files");
/*  456:     */     }
/*  457: 789 */     FileHeader fileHeader = Zip4jUtil.getFileHeader(this.zipModel, fileName);
/*  458: 790 */     if (fileHeader == null) {
/*  459: 791 */       throw new ZipException("could not find file header for file: " + fileName);
/*  460:     */     }
/*  461: 794 */     removeFile(fileHeader);
/*  462:     */   }
/*  463:     */   
/*  464:     */   public void removeFile(FileHeader fileHeader)
/*  465:     */     throws ZipException
/*  466:     */   {
/*  467: 805 */     if (fileHeader == null) {
/*  468: 806 */       throw new ZipException("file header is null, cannot remove file");
/*  469:     */     }
/*  470: 809 */     if ((this.zipModel == null) && 
/*  471: 810 */       (Zip4jUtil.checkFileExists(this.file))) {
/*  472: 811 */       readZipInfo();
/*  473:     */     }
/*  474: 815 */     if (this.zipModel.isSplitArchive()) {
/*  475: 816 */       throw new ZipException("Zip file format does not allow updating split/spanned files");
/*  476:     */     }
/*  477: 819 */     ArchiveMaintainer archiveMaintainer = new ArchiveMaintainer();
/*  478: 820 */     archiveMaintainer.initProgressMonitorForRemoveOp(this.zipModel, fileHeader, this.progressMonitor);
/*  479: 821 */     archiveMaintainer.removeZipFile(this.zipModel, fileHeader, this.progressMonitor, this.runInThread);
/*  480:     */   }
/*  481:     */   
/*  482:     */   public void mergeSplitFiles(File outputZipFile)
/*  483:     */     throws ZipException
/*  484:     */   {
/*  485: 831 */     if (outputZipFile == null) {
/*  486: 832 */       throw new ZipException("outputZipFile is null, cannot merge split files");
/*  487:     */     }
/*  488: 835 */     if (outputZipFile.exists()) {
/*  489: 836 */       throw new ZipException("output Zip File already exists");
/*  490:     */     }
/*  491: 839 */     checkZipModel();
/*  492: 841 */     if (this.zipModel == null) {
/*  493: 842 */       throw new ZipException("zip model is null, corrupt zip file?");
/*  494:     */     }
/*  495: 845 */     ArchiveMaintainer archiveMaintainer = new ArchiveMaintainer();
/*  496: 846 */     archiveMaintainer.initProgressMonitorForMergeOp(this.zipModel, this.progressMonitor);
/*  497: 847 */     archiveMaintainer.mergeSplitZipFiles(this.zipModel, outputZipFile, this.progressMonitor, this.runInThread);
/*  498:     */   }
/*  499:     */   
/*  500:     */   public void setComment(String comment)
/*  501:     */     throws ZipException
/*  502:     */   {
/*  503: 856 */     if (comment == null) {
/*  504: 857 */       throw new ZipException("input comment is null, cannot update zip file");
/*  505:     */     }
/*  506: 860 */     if (!Zip4jUtil.checkFileExists(this.file)) {
/*  507: 861 */       throw new ZipException("zip file does not exist, cannot set comment for zip file");
/*  508:     */     }
/*  509: 864 */     readZipInfo();
/*  510: 866 */     if (this.zipModel == null) {
/*  511: 867 */       throw new ZipException("zipModel is null, cannot update zip file");
/*  512:     */     }
/*  513: 870 */     if (this.zipModel.getEndCentralDirRecord() == null) {
/*  514: 871 */       throw new ZipException("end of central directory is null, cannot set comment");
/*  515:     */     }
/*  516: 874 */     ArchiveMaintainer archiveMaintainer = new ArchiveMaintainer();
/*  517: 875 */     archiveMaintainer.setComment(this.zipModel, comment);
/*  518:     */   }
/*  519:     */   
/*  520:     */   public String getComment()
/*  521:     */     throws ZipException
/*  522:     */   {
/*  523: 884 */     return getComment(null);
/*  524:     */   }
/*  525:     */   
/*  526:     */   public String getComment(String encoding)
/*  527:     */     throws ZipException
/*  528:     */   {
/*  529: 894 */     if (encoding == null) {
/*  530: 895 */       if (Zip4jUtil.isSupportedCharset("windows-1254")) {
/*  531: 896 */         encoding = "windows-1254";
/*  532:     */       } else {
/*  533: 898 */         encoding = InternalZipConstants.CHARSET_DEFAULT;
/*  534:     */       }
/*  535:     */     }
/*  536: 902 */     if (Zip4jUtil.checkFileExists(this.file)) {
/*  537: 903 */       checkZipModel();
/*  538:     */     } else {
/*  539: 905 */       throw new ZipException("zip file does not exist, cannot read comment");
/*  540:     */     }
/*  541: 908 */     if (this.zipModel == null) {
/*  542: 909 */       throw new ZipException("zip model is null, cannot read comment");
/*  543:     */     }
/*  544: 912 */     if (this.zipModel.getEndCentralDirRecord() == null) {
/*  545: 913 */       throw new ZipException("end of central directory record is null, cannot read comment");
/*  546:     */     }
/*  547: 916 */     if ((this.zipModel.getEndCentralDirRecord().getCommentBytes() == null) || 
/*  548: 917 */       (this.zipModel.getEndCentralDirRecord().getCommentBytes().length <= 0)) {
/*  549: 918 */       return null;
/*  550:     */     }
/*  551:     */     try
/*  552:     */     {
/*  553: 922 */       return new String(this.zipModel.getEndCentralDirRecord().getCommentBytes(), encoding);
/*  554:     */     }
/*  555:     */     catch (UnsupportedEncodingException e)
/*  556:     */     {
/*  557: 924 */       throw new ZipException(e);
/*  558:     */     }
/*  559:     */   }
/*  560:     */   
/*  561:     */   private void checkZipModel()
/*  562:     */     throws ZipException
/*  563:     */   {
/*  564: 933 */     if (this.zipModel == null) {
/*  565: 934 */       if (Zip4jUtil.checkFileExists(this.file)) {
/*  566: 935 */         readZipInfo();
/*  567:     */       } else {
/*  568: 937 */         createNewZipModel();
/*  569:     */       }
/*  570:     */     }
/*  571:     */   }
/*  572:     */   
/*  573:     */   private void createNewZipModel()
/*  574:     */   {
/*  575: 947 */     this.zipModel = new ZipModel();
/*  576: 948 */     this.zipModel.setZipFile(this.file);
/*  577: 949 */     this.zipModel.setFileNameCharset(this.fileNameCharset);
/*  578:     */   }
/*  579:     */   
/*  580:     */   public void setFileNameCharset(String charsetName)
/*  581:     */     throws ZipException
/*  582:     */   {
/*  583: 959 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(charsetName)) {
/*  584: 960 */       throw new ZipException("null or empty charset name");
/*  585:     */     }
/*  586: 963 */     if (!Zip4jUtil.isSupportedCharset(charsetName)) {
/*  587: 964 */       throw new ZipException("unsupported charset: " + charsetName);
/*  588:     */     }
/*  589: 967 */     this.fileNameCharset = charsetName;
/*  590:     */   }
/*  591:     */   
/*  592:     */   public ZipInputStream getInputStream(FileHeader fileHeader)
/*  593:     */     throws ZipException
/*  594:     */   {
/*  595: 979 */     if (fileHeader == null) {
/*  596: 980 */       throw new ZipException("FileHeader is null, cannot get InputStream");
/*  597:     */     }
/*  598: 983 */     checkZipModel();
/*  599: 985 */     if (this.zipModel == null) {
/*  600: 986 */       throw new ZipException("zip model is null, cannot get inputstream");
/*  601:     */     }
/*  602: 989 */     Unzip unzip = new Unzip(this.zipModel);
/*  603: 990 */     return unzip.getInputStream(fileHeader);
/*  604:     */   }
/*  605:     */   
/*  606:     */   public boolean isValidZipFile()
/*  607:     */   {
/*  608:     */     try
/*  609:     */     {
/*  610:1002 */       readZipInfo();
/*  611:1003 */       return true;
/*  612:     */     }
/*  613:     */     catch (Exception e) {}
/*  614:1005 */     return false;
/*  615:     */   }
/*  616:     */   
/*  617:     */   public ArrayList getSplitZipFiles()
/*  618:     */     throws ZipException
/*  619:     */   {
/*  620:1018 */     checkZipModel();
/*  621:1019 */     return Zip4jUtil.getSplitZipFiles(this.zipModel);
/*  622:     */   }
/*  623:     */   
/*  624:     */   public ProgressMonitor getProgressMonitor()
/*  625:     */   {
/*  626:1023 */     return this.progressMonitor;
/*  627:     */   }
/*  628:     */   
/*  629:     */   public boolean isRunInThread()
/*  630:     */   {
/*  631:1027 */     return this.runInThread;
/*  632:     */   }
/*  633:     */   
/*  634:     */   public void setRunInThread(boolean runInThread)
/*  635:     */   {
/*  636:1031 */     this.runInThread = runInThread;
/*  637:     */   }
/*  638:     */   
/*  639:     */   public File getFile()
/*  640:     */   {
/*  641:1039 */     return new File(this.file);
/*  642:     */   }
/*  643:     */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.core.ZipFile
 * JD-Core Version:    0.7.0.1
 */