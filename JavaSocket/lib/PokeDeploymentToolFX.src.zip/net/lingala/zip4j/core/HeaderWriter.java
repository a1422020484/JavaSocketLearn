/*   1:    */ package net.lingala.zip4j.core;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.OutputStream;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.List;
/*   8:    */ import net.lingala.zip4j.exception.ZipException;
/*   9:    */ import net.lingala.zip4j.io.SplitOutputStream;
/*  10:    */ import net.lingala.zip4j.model.AESExtraDataRecord;
/*  11:    */ import net.lingala.zip4j.model.CentralDirectory;
/*  12:    */ import net.lingala.zip4j.model.EndCentralDirRecord;
/*  13:    */ import net.lingala.zip4j.model.FileHeader;
/*  14:    */ import net.lingala.zip4j.model.LocalFileHeader;
/*  15:    */ import net.lingala.zip4j.model.Zip64EndCentralDirLocator;
/*  16:    */ import net.lingala.zip4j.model.Zip64EndCentralDirRecord;
/*  17:    */ import net.lingala.zip4j.model.ZipModel;
/*  18:    */ import net.lingala.zip4j.util.Raw;
/*  19:    */ import net.lingala.zip4j.util.Zip4jUtil;
/*  20:    */ 
/*  21:    */ public class HeaderWriter
/*  22:    */ {
/*  23: 39 */   private final int ZIP64_EXTRA_BUF = 50;
/*  24:    */   
/*  25:    */   public int writeLocalFileHeader(ZipModel zipModel, LocalFileHeader localFileHeader, OutputStream outputStream)
/*  26:    */     throws ZipException
/*  27:    */   {
/*  28: 43 */     if (localFileHeader == null) {
/*  29: 44 */       throw new ZipException("input parameters are null, cannot write local file header");
/*  30:    */     }
/*  31:    */     try
/*  32:    */     {
/*  33: 48 */       ArrayList byteArrayList = new ArrayList();
/*  34:    */       
/*  35: 50 */       byte[] shortByte = new byte[2];
/*  36: 51 */       byte[] intByte = new byte[4];
/*  37: 52 */       byte[] longByte = new byte[8];
/*  38: 53 */       byte[] emptyLongByte = { 0, 0, 0, 0, 0, 0, 0, 0 };
/*  39:    */       
/*  40: 55 */       Raw.writeIntLittleEndian(intByte, 0, localFileHeader.getSignature());
/*  41: 56 */       copyByteArrayToArrayList(intByte, byteArrayList);
/*  42: 57 */       Raw.writeShortLittleEndian(shortByte, 0, (short)localFileHeader.getVersionNeededToExtract());
/*  43: 58 */       copyByteArrayToArrayList(shortByte, byteArrayList);
/*  44:    */       
/*  45: 60 */       copyByteArrayToArrayList(localFileHeader.getGeneralPurposeFlag(), byteArrayList);
/*  46:    */       
/*  47: 62 */       Raw.writeShortLittleEndian(shortByte, 0, (short)localFileHeader.getCompressionMethod());
/*  48: 63 */       copyByteArrayToArrayList(shortByte, byteArrayList);
/*  49:    */       
/*  50: 65 */       int dateTime = localFileHeader.getLastModFileTime();
/*  51: 66 */       Raw.writeIntLittleEndian(intByte, 0, dateTime);
/*  52: 67 */       copyByteArrayToArrayList(intByte, byteArrayList);
/*  53:    */       
/*  54: 69 */       Raw.writeIntLittleEndian(intByte, 0, (int)localFileHeader.getCrc32());
/*  55: 70 */       copyByteArrayToArrayList(intByte, byteArrayList);
/*  56: 71 */       boolean writingZip64Rec = false;
/*  57:    */       
/*  58:    */ 
/*  59: 74 */       long uncompressedSize = localFileHeader.getUncompressedSize();
/*  60: 75 */       if (uncompressedSize + 50L >= 4294967295L)
/*  61:    */       {
/*  62: 76 */         Raw.writeLongLittleEndian(longByte, 0, 4294967295L);
/*  63: 77 */         System.arraycopy(longByte, 0, intByte, 0, 4);
/*  64:    */         
/*  65:    */ 
/*  66:    */ 
/*  67: 81 */         copyByteArrayToArrayList(intByte, byteArrayList);
/*  68:    */         
/*  69: 83 */         copyByteArrayToArrayList(intByte, byteArrayList);
/*  70: 84 */         zipModel.setZip64Format(true);
/*  71: 85 */         writingZip64Rec = true;
/*  72: 86 */         localFileHeader.setWriteComprSizeInZip64ExtraRecord(true);
/*  73:    */       }
/*  74:    */       else
/*  75:    */       {
/*  76: 88 */         Raw.writeLongLittleEndian(longByte, 0, localFileHeader.getCompressedSize());
/*  77: 89 */         System.arraycopy(longByte, 0, intByte, 0, 4);
/*  78: 90 */         copyByteArrayToArrayList(intByte, byteArrayList);
/*  79:    */         
/*  80: 92 */         Raw.writeLongLittleEndian(longByte, 0, localFileHeader.getUncompressedSize());
/*  81: 93 */         System.arraycopy(longByte, 0, intByte, 0, 4);
/*  82:    */         
/*  83: 95 */         copyByteArrayToArrayList(intByte, byteArrayList);
/*  84:    */         
/*  85: 97 */         localFileHeader.setWriteComprSizeInZip64ExtraRecord(false);
/*  86:    */       }
/*  87: 99 */       Raw.writeShortLittleEndian(shortByte, 0, (short)localFileHeader.getFileNameLength());
/*  88:100 */       copyByteArrayToArrayList(shortByte, byteArrayList);
/*  89:    */       
/*  90:102 */       int extraFieldLength = 0;
/*  91:103 */       if (writingZip64Rec) {
/*  92:104 */         extraFieldLength += 20;
/*  93:    */       }
/*  94:106 */       if (localFileHeader.getAesExtraDataRecord() != null) {
/*  95:107 */         extraFieldLength += 11;
/*  96:    */       }
/*  97:109 */       Raw.writeShortLittleEndian(shortByte, 0, (short)extraFieldLength);
/*  98:110 */       copyByteArrayToArrayList(shortByte, byteArrayList);
/*  99:111 */       if (Zip4jUtil.isStringNotNullAndNotEmpty(zipModel.getFileNameCharset()))
/* 100:    */       {
/* 101:112 */         byte[] fileNameBytes = localFileHeader.getFileName().getBytes(zipModel.getFileNameCharset());
/* 102:113 */         copyByteArrayToArrayList(fileNameBytes, byteArrayList);
/* 103:    */       }
/* 104:    */       else
/* 105:    */       {
/* 106:115 */         copyByteArrayToArrayList(Zip4jUtil.convertCharset(localFileHeader.getFileName()), byteArrayList);
/* 107:    */       }
/* 108:121 */       if (writingZip64Rec)
/* 109:    */       {
/* 110:125 */         Raw.writeShortLittleEndian(shortByte, 0, (short)1);
/* 111:126 */         copyByteArrayToArrayList(shortByte, byteArrayList);
/* 112:    */         
/* 113:    */ 
/* 114:    */ 
/* 115:130 */         Raw.writeShortLittleEndian(shortByte, 0, (short)16);
/* 116:131 */         copyByteArrayToArrayList(shortByte, byteArrayList);
/* 117:    */         
/* 118:133 */         Raw.writeLongLittleEndian(longByte, 0, localFileHeader.getUncompressedSize());
/* 119:134 */         copyByteArrayToArrayList(longByte, byteArrayList);
/* 120:    */         
/* 121:136 */         copyByteArrayToArrayList(emptyLongByte, byteArrayList);
/* 122:    */       }
/* 123:139 */       if (localFileHeader.getAesExtraDataRecord() != null)
/* 124:    */       {
/* 125:140 */         AESExtraDataRecord aesExtraDataRecord = localFileHeader.getAesExtraDataRecord();
/* 126:    */         
/* 127:142 */         Raw.writeShortLittleEndian(shortByte, 0, (short)(int)aesExtraDataRecord.getSignature());
/* 128:143 */         copyByteArrayToArrayList(shortByte, byteArrayList);
/* 129:    */         
/* 130:145 */         Raw.writeShortLittleEndian(shortByte, 0, (short)aesExtraDataRecord.getDataSize());
/* 131:146 */         copyByteArrayToArrayList(shortByte, byteArrayList);
/* 132:    */         
/* 133:148 */         Raw.writeShortLittleEndian(shortByte, 0, (short)aesExtraDataRecord.getVersionNumber());
/* 134:149 */         copyByteArrayToArrayList(shortByte, byteArrayList);
/* 135:    */         
/* 136:151 */         copyByteArrayToArrayList(aesExtraDataRecord.getVendorID().getBytes(), byteArrayList);
/* 137:    */         
/* 138:153 */         byte[] aesStrengthBytes = new byte[1];
/* 139:154 */         aesStrengthBytes[0] = ((byte)aesExtraDataRecord.getAesStrength());
/* 140:155 */         copyByteArrayToArrayList(aesStrengthBytes, byteArrayList);
/* 141:    */         
/* 142:157 */         Raw.writeShortLittleEndian(shortByte, 0, (short)aesExtraDataRecord.getCompressionMethod());
/* 143:158 */         copyByteArrayToArrayList(shortByte, byteArrayList);
/* 144:    */       }
/* 145:160 */       byte[] lhBytes = byteArrayListToByteArray(byteArrayList);
/* 146:161 */       outputStream.write(lhBytes);
/* 147:162 */       return lhBytes.length;
/* 148:    */     }
/* 149:    */     catch (ZipException e)
/* 150:    */     {
/* 151:164 */       throw e;
/* 152:    */     }
/* 153:    */     catch (Exception e)
/* 154:    */     {
/* 155:166 */       throw new ZipException(e);
/* 156:    */     }
/* 157:    */   }
/* 158:    */   
/* 159:    */   public int writeExtendedLocalHeader(LocalFileHeader localFileHeader, OutputStream outputStream)
/* 160:    */     throws ZipException, IOException
/* 161:    */   {
/* 162:172 */     if ((localFileHeader == null) || (outputStream == null)) {
/* 163:173 */       throw new ZipException("input parameters is null, cannot write extended local header");
/* 164:    */     }
/* 165:176 */     ArrayList byteArrayList = new ArrayList();
/* 166:177 */     byte[] intByte = new byte[4];
/* 167:    */     
/* 168:    */ 
/* 169:180 */     Raw.writeIntLittleEndian(intByte, 0, 134695760);
/* 170:181 */     copyByteArrayToArrayList(intByte, byteArrayList);
/* 171:    */     
/* 172:    */ 
/* 173:184 */     Raw.writeIntLittleEndian(intByte, 0, (int)localFileHeader.getCrc32());
/* 174:185 */     copyByteArrayToArrayList(intByte, byteArrayList);
/* 175:    */     
/* 176:    */ 
/* 177:188 */     long compressedSize = localFileHeader.getCompressedSize();
/* 178:189 */     if (compressedSize >= 2147483647L) {
/* 179:190 */       compressedSize = 2147483647L;
/* 180:    */     }
/* 181:192 */     Raw.writeIntLittleEndian(intByte, 0, (int)compressedSize);
/* 182:193 */     copyByteArrayToArrayList(intByte, byteArrayList);
/* 183:    */     
/* 184:    */ 
/* 185:196 */     long uncompressedSize = localFileHeader.getUncompressedSize();
/* 186:197 */     if (uncompressedSize >= 2147483647L) {
/* 187:198 */       uncompressedSize = 2147483647L;
/* 188:    */     }
/* 189:200 */     Raw.writeIntLittleEndian(intByte, 0, (int)uncompressedSize);
/* 190:201 */     copyByteArrayToArrayList(intByte, byteArrayList);
/* 191:    */     
/* 192:203 */     byte[] extLocHdrBytes = byteArrayListToByteArray(byteArrayList);
/* 193:204 */     outputStream.write(extLocHdrBytes);
/* 194:205 */     return extLocHdrBytes.length;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public void finalizeZipFile(ZipModel zipModel, OutputStream outputStream)
/* 198:    */     throws ZipException
/* 199:    */   {
/* 200:216 */     if ((zipModel == null) || (outputStream == null)) {
/* 201:217 */       throw new ZipException("input parameters is null, cannot finalize zip file");
/* 202:    */     }
/* 203:    */     try
/* 204:    */     {
/* 205:221 */       processHeaderData(zipModel, outputStream);
/* 206:    */       
/* 207:223 */       long offsetCentralDir = zipModel.getEndCentralDirRecord().getOffsetOfStartOfCentralDir();
/* 208:    */       
/* 209:225 */       List headerBytesList = new ArrayList();
/* 210:    */       
/* 211:227 */       int sizeOfCentralDir = writeCentralDirectory(zipModel, outputStream, headerBytesList);
/* 212:229 */       if (zipModel.isZip64Format())
/* 213:    */       {
/* 214:230 */         if (zipModel.getZip64EndCentralDirRecord() == null) {
/* 215:231 */           zipModel.setZip64EndCentralDirRecord(new Zip64EndCentralDirRecord());
/* 216:    */         }
/* 217:233 */         if (zipModel.getZip64EndCentralDirLocator() == null) {
/* 218:234 */           zipModel.setZip64EndCentralDirLocator(new Zip64EndCentralDirLocator());
/* 219:    */         }
/* 220:237 */         zipModel.getZip64EndCentralDirLocator().setOffsetZip64EndOfCentralDirRec(offsetCentralDir + sizeOfCentralDir);
/* 221:238 */         if ((outputStream instanceof SplitOutputStream))
/* 222:    */         {
/* 223:239 */           zipModel.getZip64EndCentralDirLocator().setNoOfDiskStartOfZip64EndOfCentralDirRec(((SplitOutputStream)outputStream).getCurrSplitFileCounter());
/* 224:240 */           zipModel.getZip64EndCentralDirLocator().setTotNumberOfDiscs(((SplitOutputStream)outputStream).getCurrSplitFileCounter() + 1);
/* 225:    */         }
/* 226:    */         else
/* 227:    */         {
/* 228:242 */           zipModel.getZip64EndCentralDirLocator().setNoOfDiskStartOfZip64EndOfCentralDirRec(0);
/* 229:243 */           zipModel.getZip64EndCentralDirLocator().setTotNumberOfDiscs(1);
/* 230:    */         }
/* 231:246 */         writeZip64EndOfCentralDirectoryRecord(zipModel, outputStream, sizeOfCentralDir, offsetCentralDir, headerBytesList);
/* 232:    */         
/* 233:248 */         writeZip64EndOfCentralDirectoryLocator(zipModel, outputStream, headerBytesList);
/* 234:    */       }
/* 235:251 */       writeEndOfCentralDirectoryRecord(zipModel, outputStream, sizeOfCentralDir, offsetCentralDir, headerBytesList);
/* 236:    */       
/* 237:253 */       writeZipHeaderBytes(zipModel, outputStream, byteArrayListToByteArray(headerBytesList));
/* 238:    */     }
/* 239:    */     catch (ZipException e)
/* 240:    */     {
/* 241:255 */       throw e;
/* 242:    */     }
/* 243:    */     catch (Exception e)
/* 244:    */     {
/* 245:257 */       throw new ZipException(e);
/* 246:    */     }
/* 247:    */   }
/* 248:    */   
/* 249:    */   public void finalizeZipFileWithoutValidations(ZipModel zipModel, OutputStream outputStream)
/* 250:    */     throws ZipException
/* 251:    */   {
/* 252:271 */     if ((zipModel == null) || (outputStream == null)) {
/* 253:272 */       throw new ZipException("input parameters is null, cannot finalize zip file without validations");
/* 254:    */     }
/* 255:    */     try
/* 256:    */     {
/* 257:277 */       List headerBytesList = new ArrayList();
/* 258:    */       
/* 259:279 */       long offsetCentralDir = zipModel.getEndCentralDirRecord().getOffsetOfStartOfCentralDir();
/* 260:    */       
/* 261:281 */       int sizeOfCentralDir = writeCentralDirectory(zipModel, outputStream, headerBytesList);
/* 262:283 */       if (zipModel.isZip64Format())
/* 263:    */       {
/* 264:284 */         if (zipModel.getZip64EndCentralDirRecord() == null) {
/* 265:285 */           zipModel.setZip64EndCentralDirRecord(new Zip64EndCentralDirRecord());
/* 266:    */         }
/* 267:287 */         if (zipModel.getZip64EndCentralDirLocator() == null) {
/* 268:288 */           zipModel.setZip64EndCentralDirLocator(new Zip64EndCentralDirLocator());
/* 269:    */         }
/* 270:291 */         zipModel.getZip64EndCentralDirLocator().setOffsetZip64EndOfCentralDirRec(offsetCentralDir + sizeOfCentralDir);
/* 271:    */         
/* 272:293 */         writeZip64EndOfCentralDirectoryRecord(zipModel, outputStream, sizeOfCentralDir, offsetCentralDir, headerBytesList);
/* 273:294 */         writeZip64EndOfCentralDirectoryLocator(zipModel, outputStream, headerBytesList);
/* 274:    */       }
/* 275:297 */       writeEndOfCentralDirectoryRecord(zipModel, outputStream, sizeOfCentralDir, offsetCentralDir, headerBytesList);
/* 276:    */       
/* 277:299 */       writeZipHeaderBytes(zipModel, outputStream, byteArrayListToByteArray(headerBytesList));
/* 278:    */     }
/* 279:    */     catch (ZipException e)
/* 280:    */     {
/* 281:301 */       throw e;
/* 282:    */     }
/* 283:    */     catch (Exception e)
/* 284:    */     {
/* 285:303 */       throw new ZipException(e);
/* 286:    */     }
/* 287:    */   }
/* 288:    */   
/* 289:    */   private void writeZipHeaderBytes(ZipModel zipModel, OutputStream outputStream, byte[] buff)
/* 290:    */     throws ZipException
/* 291:    */   {
/* 292:314 */     if (buff == null) {
/* 293:315 */       throw new ZipException("invalid buff to write as zip headers");
/* 294:    */     }
/* 295:    */     try
/* 296:    */     {
/* 297:319 */       if (((outputStream instanceof SplitOutputStream)) && 
/* 298:320 */         (((SplitOutputStream)outputStream).checkBuffSizeAndStartNextSplitFile(buff.length)))
/* 299:    */       {
/* 300:321 */         finalizeZipFile(zipModel, outputStream);
/* 301:322 */         return;
/* 302:    */       }
/* 303:326 */       outputStream.write(buff);
/* 304:    */     }
/* 305:    */     catch (IOException e)
/* 306:    */     {
/* 307:328 */       throw new ZipException(e);
/* 308:    */     }
/* 309:    */   }
/* 310:    */   
/* 311:    */   private void processHeaderData(ZipModel zipModel, OutputStream outputStream)
/* 312:    */     throws ZipException
/* 313:    */   {
/* 314:    */     try
/* 315:    */     {
/* 316:340 */       int currSplitFileCounter = 0;
/* 317:341 */       if ((outputStream instanceof SplitOutputStream))
/* 318:    */       {
/* 319:342 */         zipModel.getEndCentralDirRecord().setOffsetOfStartOfCentralDir(((SplitOutputStream)outputStream)
/* 320:343 */           .getFilePointer());
/* 321:344 */         currSplitFileCounter = ((SplitOutputStream)outputStream).getCurrSplitFileCounter();
/* 322:    */       }
/* 323:348 */       if (zipModel.isZip64Format())
/* 324:    */       {
/* 325:349 */         if (zipModel.getZip64EndCentralDirRecord() == null) {
/* 326:350 */           zipModel.setZip64EndCentralDirRecord(new Zip64EndCentralDirRecord());
/* 327:    */         }
/* 328:352 */         if (zipModel.getZip64EndCentralDirLocator() == null) {
/* 329:353 */           zipModel.setZip64EndCentralDirLocator(new Zip64EndCentralDirLocator());
/* 330:    */         }
/* 331:356 */         zipModel.getZip64EndCentralDirLocator().setNoOfDiskStartOfZip64EndOfCentralDirRec(currSplitFileCounter);
/* 332:357 */         zipModel.getZip64EndCentralDirLocator().setTotNumberOfDiscs(currSplitFileCounter + 1);
/* 333:    */       }
/* 334:359 */       zipModel.getEndCentralDirRecord().setNoOfThisDisk(currSplitFileCounter);
/* 335:360 */       zipModel.getEndCentralDirRecord().setNoOfThisDiskStartOfCentralDir(currSplitFileCounter);
/* 336:    */     }
/* 337:    */     catch (IOException e)
/* 338:    */     {
/* 339:362 */       throw new ZipException(e);
/* 340:    */     }
/* 341:    */   }
/* 342:    */   
/* 343:    */   private int writeCentralDirectory(ZipModel zipModel, OutputStream outputStream, List headerBytesList)
/* 344:    */     throws ZipException
/* 345:    */   {
/* 346:376 */     if ((zipModel == null) || (outputStream == null)) {
/* 347:377 */       throw new ZipException("input parameters is null, cannot write central directory");
/* 348:    */     }
/* 349:380 */     if ((zipModel.getCentralDirectory() == null) || 
/* 350:381 */       (zipModel.getCentralDirectory().getFileHeaders() == null) || 
/* 351:382 */       (zipModel.getCentralDirectory().getFileHeaders().size() <= 0)) {
/* 352:383 */       return 0;
/* 353:    */     }
/* 354:386 */     int sizeOfCentralDir = 0;
/* 355:387 */     for (int i = 0; i < zipModel.getCentralDirectory().getFileHeaders().size(); i++)
/* 356:    */     {
/* 357:388 */       FileHeader fileHeader = (FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(i);
/* 358:389 */       int sizeOfFileHeader = writeFileHeader(zipModel, fileHeader, outputStream, headerBytesList);
/* 359:390 */       sizeOfCentralDir += sizeOfFileHeader;
/* 360:    */     }
/* 361:392 */     return sizeOfCentralDir;
/* 362:    */   }
/* 363:    */   
/* 364:    */   private int writeFileHeader(ZipModel zipModel, FileHeader fileHeader, OutputStream outputStream, List headerBytesList)
/* 365:    */     throws ZipException
/* 366:    */   {
/* 367:398 */     if ((fileHeader == null) || (outputStream == null)) {
/* 368:399 */       throw new ZipException("input parameters is null, cannot write local file header");
/* 369:    */     }
/* 370:    */     try
/* 371:    */     {
/* 372:403 */       int sizeOfFileHeader = 0;
/* 373:    */       
/* 374:405 */       byte[] shortByte = new byte[2];
/* 375:406 */       byte[] intByte = new byte[4];
/* 376:407 */       byte[] longByte = new byte[8];
/* 377:408 */       byte[] emptyShortByte = { 0, 0 };
/* 378:409 */       byte[] emptyIntByte = { 0, 0, 0, 0 };
/* 379:    */       
/* 380:411 */       boolean writeZip64FileSize = false;
/* 381:412 */       boolean writeZip64OffsetLocalHeader = false;
/* 382:    */       
/* 383:414 */       Raw.writeIntLittleEndian(intByte, 0, fileHeader.getSignature());
/* 384:415 */       copyByteArrayToArrayList(intByte, headerBytesList);
/* 385:416 */       sizeOfFileHeader += 4;
/* 386:    */       
/* 387:418 */       Raw.writeShortLittleEndian(shortByte, 0, (short)fileHeader.getVersionMadeBy());
/* 388:419 */       copyByteArrayToArrayList(shortByte, headerBytesList);
/* 389:420 */       sizeOfFileHeader += 2;
/* 390:    */       
/* 391:422 */       Raw.writeShortLittleEndian(shortByte, 0, (short)fileHeader.getVersionNeededToExtract());
/* 392:423 */       copyByteArrayToArrayList(shortByte, headerBytesList);
/* 393:424 */       sizeOfFileHeader += 2;
/* 394:    */       
/* 395:426 */       copyByteArrayToArrayList(fileHeader.getGeneralPurposeFlag(), headerBytesList);
/* 396:427 */       sizeOfFileHeader += 2;
/* 397:    */       
/* 398:429 */       Raw.writeShortLittleEndian(shortByte, 0, (short)fileHeader.getCompressionMethod());
/* 399:430 */       copyByteArrayToArrayList(shortByte, headerBytesList);
/* 400:431 */       sizeOfFileHeader += 2;
/* 401:    */       
/* 402:433 */       int dateTime = fileHeader.getLastModFileTime();
/* 403:434 */       Raw.writeIntLittleEndian(intByte, 0, dateTime);
/* 404:435 */       copyByteArrayToArrayList(intByte, headerBytesList);
/* 405:436 */       sizeOfFileHeader += 4;
/* 406:    */       
/* 407:438 */       Raw.writeIntLittleEndian(intByte, 0, (int)fileHeader.getCrc32());
/* 408:439 */       copyByteArrayToArrayList(intByte, headerBytesList);
/* 409:440 */       sizeOfFileHeader += 4;
/* 410:442 */       if ((fileHeader.getCompressedSize() >= 4294967295L) || 
/* 411:443 */         (fileHeader.getUncompressedSize() + 50L >= 4294967295L))
/* 412:    */       {
/* 413:444 */         Raw.writeLongLittleEndian(longByte, 0, 4294967295L);
/* 414:445 */         System.arraycopy(longByte, 0, intByte, 0, 4);
/* 415:    */         
/* 416:447 */         copyByteArrayToArrayList(intByte, headerBytesList);
/* 417:448 */         sizeOfFileHeader += 4;
/* 418:    */         
/* 419:450 */         copyByteArrayToArrayList(intByte, headerBytesList);
/* 420:451 */         sizeOfFileHeader += 4;
/* 421:    */         
/* 422:453 */         writeZip64FileSize = true;
/* 423:    */       }
/* 424:    */       else
/* 425:    */       {
/* 426:455 */         Raw.writeLongLittleEndian(longByte, 0, fileHeader.getCompressedSize());
/* 427:456 */         System.arraycopy(longByte, 0, intByte, 0, 4);
/* 428:    */         
/* 429:458 */         copyByteArrayToArrayList(intByte, headerBytesList);
/* 430:459 */         sizeOfFileHeader += 4;
/* 431:    */         
/* 432:461 */         Raw.writeLongLittleEndian(longByte, 0, fileHeader.getUncompressedSize());
/* 433:462 */         System.arraycopy(longByte, 0, intByte, 0, 4);
/* 434:    */         
/* 435:464 */         copyByteArrayToArrayList(intByte, headerBytesList);
/* 436:465 */         sizeOfFileHeader += 4;
/* 437:    */       }
/* 438:468 */       Raw.writeShortLittleEndian(shortByte, 0, (short)fileHeader.getFileNameLength());
/* 439:469 */       copyByteArrayToArrayList(shortByte, headerBytesList);
/* 440:470 */       sizeOfFileHeader += 2;
/* 441:    */       
/* 442:    */ 
/* 443:    */ 
/* 444:474 */       byte[] offsetLocalHeaderBytes = new byte[4];
/* 445:475 */       if (fileHeader.getOffsetLocalHeader() > 4294967295L)
/* 446:    */       {
/* 447:476 */         Raw.writeLongLittleEndian(longByte, 0, 4294967295L);
/* 448:477 */         System.arraycopy(longByte, 0, offsetLocalHeaderBytes, 0, 4);
/* 449:478 */         writeZip64OffsetLocalHeader = true;
/* 450:    */       }
/* 451:    */       else
/* 452:    */       {
/* 453:480 */         Raw.writeLongLittleEndian(longByte, 0, fileHeader.getOffsetLocalHeader());
/* 454:481 */         System.arraycopy(longByte, 0, offsetLocalHeaderBytes, 0, 4);
/* 455:    */       }
/* 456:485 */       int extraFieldLength = 0;
/* 457:486 */       if ((writeZip64FileSize) || (writeZip64OffsetLocalHeader))
/* 458:    */       {
/* 459:487 */         extraFieldLength += 4;
/* 460:488 */         if (writeZip64FileSize) {
/* 461:489 */           extraFieldLength += 16;
/* 462:    */         }
/* 463:490 */         if (writeZip64OffsetLocalHeader) {
/* 464:491 */           extraFieldLength += 8;
/* 465:    */         }
/* 466:    */       }
/* 467:493 */       if (fileHeader.getAesExtraDataRecord() != null) {
/* 468:494 */         extraFieldLength += 11;
/* 469:    */       }
/* 470:496 */       Raw.writeShortLittleEndian(shortByte, 0, (short)extraFieldLength);
/* 471:497 */       copyByteArrayToArrayList(shortByte, headerBytesList);
/* 472:498 */       sizeOfFileHeader += 2;
/* 473:    */       
/* 474:    */ 
/* 475:501 */       copyByteArrayToArrayList(emptyShortByte, headerBytesList);
/* 476:502 */       sizeOfFileHeader += 2;
/* 477:    */       
/* 478:    */ 
/* 479:505 */       Raw.writeShortLittleEndian(shortByte, 0, (short)fileHeader.getDiskNumberStart());
/* 480:506 */       copyByteArrayToArrayList(shortByte, headerBytesList);
/* 481:507 */       sizeOfFileHeader += 2;
/* 482:    */       
/* 483:    */ 
/* 484:510 */       copyByteArrayToArrayList(emptyShortByte, headerBytesList);
/* 485:511 */       sizeOfFileHeader += 2;
/* 486:514 */       if (fileHeader.getExternalFileAttr() != null) {
/* 487:515 */         copyByteArrayToArrayList(fileHeader.getExternalFileAttr(), headerBytesList);
/* 488:    */       } else {
/* 489:517 */         copyByteArrayToArrayList(emptyIntByte, headerBytesList);
/* 490:    */       }
/* 491:519 */       sizeOfFileHeader += 4;
/* 492:    */       
/* 493:    */ 
/* 494:    */ 
/* 495:523 */       copyByteArrayToArrayList(offsetLocalHeaderBytes, headerBytesList);
/* 496:524 */       sizeOfFileHeader += 4;
/* 497:526 */       if (Zip4jUtil.isStringNotNullAndNotEmpty(zipModel.getFileNameCharset()))
/* 498:    */       {
/* 499:527 */         byte[] fileNameBytes = fileHeader.getFileName().getBytes(zipModel.getFileNameCharset());
/* 500:528 */         copyByteArrayToArrayList(fileNameBytes, headerBytesList);
/* 501:529 */         sizeOfFileHeader += fileNameBytes.length;
/* 502:    */       }
/* 503:    */       else
/* 504:    */       {
/* 505:531 */         copyByteArrayToArrayList(Zip4jUtil.convertCharset(fileHeader.getFileName()), headerBytesList);
/* 506:532 */         sizeOfFileHeader += Zip4jUtil.getEncodedStringLength(fileHeader.getFileName());
/* 507:    */       }
/* 508:535 */       if ((writeZip64FileSize) || (writeZip64OffsetLocalHeader))
/* 509:    */       {
/* 510:536 */         zipModel.setZip64Format(true);
/* 511:    */         
/* 512:    */ 
/* 513:539 */         Raw.writeShortLittleEndian(shortByte, 0, (short)1);
/* 514:540 */         copyByteArrayToArrayList(shortByte, headerBytesList);
/* 515:541 */         sizeOfFileHeader += 2;
/* 516:    */         
/* 517:    */ 
/* 518:544 */         int dataSize = 0;
/* 519:546 */         if (writeZip64FileSize) {
/* 520:547 */           dataSize += 16;
/* 521:    */         }
/* 522:549 */         if (writeZip64OffsetLocalHeader) {
/* 523:550 */           dataSize += 8;
/* 524:    */         }
/* 525:553 */         Raw.writeShortLittleEndian(shortByte, 0, (short)dataSize);
/* 526:554 */         copyByteArrayToArrayList(shortByte, headerBytesList);
/* 527:555 */         sizeOfFileHeader += 2;
/* 528:557 */         if (writeZip64FileSize)
/* 529:    */         {
/* 530:558 */           Raw.writeLongLittleEndian(longByte, 0, fileHeader.getUncompressedSize());
/* 531:559 */           copyByteArrayToArrayList(longByte, headerBytesList);
/* 532:560 */           sizeOfFileHeader += 8;
/* 533:    */           
/* 534:562 */           Raw.writeLongLittleEndian(longByte, 0, fileHeader.getCompressedSize());
/* 535:563 */           copyByteArrayToArrayList(longByte, headerBytesList);
/* 536:564 */           sizeOfFileHeader += 8;
/* 537:    */         }
/* 538:567 */         if (writeZip64OffsetLocalHeader)
/* 539:    */         {
/* 540:568 */           Raw.writeLongLittleEndian(longByte, 0, fileHeader.getOffsetLocalHeader());
/* 541:569 */           copyByteArrayToArrayList(longByte, headerBytesList);
/* 542:570 */           sizeOfFileHeader += 8;
/* 543:    */         }
/* 544:    */       }
/* 545:574 */       if (fileHeader.getAesExtraDataRecord() != null)
/* 546:    */       {
/* 547:575 */         AESExtraDataRecord aesExtraDataRecord = fileHeader.getAesExtraDataRecord();
/* 548:    */         
/* 549:577 */         Raw.writeShortLittleEndian(shortByte, 0, (short)(int)aesExtraDataRecord.getSignature());
/* 550:578 */         copyByteArrayToArrayList(shortByte, headerBytesList);
/* 551:    */         
/* 552:580 */         Raw.writeShortLittleEndian(shortByte, 0, (short)aesExtraDataRecord.getDataSize());
/* 553:581 */         copyByteArrayToArrayList(shortByte, headerBytesList);
/* 554:    */         
/* 555:583 */         Raw.writeShortLittleEndian(shortByte, 0, (short)aesExtraDataRecord.getVersionNumber());
/* 556:584 */         copyByteArrayToArrayList(shortByte, headerBytesList);
/* 557:    */         
/* 558:586 */         copyByteArrayToArrayList(aesExtraDataRecord.getVendorID().getBytes(), headerBytesList);
/* 559:    */         
/* 560:588 */         byte[] aesStrengthBytes = new byte[1];
/* 561:589 */         aesStrengthBytes[0] = ((byte)aesExtraDataRecord.getAesStrength());
/* 562:590 */         copyByteArrayToArrayList(aesStrengthBytes, headerBytesList);
/* 563:    */         
/* 564:592 */         Raw.writeShortLittleEndian(shortByte, 0, (short)aesExtraDataRecord.getCompressionMethod());
/* 565:593 */         copyByteArrayToArrayList(shortByte, headerBytesList);
/* 566:    */         
/* 567:595 */         sizeOfFileHeader += 11;
/* 568:    */       }
/* 569:600 */       return sizeOfFileHeader;
/* 570:    */     }
/* 571:    */     catch (Exception e)
/* 572:    */     {
/* 573:602 */       throw new ZipException(e);
/* 574:    */     }
/* 575:    */   }
/* 576:    */   
/* 577:    */   private void writeZip64EndOfCentralDirectoryRecord(ZipModel zipModel, OutputStream outputStream, int sizeOfCentralDir, long offsetCentralDir, List headerBytesList)
/* 578:    */     throws ZipException
/* 579:    */   {
/* 580:609 */     if ((zipModel == null) || (outputStream == null)) {
/* 581:610 */       throw new ZipException("zip model or output stream is null, cannot write zip64 end of central directory record");
/* 582:    */     }
/* 583:    */     try
/* 584:    */     {
/* 585:615 */       byte[] shortByte = new byte[2];
/* 586:616 */       byte[] emptyShortByte = { 0, 0 };
/* 587:617 */       byte[] intByte = new byte[4];
/* 588:618 */       byte[] longByte = new byte[8];
/* 589:    */       
/* 590:    */ 
/* 591:621 */       Raw.writeIntLittleEndian(intByte, 0, 101075792);
/* 592:622 */       copyByteArrayToArrayList(intByte, headerBytesList);
/* 593:    */       
/* 594:    */ 
/* 595:625 */       Raw.writeLongLittleEndian(longByte, 0, 44L);
/* 596:626 */       copyByteArrayToArrayList(longByte, headerBytesList);
/* 597:630 */       if ((zipModel.getCentralDirectory() != null) && 
/* 598:631 */         (zipModel.getCentralDirectory().getFileHeaders() != null) && 
/* 599:632 */         (zipModel.getCentralDirectory().getFileHeaders().size() > 0))
/* 600:    */       {
/* 601:633 */         Raw.writeShortLittleEndian(shortByte, 0, 
/* 602:634 */           (short)((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(0)).getVersionMadeBy());
/* 603:635 */         copyByteArrayToArrayList(shortByte, headerBytesList);
/* 604:    */         
/* 605:637 */         Raw.writeShortLittleEndian(shortByte, 0, 
/* 606:638 */           (short)((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(0)).getVersionNeededToExtract());
/* 607:639 */         copyByteArrayToArrayList(shortByte, headerBytesList);
/* 608:    */       }
/* 609:    */       else
/* 610:    */       {
/* 611:641 */         copyByteArrayToArrayList(emptyShortByte, headerBytesList);
/* 612:642 */         copyByteArrayToArrayList(emptyShortByte, headerBytesList);
/* 613:    */       }
/* 614:646 */       Raw.writeIntLittleEndian(intByte, 0, zipModel.getEndCentralDirRecord().getNoOfThisDisk());
/* 615:647 */       copyByteArrayToArrayList(intByte, headerBytesList);
/* 616:    */       
/* 617:    */ 
/* 618:650 */       Raw.writeIntLittleEndian(intByte, 0, zipModel.getEndCentralDirRecord().getNoOfThisDiskStartOfCentralDir());
/* 619:651 */       copyByteArrayToArrayList(intByte, headerBytesList);
/* 620:    */       
/* 621:    */ 
/* 622:654 */       int numEntries = 0;
/* 623:655 */       int numEntriesOnThisDisk = 0;
/* 624:656 */       if ((zipModel.getCentralDirectory() == null) || 
/* 625:657 */         (zipModel.getCentralDirectory().getFileHeaders() == null)) {
/* 626:658 */         throw new ZipException("invalid central directory/file headers, cannot write end of central directory record");
/* 627:    */       }
/* 628:661 */       numEntries = zipModel.getCentralDirectory().getFileHeaders().size();
/* 629:662 */       if (zipModel.isSplitArchive()) {
/* 630:663 */         countNumberOfFileHeaderEntriesOnDisk(zipModel.getCentralDirectory().getFileHeaders(), zipModel
/* 631:664 */           .getEndCentralDirRecord().getNoOfThisDisk());
/* 632:    */       } else {
/* 633:666 */         numEntriesOnThisDisk = numEntries;
/* 634:    */       }
/* 635:669 */       Raw.writeLongLittleEndian(longByte, 0, numEntriesOnThisDisk);
/* 636:670 */       copyByteArrayToArrayList(longByte, headerBytesList);
/* 637:    */       
/* 638:    */ 
/* 639:673 */       Raw.writeLongLittleEndian(longByte, 0, numEntries);
/* 640:674 */       copyByteArrayToArrayList(longByte, headerBytesList);
/* 641:    */       
/* 642:    */ 
/* 643:677 */       Raw.writeLongLittleEndian(longByte, 0, sizeOfCentralDir);
/* 644:678 */       copyByteArrayToArrayList(longByte, headerBytesList);
/* 645:    */       
/* 646:    */ 
/* 647:681 */       Raw.writeLongLittleEndian(longByte, 0, offsetCentralDir);
/* 648:682 */       copyByteArrayToArrayList(longByte, headerBytesList);
/* 649:    */     }
/* 650:    */     catch (ZipException zipException)
/* 651:    */     {
/* 652:685 */       throw zipException;
/* 653:    */     }
/* 654:    */     catch (Exception e)
/* 655:    */     {
/* 656:687 */       throw new ZipException(e);
/* 657:    */     }
/* 658:    */   }
/* 659:    */   
/* 660:    */   private void writeZip64EndOfCentralDirectoryLocator(ZipModel zipModel, OutputStream outputStream, List headerBytesList)
/* 661:    */     throws ZipException
/* 662:    */   {
/* 663:693 */     if ((zipModel == null) || (outputStream == null)) {
/* 664:694 */       throw new ZipException("zip model or output stream is null, cannot write zip64 end of central directory locator");
/* 665:    */     }
/* 666:    */     try
/* 667:    */     {
/* 668:699 */       byte[] intByte = new byte[4];
/* 669:700 */       byte[] longByte = new byte[8];
/* 670:    */       
/* 671:    */ 
/* 672:703 */       Raw.writeIntLittleEndian(intByte, 0, 117853008);
/* 673:704 */       copyByteArrayToArrayList(intByte, headerBytesList);
/* 674:    */       
/* 675:    */ 
/* 676:707 */       Raw.writeIntLittleEndian(intByte, 0, zipModel.getZip64EndCentralDirLocator().getNoOfDiskStartOfZip64EndOfCentralDirRec());
/* 677:708 */       copyByteArrayToArrayList(intByte, headerBytesList);
/* 678:    */       
/* 679:    */ 
/* 680:711 */       Raw.writeLongLittleEndian(longByte, 0, zipModel.getZip64EndCentralDirLocator().getOffsetZip64EndOfCentralDirRec());
/* 681:712 */       copyByteArrayToArrayList(longByte, headerBytesList);
/* 682:    */       
/* 683:    */ 
/* 684:715 */       Raw.writeIntLittleEndian(intByte, 0, zipModel.getZip64EndCentralDirLocator().getTotNumberOfDiscs());
/* 685:716 */       copyByteArrayToArrayList(intByte, headerBytesList);
/* 686:    */     }
/* 687:    */     catch (ZipException zipException)
/* 688:    */     {
/* 689:718 */       throw zipException;
/* 690:    */     }
/* 691:    */     catch (Exception e)
/* 692:    */     {
/* 693:720 */       throw new ZipException(e);
/* 694:    */     }
/* 695:    */   }
/* 696:    */   
/* 697:    */   private void writeEndOfCentralDirectoryRecord(ZipModel zipModel, OutputStream outputStream, int sizeOfCentralDir, long offsetCentralDir, List headrBytesList)
/* 698:    */     throws ZipException
/* 699:    */   {
/* 700:729 */     if ((zipModel == null) || (outputStream == null)) {
/* 701:730 */       throw new ZipException("zip model or output stream is null, cannot write end of central directory record");
/* 702:    */     }
/* 703:    */     try
/* 704:    */     {
/* 705:735 */       byte[] shortByte = new byte[2];
/* 706:736 */       byte[] intByte = new byte[4];
/* 707:737 */       byte[] longByte = new byte[8];
/* 708:    */       
/* 709:    */ 
/* 710:740 */       Raw.writeIntLittleEndian(intByte, 0, (int)zipModel.getEndCentralDirRecord().getSignature());
/* 711:741 */       copyByteArrayToArrayList(intByte, headrBytesList);
/* 712:    */       
/* 713:    */ 
/* 714:744 */       Raw.writeShortLittleEndian(shortByte, 0, (short)zipModel.getEndCentralDirRecord().getNoOfThisDisk());
/* 715:745 */       copyByteArrayToArrayList(shortByte, headrBytesList);
/* 716:    */       
/* 717:    */ 
/* 718:748 */       Raw.writeShortLittleEndian(shortByte, 0, (short)zipModel.getEndCentralDirRecord().getNoOfThisDiskStartOfCentralDir());
/* 719:749 */       copyByteArrayToArrayList(shortByte, headrBytesList);
/* 720:    */       
/* 721:    */ 
/* 722:752 */       int numEntries = 0;
/* 723:753 */       int numEntriesOnThisDisk = 0;
/* 724:754 */       if ((zipModel.getCentralDirectory() == null) || 
/* 725:755 */         (zipModel.getCentralDirectory().getFileHeaders() == null)) {
/* 726:756 */         throw new ZipException("invalid central directory/file headers, cannot write end of central directory record");
/* 727:    */       }
/* 728:759 */       numEntries = zipModel.getCentralDirectory().getFileHeaders().size();
/* 729:760 */       if (zipModel.isSplitArchive()) {
/* 730:761 */         numEntriesOnThisDisk = countNumberOfFileHeaderEntriesOnDisk(zipModel.getCentralDirectory().getFileHeaders(), zipModel
/* 731:762 */           .getEndCentralDirRecord().getNoOfThisDisk());
/* 732:    */       } else {
/* 733:764 */         numEntriesOnThisDisk = numEntries;
/* 734:    */       }
/* 735:767 */       Raw.writeShortLittleEndian(shortByte, 0, (short)numEntriesOnThisDisk);
/* 736:768 */       copyByteArrayToArrayList(shortByte, headrBytesList);
/* 737:    */       
/* 738:    */ 
/* 739:771 */       Raw.writeShortLittleEndian(shortByte, 0, (short)numEntries);
/* 740:772 */       copyByteArrayToArrayList(shortByte, headrBytesList);
/* 741:    */       
/* 742:    */ 
/* 743:775 */       Raw.writeIntLittleEndian(intByte, 0, sizeOfCentralDir);
/* 744:776 */       copyByteArrayToArrayList(intByte, headrBytesList);
/* 745:779 */       if (offsetCentralDir > 4294967295L)
/* 746:    */       {
/* 747:780 */         Raw.writeLongLittleEndian(longByte, 0, 4294967295L);
/* 748:781 */         System.arraycopy(longByte, 0, intByte, 0, 4);
/* 749:782 */         copyByteArrayToArrayList(intByte, headrBytesList);
/* 750:    */       }
/* 751:    */       else
/* 752:    */       {
/* 753:784 */         Raw.writeLongLittleEndian(longByte, 0, offsetCentralDir);
/* 754:785 */         System.arraycopy(longByte, 0, intByte, 0, 4);
/* 755:    */         
/* 756:787 */         copyByteArrayToArrayList(intByte, headrBytesList);
/* 757:    */       }
/* 758:791 */       int commentLength = 0;
/* 759:792 */       if (zipModel.getEndCentralDirRecord().getComment() != null) {
/* 760:793 */         commentLength = zipModel.getEndCentralDirRecord().getCommentLength();
/* 761:    */       }
/* 762:795 */       Raw.writeShortLittleEndian(shortByte, 0, (short)commentLength);
/* 763:796 */       copyByteArrayToArrayList(shortByte, headrBytesList);
/* 764:799 */       if (commentLength > 0) {
/* 765:800 */         copyByteArrayToArrayList(zipModel.getEndCentralDirRecord().getCommentBytes(), headrBytesList);
/* 766:    */       }
/* 767:    */     }
/* 768:    */     catch (Exception e)
/* 769:    */     {
/* 770:804 */       throw new ZipException(e);
/* 771:    */     }
/* 772:    */   }
/* 773:    */   
/* 774:    */   public void updateLocalFileHeader(LocalFileHeader localFileHeader, long offset, int toUpdate, ZipModel zipModel, byte[] bytesToWrite, int noOfDisk, SplitOutputStream outputStream)
/* 775:    */     throws ZipException
/* 776:    */   {
/* 777:810 */     if ((localFileHeader == null) || (offset < 0L) || (zipModel == null)) {
/* 778:811 */       throw new ZipException("invalid input parameters, cannot update local file header");
/* 779:    */     }
/* 780:    */     try
/* 781:    */     {
/* 782:815 */       boolean closeFlag = false;
/* 783:816 */       SplitOutputStream currOutputStream = null;
/* 784:818 */       if (noOfDisk != outputStream.getCurrSplitFileCounter())
/* 785:    */       {
/* 786:819 */         File zipFile = new File(zipModel.getZipFile());
/* 787:820 */         String parentFile = zipFile.getParent();
/* 788:821 */         String fileNameWithoutExt = Zip4jUtil.getZipFileNameWithoutExt(zipFile.getName());
/* 789:822 */         String fileName = parentFile + System.getProperty("file.separator");
/* 790:823 */         if (noOfDisk < 9) {
/* 791:824 */           fileName = fileName + fileNameWithoutExt + ".z0" + (noOfDisk + 1);
/* 792:    */         } else {
/* 793:826 */           fileName = fileName + fileNameWithoutExt + ".z" + (noOfDisk + 1);
/* 794:    */         }
/* 795:828 */         currOutputStream = new SplitOutputStream(new File(fileName));
/* 796:829 */         closeFlag = true;
/* 797:    */       }
/* 798:    */       else
/* 799:    */       {
/* 800:831 */         currOutputStream = outputStream;
/* 801:    */       }
/* 802:834 */       long currOffset = currOutputStream.getFilePointer();
/* 803:836 */       switch (toUpdate)
/* 804:    */       {
/* 805:    */       case 14: 
/* 806:838 */         currOutputStream.seek(offset + toUpdate);
/* 807:839 */         currOutputStream.write(bytesToWrite);
/* 808:840 */         break;
/* 809:    */       case 18: 
/* 810:    */       case 22: 
/* 811:843 */         updateCompressedSizeInLocalFileHeader(currOutputStream, localFileHeader, offset, toUpdate, bytesToWrite, zipModel
/* 812:844 */           .isZip64Format());
/* 813:845 */         break;
/* 814:    */       }
/* 815:849 */       if (closeFlag) {
/* 816:850 */         currOutputStream.close();
/* 817:    */       } else {
/* 818:852 */         outputStream.seek(currOffset);
/* 819:    */       }
/* 820:    */     }
/* 821:    */     catch (Exception e)
/* 822:    */     {
/* 823:856 */       throw new ZipException(e);
/* 824:    */     }
/* 825:    */   }
/* 826:    */   
/* 827:    */   private void updateCompressedSizeInLocalFileHeader(SplitOutputStream outputStream, LocalFileHeader localFileHeader, long offset, long toUpdate, byte[] bytesToWrite, boolean isZip64Format)
/* 828:    */     throws ZipException
/* 829:    */   {
/* 830:863 */     if (outputStream == null) {
/* 831:864 */       throw new ZipException("invalid output stream, cannot update compressed size for local file header");
/* 832:    */     }
/* 833:    */     try
/* 834:    */     {
/* 835:868 */       if (localFileHeader.isWriteComprSizeInZip64ExtraRecord())
/* 836:    */       {
/* 837:869 */         if (bytesToWrite.length != 8) {
/* 838:870 */           throw new ZipException("attempting to write a non 8-byte compressed size block for a zip64 file");
/* 839:    */         }
/* 840:883 */         long zip64CompressedSizeOffset = offset + toUpdate + 4L + 4L + 2L + 2L + localFileHeader.getFileNameLength() + 2L + 2L + 8L;
/* 841:884 */         if (toUpdate == 22L) {
/* 842:885 */           zip64CompressedSizeOffset += 8L;
/* 843:    */         }
/* 844:887 */         outputStream.seek(zip64CompressedSizeOffset);
/* 845:888 */         outputStream.write(bytesToWrite);
/* 846:    */       }
/* 847:    */       else
/* 848:    */       {
/* 849:890 */         outputStream.seek(offset + toUpdate);
/* 850:891 */         outputStream.write(bytesToWrite);
/* 851:    */       }
/* 852:    */     }
/* 853:    */     catch (IOException e)
/* 854:    */     {
/* 855:894 */       throw new ZipException(e);
/* 856:    */     }
/* 857:    */   }
/* 858:    */   
/* 859:    */   private void copyByteArrayToArrayList(byte[] byteArray, List arrayList)
/* 860:    */     throws ZipException
/* 861:    */   {
/* 862:900 */     if ((arrayList == null) || (byteArray == null)) {
/* 863:901 */       throw new ZipException("one of the input parameters is null, cannot copy byte array to array list");
/* 864:    */     }
/* 865:904 */     for (int i = 0; i < byteArray.length; i++) {
/* 866:905 */       arrayList.add(Byte.toString(byteArray[i]));
/* 867:    */     }
/* 868:    */   }
/* 869:    */   
/* 870:    */   private byte[] byteArrayListToByteArray(List arrayList)
/* 871:    */     throws ZipException
/* 872:    */   {
/* 873:910 */     if (arrayList == null) {
/* 874:911 */       throw new ZipException("input byte array list is null, cannot conver to byte array");
/* 875:    */     }
/* 876:914 */     if (arrayList.size() <= 0) {
/* 877:915 */       return null;
/* 878:    */     }
/* 879:918 */     byte[] retBytes = new byte[arrayList.size()];
/* 880:920 */     for (int i = 0; i < arrayList.size(); i++) {
/* 881:921 */       retBytes[i] = Byte.parseByte((String)arrayList.get(i));
/* 882:    */     }
/* 883:924 */     return retBytes;
/* 884:    */   }
/* 885:    */   
/* 886:    */   private int countNumberOfFileHeaderEntriesOnDisk(ArrayList fileHeaders, int numOfDisk)
/* 887:    */     throws ZipException
/* 888:    */   {
/* 889:929 */     if (fileHeaders == null) {
/* 890:930 */       throw new ZipException("file headers are null, cannot calculate number of entries on this disk");
/* 891:    */     }
/* 892:933 */     int noEntries = 0;
/* 893:934 */     for (int i = 0; i < fileHeaders.size(); i++)
/* 894:    */     {
/* 895:935 */       FileHeader fileHeader = (FileHeader)fileHeaders.get(i);
/* 896:936 */       if (fileHeader.getDiskNumberStart() == numOfDisk) {
/* 897:937 */         noEntries++;
/* 898:    */       }
/* 899:    */     }
/* 900:940 */     return noEntries;
/* 901:    */   }
/* 902:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.core.HeaderWriter
 * JD-Core Version:    0.7.0.1
 */