/*    1:     */ package net.lingala.zip4j.core;
/*    2:     */ 
/*    3:     */ import java.io.IOException;
/*    4:     */ import java.io.RandomAccessFile;
/*    5:     */ import java.util.ArrayList;
/*    6:     */ import net.lingala.zip4j.exception.ZipException;
/*    7:     */ import net.lingala.zip4j.model.AESExtraDataRecord;
/*    8:     */ import net.lingala.zip4j.model.CentralDirectory;
/*    9:     */ import net.lingala.zip4j.model.DigitalSignature;
/*   10:     */ import net.lingala.zip4j.model.EndCentralDirRecord;
/*   11:     */ import net.lingala.zip4j.model.ExtraDataRecord;
/*   12:     */ import net.lingala.zip4j.model.FileHeader;
/*   13:     */ import net.lingala.zip4j.model.LocalFileHeader;
/*   14:     */ import net.lingala.zip4j.model.Zip64EndCentralDirLocator;
/*   15:     */ import net.lingala.zip4j.model.Zip64EndCentralDirRecord;
/*   16:     */ import net.lingala.zip4j.model.Zip64ExtendedInfo;
/*   17:     */ import net.lingala.zip4j.model.ZipModel;
/*   18:     */ import net.lingala.zip4j.util.Raw;
/*   19:     */ import net.lingala.zip4j.util.Zip4jUtil;
/*   20:     */ 
/*   21:     */ public class HeaderReader
/*   22:     */ {
/*   23:  47 */   private RandomAccessFile zip4jRaf = null;
/*   24:     */   private ZipModel zipModel;
/*   25:     */   
/*   26:     */   public HeaderReader(RandomAccessFile zip4jRaf)
/*   27:     */   {
/*   28:  55 */     this.zip4jRaf = zip4jRaf;
/*   29:     */   }
/*   30:     */   
/*   31:     */   public ZipModel readAllHeaders()
/*   32:     */     throws ZipException
/*   33:     */   {
/*   34:  65 */     return readAllHeaders(null);
/*   35:     */   }
/*   36:     */   
/*   37:     */   public ZipModel readAllHeaders(String fileNameCharset)
/*   38:     */     throws ZipException
/*   39:     */   {
/*   40:  76 */     this.zipModel = new ZipModel();
/*   41:  77 */     this.zipModel.setFileNameCharset(fileNameCharset);
/*   42:  78 */     this.zipModel.setEndCentralDirRecord(readEndOfCentralDirectoryRecord());
/*   43:     */     
/*   44:     */ 
/*   45:     */ 
/*   46:  82 */     this.zipModel.setZip64EndCentralDirLocator(readZip64EndCentralDirLocator());
/*   47:  84 */     if (this.zipModel.isZip64Format())
/*   48:     */     {
/*   49:  85 */       this.zipModel.setZip64EndCentralDirRecord(readZip64EndCentralDirRec());
/*   50:  86 */       if ((this.zipModel.getZip64EndCentralDirRecord() != null) && 
/*   51:  87 */         (this.zipModel.getZip64EndCentralDirRecord().getNoOfThisDisk() > 0)) {
/*   52:  88 */         this.zipModel.setSplitArchive(true);
/*   53:     */       } else {
/*   54:  90 */         this.zipModel.setSplitArchive(false);
/*   55:     */       }
/*   56:     */     }
/*   57:  94 */     this.zipModel.setCentralDirectory(readCentralDirectory());
/*   58:     */     
/*   59:  96 */     return this.zipModel;
/*   60:     */   }
/*   61:     */   
/*   62:     */   private EndCentralDirRecord readEndOfCentralDirectoryRecord()
/*   63:     */     throws ZipException
/*   64:     */   {
/*   65: 106 */     if (this.zip4jRaf == null) {
/*   66: 107 */       throw new ZipException("random access file was null", 3);
/*   67:     */     }
/*   68:     */     try
/*   69:     */     {
/*   70: 111 */       byte[] ebs = new byte[4];
/*   71: 112 */       long pos = this.zip4jRaf.length() - 22L;
/*   72:     */       
/*   73: 114 */       EndCentralDirRecord endCentralDirRecord = new EndCentralDirRecord();
/*   74: 115 */       int counter = 0;
/*   75:     */       do
/*   76:     */       {
/*   77: 117 */         this.zip4jRaf.seek(pos--);
/*   78: 118 */         counter++;
/*   79: 119 */       } while ((Raw.readLeInt(this.zip4jRaf, ebs) != 101010256L) && (counter <= 3000));
/*   80: 121 */       if (Raw.readIntLittleEndian(ebs, 0) != 101010256L) {
/*   81: 122 */         throw new ZipException("zip headers not found. probably not a zip file");
/*   82:     */       }
/*   83: 124 */       byte[] intBuff = new byte[4];
/*   84: 125 */       byte[] shortBuff = new byte[2];
/*   85:     */       
/*   86:     */ 
/*   87: 128 */       endCentralDirRecord.setSignature(101010256L);
/*   88:     */       
/*   89:     */ 
/*   90: 131 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*   91: 132 */       endCentralDirRecord.setNoOfThisDisk(Raw.readShortLittleEndian(shortBuff, 0));
/*   92:     */       
/*   93:     */ 
/*   94: 135 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*   95: 136 */       endCentralDirRecord.setNoOfThisDiskStartOfCentralDir(Raw.readShortLittleEndian(shortBuff, 0));
/*   96:     */       
/*   97:     */ 
/*   98: 139 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*   99: 140 */       endCentralDirRecord.setTotNoOfEntriesInCentralDirOnThisDisk(Raw.readShortLittleEndian(shortBuff, 0));
/*  100:     */       
/*  101:     */ 
/*  102: 143 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*  103: 144 */       endCentralDirRecord.setTotNoOfEntriesInCentralDir(Raw.readShortLittleEndian(shortBuff, 0));
/*  104:     */       
/*  105:     */ 
/*  106: 147 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  107: 148 */       endCentralDirRecord.setSizeOfCentralDir(Raw.readIntLittleEndian(intBuff, 0));
/*  108:     */       
/*  109:     */ 
/*  110: 151 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  111: 152 */       byte[] longBuff = getLongByteFromIntByte(intBuff);
/*  112: 153 */       endCentralDirRecord.setOffsetOfStartOfCentralDir(Raw.readLongLittleEndian(longBuff, 0));
/*  113:     */       
/*  114:     */ 
/*  115: 156 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*  116: 157 */       int commentLength = Raw.readShortLittleEndian(shortBuff, 0);
/*  117: 158 */       endCentralDirRecord.setCommentLength(commentLength);
/*  118: 161 */       if (commentLength > 0)
/*  119:     */       {
/*  120: 162 */         byte[] commentBuf = new byte[commentLength];
/*  121: 163 */         readIntoBuff(this.zip4jRaf, commentBuf);
/*  122: 164 */         endCentralDirRecord.setComment(new String(commentBuf));
/*  123: 165 */         endCentralDirRecord.setCommentBytes(commentBuf);
/*  124:     */       }
/*  125:     */       else
/*  126:     */       {
/*  127: 167 */         endCentralDirRecord.setComment(null);
/*  128:     */       }
/*  129: 170 */       int diskNumber = endCentralDirRecord.getNoOfThisDisk();
/*  130: 171 */       if (diskNumber > 0) {
/*  131: 172 */         this.zipModel.setSplitArchive(true);
/*  132:     */       } else {
/*  133: 174 */         this.zipModel.setSplitArchive(false);
/*  134:     */       }
/*  135: 177 */       return endCentralDirRecord;
/*  136:     */     }
/*  137:     */     catch (IOException e)
/*  138:     */     {
/*  139: 179 */       throw new ZipException("Probably not a zip file or a corrupted zip file", e, 4);
/*  140:     */     }
/*  141:     */   }
/*  142:     */   
/*  143:     */   private CentralDirectory readCentralDirectory()
/*  144:     */     throws ZipException
/*  145:     */   {
/*  146: 190 */     if (this.zip4jRaf == null) {
/*  147: 191 */       throw new ZipException("random access file was null", 3);
/*  148:     */     }
/*  149: 194 */     if (this.zipModel.getEndCentralDirRecord() == null) {
/*  150: 195 */       throw new ZipException("EndCentralRecord was null, maybe a corrupt zip file");
/*  151:     */     }
/*  152:     */     try
/*  153:     */     {
/*  154: 199 */       CentralDirectory centralDirectory = new CentralDirectory();
/*  155: 200 */       ArrayList fileHeaderList = new ArrayList();
/*  156:     */       
/*  157: 202 */       EndCentralDirRecord endCentralDirRecord = this.zipModel.getEndCentralDirRecord();
/*  158: 203 */       long offSetStartCentralDir = endCentralDirRecord.getOffsetOfStartOfCentralDir();
/*  159: 204 */       int centralDirEntryCount = endCentralDirRecord.getTotNoOfEntriesInCentralDir();
/*  160: 206 */       if (this.zipModel.isZip64Format())
/*  161:     */       {
/*  162: 207 */         offSetStartCentralDir = this.zipModel.getZip64EndCentralDirRecord().getOffsetStartCenDirWRTStartDiskNo();
/*  163: 208 */         centralDirEntryCount = (int)this.zipModel.getZip64EndCentralDirRecord().getTotNoOfEntriesInCentralDir();
/*  164:     */       }
/*  165: 211 */       this.zip4jRaf.seek(offSetStartCentralDir);
/*  166:     */       
/*  167: 213 */       byte[] intBuff = new byte[4];
/*  168: 214 */       byte[] shortBuff = new byte[2];
/*  169: 215 */       byte[] longBuff = new byte[8];
/*  170: 217 */       for (int i = 0; i < centralDirEntryCount; i++)
/*  171:     */       {
/*  172: 218 */         FileHeader fileHeader = new FileHeader();
/*  173:     */         
/*  174:     */ 
/*  175: 221 */         readIntoBuff(this.zip4jRaf, intBuff);
/*  176: 222 */         int signature = Raw.readIntLittleEndian(intBuff, 0);
/*  177: 223 */         if (signature != 33639248L) {
/*  178: 224 */           throw new ZipException("Expected central directory entry not found (#" + (i + 1) + ")");
/*  179:     */         }
/*  180: 226 */         fileHeader.setSignature(signature);
/*  181:     */         
/*  182:     */ 
/*  183: 229 */         readIntoBuff(this.zip4jRaf, shortBuff);
/*  184: 230 */         fileHeader.setVersionMadeBy(Raw.readShortLittleEndian(shortBuff, 0));
/*  185:     */         
/*  186:     */ 
/*  187: 233 */         readIntoBuff(this.zip4jRaf, shortBuff);
/*  188: 234 */         fileHeader.setVersionNeededToExtract(Raw.readShortLittleEndian(shortBuff, 0));
/*  189:     */         
/*  190:     */ 
/*  191: 237 */         readIntoBuff(this.zip4jRaf, shortBuff);
/*  192: 238 */         fileHeader.setFileNameUTF8Encoded((Raw.readShortLittleEndian(shortBuff, 0) & 0x800) != 0);
/*  193: 239 */         int firstByte = shortBuff[0];
/*  194: 240 */         int result = firstByte & 0x1;
/*  195: 241 */         if (result != 0) {
/*  196: 242 */           fileHeader.setEncrypted(true);
/*  197:     */         }
/*  198: 244 */         fileHeader.setGeneralPurposeFlag((byte[])shortBuff.clone());
/*  199:     */         
/*  200:     */ 
/*  201: 247 */         fileHeader.setDataDescriptorExists(firstByte >> 3 == 1);
/*  202:     */         
/*  203:     */ 
/*  204: 250 */         readIntoBuff(this.zip4jRaf, shortBuff);
/*  205: 251 */         fileHeader.setCompressionMethod(Raw.readShortLittleEndian(shortBuff, 0));
/*  206:     */         
/*  207:     */ 
/*  208: 254 */         readIntoBuff(this.zip4jRaf, intBuff);
/*  209: 255 */         fileHeader.setLastModFileTime(Raw.readIntLittleEndian(intBuff, 0));
/*  210:     */         
/*  211:     */ 
/*  212: 258 */         readIntoBuff(this.zip4jRaf, intBuff);
/*  213: 259 */         fileHeader.setCrc32(Raw.readIntLittleEndian(intBuff, 0));
/*  214: 260 */         fileHeader.setCrcBuff((byte[])intBuff.clone());
/*  215:     */         
/*  216:     */ 
/*  217: 263 */         readIntoBuff(this.zip4jRaf, intBuff);
/*  218: 264 */         longBuff = getLongByteFromIntByte(intBuff);
/*  219: 265 */         fileHeader.setCompressedSize(Raw.readLongLittleEndian(longBuff, 0));
/*  220:     */         
/*  221:     */ 
/*  222: 268 */         readIntoBuff(this.zip4jRaf, intBuff);
/*  223: 269 */         longBuff = getLongByteFromIntByte(intBuff);
/*  224: 270 */         fileHeader.setUncompressedSize(Raw.readLongLittleEndian(longBuff, 0));
/*  225:     */         
/*  226:     */ 
/*  227: 273 */         readIntoBuff(this.zip4jRaf, shortBuff);
/*  228: 274 */         int fileNameLength = Raw.readShortLittleEndian(shortBuff, 0);
/*  229: 275 */         fileHeader.setFileNameLength(fileNameLength);
/*  230:     */         
/*  231:     */ 
/*  232: 278 */         readIntoBuff(this.zip4jRaf, shortBuff);
/*  233: 279 */         int extraFieldLength = Raw.readShortLittleEndian(shortBuff, 0);
/*  234: 280 */         fileHeader.setExtraFieldLength(extraFieldLength);
/*  235:     */         
/*  236:     */ 
/*  237: 283 */         readIntoBuff(this.zip4jRaf, shortBuff);
/*  238: 284 */         int fileCommentLength = Raw.readShortLittleEndian(shortBuff, 0);
/*  239: 285 */         fileHeader.setFileComment(new String(shortBuff));
/*  240:     */         
/*  241:     */ 
/*  242: 288 */         readIntoBuff(this.zip4jRaf, shortBuff);
/*  243: 289 */         fileHeader.setDiskNumberStart(Raw.readShortLittleEndian(shortBuff, 0));
/*  244:     */         
/*  245:     */ 
/*  246: 292 */         readIntoBuff(this.zip4jRaf, shortBuff);
/*  247: 293 */         fileHeader.setInternalFileAttr((byte[])shortBuff.clone());
/*  248:     */         
/*  249:     */ 
/*  250: 296 */         readIntoBuff(this.zip4jRaf, intBuff);
/*  251: 297 */         fileHeader.setExternalFileAttr((byte[])intBuff.clone());
/*  252:     */         
/*  253:     */ 
/*  254: 300 */         readIntoBuff(this.zip4jRaf, intBuff);
/*  255:     */         
/*  256:     */ 
/*  257: 303 */         longBuff = getLongByteFromIntByte(intBuff);
/*  258: 304 */         fileHeader.setOffsetLocalHeader(Raw.readLongLittleEndian(longBuff, 0) & 0xFFFFFFFF);
/*  259: 306 */         if (fileNameLength > 0)
/*  260:     */         {
/*  261: 307 */           byte[] fileNameBuf = new byte[fileNameLength];
/*  262: 308 */           readIntoBuff(this.zip4jRaf, fileNameBuf);
/*  263:     */           
/*  264:     */ 
/*  265:     */ 
/*  266:     */ 
/*  267:     */ 
/*  268: 314 */           String fileName = null;
/*  269: 316 */           if (Zip4jUtil.isStringNotNullAndNotEmpty(this.zipModel.getFileNameCharset())) {
/*  270: 317 */             fileName = new String(fileNameBuf, this.zipModel.getFileNameCharset());
/*  271:     */           } else {
/*  272: 319 */             fileName = Zip4jUtil.decodeFileName(fileNameBuf, fileHeader.isFileNameUTF8Encoded());
/*  273:     */           }
/*  274: 322 */           if (fileName == null) {
/*  275: 323 */             throw new ZipException("fileName is null when reading central directory");
/*  276:     */           }
/*  277: 326 */           if (fileName.indexOf(":" + System.getProperty("file.separator")) >= 0) {
/*  278: 327 */             fileName = fileName.substring(fileName.indexOf(":" + System.getProperty("file.separator")) + 2);
/*  279:     */           }
/*  280: 330 */           fileHeader.setFileName(fileName);
/*  281: 331 */           fileHeader.setDirectory((fileName.endsWith("/")) || (fileName.endsWith("\\")));
/*  282:     */         }
/*  283:     */         else
/*  284:     */         {
/*  285: 334 */           fileHeader.setFileName(null);
/*  286:     */         }
/*  287: 338 */         readAndSaveExtraDataRecord(fileHeader);
/*  288:     */         
/*  289:     */ 
/*  290: 341 */         readAndSaveZip64ExtendedInfo(fileHeader);
/*  291:     */         
/*  292:     */ 
/*  293: 344 */         readAndSaveAESExtraDataRecord(fileHeader);
/*  294: 363 */         if (fileCommentLength > 0)
/*  295:     */         {
/*  296: 364 */           byte[] fileCommentBuf = new byte[fileCommentLength];
/*  297: 365 */           readIntoBuff(this.zip4jRaf, fileCommentBuf);
/*  298: 366 */           fileHeader.setFileComment(new String(fileCommentBuf));
/*  299:     */         }
/*  300: 369 */         fileHeaderList.add(fileHeader);
/*  301:     */       }
/*  302: 371 */       centralDirectory.setFileHeaders(fileHeaderList);
/*  303:     */       
/*  304:     */ 
/*  305: 374 */       DigitalSignature digitalSignature = new DigitalSignature();
/*  306: 375 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  307: 376 */       int signature = Raw.readIntLittleEndian(intBuff, 0);
/*  308: 377 */       if (signature != 84233040L) {
/*  309: 378 */         return centralDirectory;
/*  310:     */       }
/*  311: 381 */       digitalSignature.setHeaderSignature(signature);
/*  312:     */       
/*  313:     */ 
/*  314: 384 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*  315: 385 */       int sizeOfData = Raw.readShortLittleEndian(shortBuff, 0);
/*  316: 386 */       digitalSignature.setSizeOfData(sizeOfData);
/*  317: 388 */       if (sizeOfData > 0)
/*  318:     */       {
/*  319: 389 */         byte[] sigDataBuf = new byte[sizeOfData];
/*  320: 390 */         readIntoBuff(this.zip4jRaf, sigDataBuf);
/*  321: 391 */         digitalSignature.setSignatureData(new String(sigDataBuf));
/*  322:     */       }
/*  323: 394 */       return centralDirectory;
/*  324:     */     }
/*  325:     */     catch (IOException e)
/*  326:     */     {
/*  327: 396 */       throw new ZipException(e);
/*  328:     */     }
/*  329:     */   }
/*  330:     */   
/*  331:     */   private void readAndSaveExtraDataRecord(FileHeader fileHeader)
/*  332:     */     throws ZipException
/*  333:     */   {
/*  334: 407 */     if (this.zip4jRaf == null) {
/*  335: 408 */       throw new ZipException("invalid file handler when trying to read extra data record");
/*  336:     */     }
/*  337: 411 */     if (fileHeader == null) {
/*  338: 412 */       throw new ZipException("file header is null");
/*  339:     */     }
/*  340: 415 */     int extraFieldLength = fileHeader.getExtraFieldLength();
/*  341: 416 */     if (extraFieldLength <= 0) {
/*  342: 417 */       return;
/*  343:     */     }
/*  344: 420 */     fileHeader.setExtraDataRecords(readExtraDataRecords(extraFieldLength));
/*  345:     */   }
/*  346:     */   
/*  347:     */   private void readAndSaveExtraDataRecord(LocalFileHeader localFileHeader)
/*  348:     */     throws ZipException
/*  349:     */   {
/*  350: 431 */     if (this.zip4jRaf == null) {
/*  351: 432 */       throw new ZipException("invalid file handler when trying to read extra data record");
/*  352:     */     }
/*  353: 435 */     if (localFileHeader == null) {
/*  354: 436 */       throw new ZipException("file header is null");
/*  355:     */     }
/*  356: 439 */     int extraFieldLength = localFileHeader.getExtraFieldLength();
/*  357: 440 */     if (extraFieldLength <= 0) {
/*  358: 441 */       return;
/*  359:     */     }
/*  360: 444 */     localFileHeader.setExtraDataRecords(readExtraDataRecords(extraFieldLength));
/*  361:     */   }
/*  362:     */   
/*  363:     */   private ArrayList readExtraDataRecords(int extraFieldLength)
/*  364:     */     throws ZipException
/*  365:     */   {
/*  366: 456 */     if (extraFieldLength <= 0) {
/*  367: 457 */       return null;
/*  368:     */     }
/*  369:     */     try
/*  370:     */     {
/*  371: 461 */       byte[] extraFieldBuf = new byte[extraFieldLength];
/*  372: 462 */       this.zip4jRaf.read(extraFieldBuf);
/*  373:     */       
/*  374: 464 */       int counter = 0;
/*  375: 465 */       ArrayList extraDataList = new ArrayList();
/*  376: 466 */       while (counter < extraFieldLength)
/*  377:     */       {
/*  378: 467 */         ExtraDataRecord extraDataRecord = new ExtraDataRecord();
/*  379: 468 */         int header = Raw.readShortLittleEndian(extraFieldBuf, counter);
/*  380: 469 */         extraDataRecord.setHeader(header);
/*  381: 470 */         counter += 2;
/*  382: 471 */         int sizeOfRec = Raw.readShortLittleEndian(extraFieldBuf, counter);
/*  383: 473 */         if (2 + sizeOfRec > extraFieldLength)
/*  384:     */         {
/*  385: 474 */           sizeOfRec = Raw.readShortBigEndian(extraFieldBuf, counter);
/*  386: 475 */           if (2 + sizeOfRec > extraFieldLength) {
/*  387:     */             break;
/*  388:     */           }
/*  389:     */         }
/*  390: 482 */         extraDataRecord.setSizeOfData(sizeOfRec);
/*  391: 483 */         counter += 2;
/*  392: 485 */         if (sizeOfRec > 0)
/*  393:     */         {
/*  394: 486 */           byte[] data = new byte[sizeOfRec];
/*  395: 487 */           System.arraycopy(extraFieldBuf, counter, data, 0, sizeOfRec);
/*  396: 488 */           extraDataRecord.setData(data);
/*  397:     */         }
/*  398: 490 */         counter += sizeOfRec;
/*  399: 491 */         extraDataList.add(extraDataRecord);
/*  400:     */       }
/*  401: 493 */       if (extraDataList.size() > 0) {
/*  402: 494 */         return extraDataList;
/*  403:     */       }
/*  404: 496 */       return null;
/*  405:     */     }
/*  406:     */     catch (IOException e)
/*  407:     */     {
/*  408: 499 */       throw new ZipException(e);
/*  409:     */     }
/*  410:     */   }
/*  411:     */   
/*  412:     */   private Zip64EndCentralDirLocator readZip64EndCentralDirLocator()
/*  413:     */     throws ZipException
/*  414:     */   {
/*  415: 510 */     if (this.zip4jRaf == null) {
/*  416: 511 */       throw new ZipException("invalid file handler when trying to read Zip64EndCentralDirLocator");
/*  417:     */     }
/*  418:     */     try
/*  419:     */     {
/*  420: 515 */       Zip64EndCentralDirLocator zip64EndCentralDirLocator = new Zip64EndCentralDirLocator();
/*  421:     */       
/*  422: 517 */       setFilePointerToReadZip64EndCentralDirLoc();
/*  423:     */       
/*  424: 519 */       byte[] intBuff = new byte[4];
/*  425: 520 */       byte[] longBuff = new byte[8];
/*  426:     */       
/*  427: 522 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  428: 523 */       int signature = Raw.readIntLittleEndian(intBuff, 0);
/*  429: 524 */       if (signature == 117853008L)
/*  430:     */       {
/*  431: 525 */         this.zipModel.setZip64Format(true);
/*  432: 526 */         zip64EndCentralDirLocator.setSignature(signature);
/*  433:     */       }
/*  434:     */       else
/*  435:     */       {
/*  436: 528 */         this.zipModel.setZip64Format(false);
/*  437: 529 */         return null;
/*  438:     */       }
/*  439: 532 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  440: 533 */       zip64EndCentralDirLocator.setNoOfDiskStartOfZip64EndOfCentralDirRec(
/*  441: 534 */         Raw.readIntLittleEndian(intBuff, 0));
/*  442:     */       
/*  443: 536 */       readIntoBuff(this.zip4jRaf, longBuff);
/*  444: 537 */       zip64EndCentralDirLocator.setOffsetZip64EndOfCentralDirRec(
/*  445: 538 */         Raw.readLongLittleEndian(longBuff, 0));
/*  446:     */       
/*  447: 540 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  448: 541 */       zip64EndCentralDirLocator.setTotNumberOfDiscs(Raw.readIntLittleEndian(intBuff, 0));
/*  449:     */       
/*  450: 543 */       return zip64EndCentralDirLocator;
/*  451:     */     }
/*  452:     */     catch (Exception e)
/*  453:     */     {
/*  454: 546 */       throw new ZipException(e);
/*  455:     */     }
/*  456:     */   }
/*  457:     */   
/*  458:     */   private Zip64EndCentralDirRecord readZip64EndCentralDirRec()
/*  459:     */     throws ZipException
/*  460:     */   {
/*  461: 558 */     if (this.zipModel.getZip64EndCentralDirLocator() == null) {
/*  462: 559 */       throw new ZipException("invalid zip64 end of central directory locator");
/*  463:     */     }
/*  464: 563 */     long offSetStartOfZip64CentralDir = this.zipModel.getZip64EndCentralDirLocator().getOffsetZip64EndOfCentralDirRec();
/*  465: 565 */     if (offSetStartOfZip64CentralDir < 0L) {
/*  466: 566 */       throw new ZipException("invalid offset for start of end of central directory record");
/*  467:     */     }
/*  468:     */     try
/*  469:     */     {
/*  470: 570 */       this.zip4jRaf.seek(offSetStartOfZip64CentralDir);
/*  471:     */       
/*  472: 572 */       Zip64EndCentralDirRecord zip64EndCentralDirRecord = new Zip64EndCentralDirRecord();
/*  473:     */       
/*  474: 574 */       byte[] shortBuff = new byte[2];
/*  475: 575 */       byte[] intBuff = new byte[4];
/*  476: 576 */       byte[] longBuff = new byte[8];
/*  477:     */       
/*  478:     */ 
/*  479: 579 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  480: 580 */       int signature = Raw.readIntLittleEndian(intBuff, 0);
/*  481: 581 */       if (signature != 101075792L) {
/*  482: 582 */         throw new ZipException("invalid signature for zip64 end of central directory record");
/*  483:     */       }
/*  484: 584 */       zip64EndCentralDirRecord.setSignature(signature);
/*  485:     */       
/*  486:     */ 
/*  487: 587 */       readIntoBuff(this.zip4jRaf, longBuff);
/*  488: 588 */       zip64EndCentralDirRecord.setSizeOfZip64EndCentralDirRec(
/*  489: 589 */         Raw.readLongLittleEndian(longBuff, 0));
/*  490:     */       
/*  491:     */ 
/*  492: 592 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*  493: 593 */       zip64EndCentralDirRecord.setVersionMadeBy(Raw.readShortLittleEndian(shortBuff, 0));
/*  494:     */       
/*  495:     */ 
/*  496: 596 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*  497: 597 */       zip64EndCentralDirRecord.setVersionNeededToExtract(Raw.readShortLittleEndian(shortBuff, 0));
/*  498:     */       
/*  499:     */ 
/*  500: 600 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  501: 601 */       zip64EndCentralDirRecord.setNoOfThisDisk(Raw.readIntLittleEndian(intBuff, 0));
/*  502:     */       
/*  503:     */ 
/*  504: 604 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  505: 605 */       zip64EndCentralDirRecord.setNoOfThisDiskStartOfCentralDir(
/*  506: 606 */         Raw.readIntLittleEndian(intBuff, 0));
/*  507:     */       
/*  508:     */ 
/*  509: 609 */       readIntoBuff(this.zip4jRaf, longBuff);
/*  510: 610 */       zip64EndCentralDirRecord.setTotNoOfEntriesInCentralDirOnThisDisk(
/*  511: 611 */         Raw.readLongLittleEndian(longBuff, 0));
/*  512:     */       
/*  513:     */ 
/*  514: 614 */       readIntoBuff(this.zip4jRaf, longBuff);
/*  515: 615 */       zip64EndCentralDirRecord.setTotNoOfEntriesInCentralDir(
/*  516: 616 */         Raw.readLongLittleEndian(longBuff, 0));
/*  517:     */       
/*  518:     */ 
/*  519: 619 */       readIntoBuff(this.zip4jRaf, longBuff);
/*  520: 620 */       zip64EndCentralDirRecord.setSizeOfCentralDir(Raw.readLongLittleEndian(longBuff, 0));
/*  521:     */       
/*  522:     */ 
/*  523: 623 */       readIntoBuff(this.zip4jRaf, longBuff);
/*  524: 624 */       zip64EndCentralDirRecord.setOffsetStartCenDirWRTStartDiskNo(
/*  525: 625 */         Raw.readLongLittleEndian(longBuff, 0));
/*  526:     */       
/*  527:     */ 
/*  528:     */ 
/*  529: 629 */       long extDataSecSize = zip64EndCentralDirRecord.getSizeOfZip64EndCentralDirRec() - 44L;
/*  530: 630 */       if (extDataSecSize > 0L)
/*  531:     */       {
/*  532: 631 */         byte[] extDataSecRecBuf = new byte[(int)extDataSecSize];
/*  533: 632 */         readIntoBuff(this.zip4jRaf, extDataSecRecBuf);
/*  534: 633 */         zip64EndCentralDirRecord.setExtensibleDataSector(extDataSecRecBuf);
/*  535:     */       }
/*  536: 636 */       return zip64EndCentralDirRecord;
/*  537:     */     }
/*  538:     */     catch (IOException e)
/*  539:     */     {
/*  540: 639 */       throw new ZipException(e);
/*  541:     */     }
/*  542:     */   }
/*  543:     */   
/*  544:     */   private void readAndSaveZip64ExtendedInfo(FileHeader fileHeader)
/*  545:     */     throws ZipException
/*  546:     */   {
/*  547: 650 */     if (fileHeader == null) {
/*  548: 651 */       throw new ZipException("file header is null in reading Zip64 Extended Info");
/*  549:     */     }
/*  550: 654 */     if ((fileHeader.getExtraDataRecords() == null) || (fileHeader.getExtraDataRecords().size() <= 0)) {
/*  551: 655 */       return;
/*  552:     */     }
/*  553: 658 */     Zip64ExtendedInfo zip64ExtendedInfo = readZip64ExtendedInfo(fileHeader
/*  554: 659 */       .getExtraDataRecords(), fileHeader
/*  555: 660 */       .getUncompressedSize(), fileHeader
/*  556: 661 */       .getCompressedSize(), fileHeader
/*  557: 662 */       .getOffsetLocalHeader(), fileHeader
/*  558: 663 */       .getDiskNumberStart());
/*  559: 665 */     if (zip64ExtendedInfo != null)
/*  560:     */     {
/*  561: 666 */       fileHeader.setZip64ExtendedInfo(zip64ExtendedInfo);
/*  562: 667 */       if (zip64ExtendedInfo.getUnCompressedSize() != -1L) {
/*  563: 668 */         fileHeader.setUncompressedSize(zip64ExtendedInfo.getUnCompressedSize());
/*  564:     */       }
/*  565: 670 */       if (zip64ExtendedInfo.getCompressedSize() != -1L) {
/*  566: 671 */         fileHeader.setCompressedSize(zip64ExtendedInfo.getCompressedSize());
/*  567:     */       }
/*  568: 673 */       if (zip64ExtendedInfo.getOffsetLocalHeader() != -1L) {
/*  569: 674 */         fileHeader.setOffsetLocalHeader(zip64ExtendedInfo.getOffsetLocalHeader());
/*  570:     */       }
/*  571: 676 */       if (zip64ExtendedInfo.getDiskNumberStart() != -1) {
/*  572: 677 */         fileHeader.setDiskNumberStart(zip64ExtendedInfo.getDiskNumberStart());
/*  573:     */       }
/*  574:     */     }
/*  575:     */   }
/*  576:     */   
/*  577:     */   private void readAndSaveZip64ExtendedInfo(LocalFileHeader localFileHeader)
/*  578:     */     throws ZipException
/*  579:     */   {
/*  580: 687 */     if (localFileHeader == null) {
/*  581: 688 */       throw new ZipException("file header is null in reading Zip64 Extended Info");
/*  582:     */     }
/*  583: 691 */     if ((localFileHeader.getExtraDataRecords() == null) || (localFileHeader.getExtraDataRecords().size() <= 0)) {
/*  584: 692 */       return;
/*  585:     */     }
/*  586: 695 */     Zip64ExtendedInfo zip64ExtendedInfo = readZip64ExtendedInfo(localFileHeader
/*  587: 696 */       .getExtraDataRecords(), localFileHeader
/*  588: 697 */       .getUncompressedSize(), localFileHeader
/*  589: 698 */       .getCompressedSize(), -1L, -1);
/*  590: 701 */     if (zip64ExtendedInfo != null)
/*  591:     */     {
/*  592: 702 */       localFileHeader.setZip64ExtendedInfo(zip64ExtendedInfo);
/*  593: 704 */       if (zip64ExtendedInfo.getUnCompressedSize() != -1L) {
/*  594: 705 */         localFileHeader.setUncompressedSize(zip64ExtendedInfo.getUnCompressedSize());
/*  595:     */       }
/*  596: 707 */       if (zip64ExtendedInfo.getCompressedSize() != -1L) {
/*  597: 708 */         localFileHeader.setCompressedSize(zip64ExtendedInfo.getCompressedSize());
/*  598:     */       }
/*  599:     */     }
/*  600:     */   }
/*  601:     */   
/*  602:     */   private Zip64ExtendedInfo readZip64ExtendedInfo(ArrayList extraDataRecords, long unCompressedSize, long compressedSize, long offsetLocalHeader, int diskNumberStart)
/*  603:     */     throws ZipException
/*  604:     */   {
/*  605: 729 */     for (int i = 0; i < extraDataRecords.size(); i++)
/*  606:     */     {
/*  607: 730 */       ExtraDataRecord extraDataRecord = (ExtraDataRecord)extraDataRecords.get(i);
/*  608: 731 */       if (extraDataRecord != null) {
/*  609: 735 */         if (extraDataRecord.getHeader() == 1L)
/*  610:     */         {
/*  611: 737 */           Zip64ExtendedInfo zip64ExtendedInfo = new Zip64ExtendedInfo();
/*  612:     */           
/*  613: 739 */           byte[] byteBuff = extraDataRecord.getData();
/*  614: 741 */           if (extraDataRecord.getSizeOfData() <= 0) {
/*  615:     */             break;
/*  616:     */           }
/*  617: 744 */           byte[] longByteBuff = new byte[8];
/*  618: 745 */           byte[] intByteBuff = new byte[4];
/*  619: 746 */           int counter = 0;
/*  620: 747 */           boolean valueAdded = false;
/*  621: 749 */           if (((unCompressedSize & 0xFFFF) == 65535L) && (counter < extraDataRecord.getSizeOfData()))
/*  622:     */           {
/*  623: 750 */             System.arraycopy(byteBuff, counter, longByteBuff, 0, 8);
/*  624: 751 */             long val = Raw.readLongLittleEndian(longByteBuff, 0);
/*  625: 752 */             zip64ExtendedInfo.setUnCompressedSize(val);
/*  626: 753 */             counter += 8;
/*  627: 754 */             valueAdded = true;
/*  628:     */           }
/*  629: 757 */           if (((compressedSize & 0xFFFF) == 65535L) && (counter < extraDataRecord.getSizeOfData()))
/*  630:     */           {
/*  631: 758 */             System.arraycopy(byteBuff, counter, longByteBuff, 0, 8);
/*  632: 759 */             long val = Raw.readLongLittleEndian(longByteBuff, 0);
/*  633: 760 */             zip64ExtendedInfo.setCompressedSize(val);
/*  634: 761 */             counter += 8;
/*  635: 762 */             valueAdded = true;
/*  636:     */           }
/*  637: 765 */           if (((offsetLocalHeader & 0xFFFF) == 65535L) && (counter < extraDataRecord.getSizeOfData()))
/*  638:     */           {
/*  639: 766 */             System.arraycopy(byteBuff, counter, longByteBuff, 0, 8);
/*  640: 767 */             long val = Raw.readLongLittleEndian(longByteBuff, 0);
/*  641: 768 */             zip64ExtendedInfo.setOffsetLocalHeader(val);
/*  642: 769 */             counter += 8;
/*  643: 770 */             valueAdded = true;
/*  644:     */           }
/*  645: 773 */           if (((diskNumberStart & 0xFFFF) == 65535) && (counter < extraDataRecord.getSizeOfData()))
/*  646:     */           {
/*  647: 774 */             System.arraycopy(byteBuff, counter, intByteBuff, 0, 4);
/*  648: 775 */             int val = Raw.readIntLittleEndian(intByteBuff, 0);
/*  649: 776 */             zip64ExtendedInfo.setDiskNumberStart(val);
/*  650: 777 */             counter += 8;
/*  651: 778 */             valueAdded = true;
/*  652:     */           }
/*  653: 781 */           if (!valueAdded) {
/*  654:     */             break;
/*  655:     */           }
/*  656: 782 */           return zip64ExtendedInfo;
/*  657:     */         }
/*  658:     */       }
/*  659:     */     }
/*  660: 788 */     return null;
/*  661:     */   }
/*  662:     */   
/*  663:     */   private void setFilePointerToReadZip64EndCentralDirLoc()
/*  664:     */     throws ZipException
/*  665:     */   {
/*  666:     */     try
/*  667:     */     {
/*  668: 798 */       byte[] ebs = new byte[4];
/*  669: 799 */       long pos = this.zip4jRaf.length() - 22L;
/*  670:     */       do
/*  671:     */       {
/*  672: 802 */         this.zip4jRaf.seek(pos--);
/*  673: 803 */       } while (Raw.readLeInt(this.zip4jRaf, ebs) != 101010256L);
/*  674: 814 */       this.zip4jRaf.seek(this.zip4jRaf.getFilePointer() - 4L - 4L - 8L - 4L - 4L);
/*  675:     */     }
/*  676:     */     catch (IOException e)
/*  677:     */     {
/*  678: 816 */       throw new ZipException(e);
/*  679:     */     }
/*  680:     */   }
/*  681:     */   
/*  682:     */   public LocalFileHeader readLocalFileHeader(FileHeader fileHeader)
/*  683:     */     throws ZipException
/*  684:     */   {
/*  685: 827 */     if ((fileHeader == null) || (this.zip4jRaf == null)) {
/*  686: 828 */       throw new ZipException("invalid read parameters for local header");
/*  687:     */     }
/*  688: 831 */     long locHdrOffset = fileHeader.getOffsetLocalHeader();
/*  689: 833 */     if (fileHeader.getZip64ExtendedInfo() != null)
/*  690:     */     {
/*  691: 834 */       Zip64ExtendedInfo zip64ExtendedInfo = fileHeader.getZip64ExtendedInfo();
/*  692: 835 */       if (zip64ExtendedInfo.getOffsetLocalHeader() > 0L) {
/*  693: 836 */         locHdrOffset = fileHeader.getOffsetLocalHeader();
/*  694:     */       }
/*  695:     */     }
/*  696: 840 */     if (locHdrOffset < 0L) {
/*  697: 841 */       throw new ZipException("invalid local header offset");
/*  698:     */     }
/*  699:     */     try
/*  700:     */     {
/*  701: 845 */       this.zip4jRaf.seek(locHdrOffset);
/*  702:     */       
/*  703: 847 */       int length = 0;
/*  704: 848 */       LocalFileHeader localFileHeader = new LocalFileHeader();
/*  705:     */       
/*  706: 850 */       byte[] shortBuff = new byte[2];
/*  707: 851 */       byte[] intBuff = new byte[4];
/*  708: 852 */       byte[] longBuff = new byte[8];
/*  709:     */       
/*  710:     */ 
/*  711: 855 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  712: 856 */       int sig = Raw.readIntLittleEndian(intBuff, 0);
/*  713: 857 */       if (sig != 67324752L) {
/*  714: 858 */         throw new ZipException("invalid local header signature for file: " + fileHeader.getFileName());
/*  715:     */       }
/*  716: 860 */       localFileHeader.setSignature(sig);
/*  717: 861 */       length += 4;
/*  718:     */       
/*  719:     */ 
/*  720: 864 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*  721: 865 */       localFileHeader.setVersionNeededToExtract(Raw.readShortLittleEndian(shortBuff, 0));
/*  722: 866 */       length += 2;
/*  723:     */       
/*  724:     */ 
/*  725: 869 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*  726: 870 */       localFileHeader.setFileNameUTF8Encoded((Raw.readShortLittleEndian(shortBuff, 0) & 0x800) != 0);
/*  727: 871 */       int firstByte = shortBuff[0];
/*  728: 872 */       int result = firstByte & 0x1;
/*  729: 873 */       if (result != 0) {
/*  730: 874 */         localFileHeader.setEncrypted(true);
/*  731:     */       }
/*  732: 876 */       localFileHeader.setGeneralPurposeFlag(shortBuff);
/*  733: 877 */       length += 2;
/*  734:     */       
/*  735:     */ 
/*  736: 880 */       String binary = Integer.toBinaryString(firstByte);
/*  737: 881 */       if (binary.length() >= 4) {
/*  738: 882 */         localFileHeader.setDataDescriptorExists(binary.charAt(3) == '1');
/*  739:     */       }
/*  740: 885 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*  741: 886 */       localFileHeader.setCompressionMethod(Raw.readShortLittleEndian(shortBuff, 0));
/*  742: 887 */       length += 2;
/*  743:     */       
/*  744:     */ 
/*  745: 890 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  746: 891 */       localFileHeader.setLastModFileTime(Raw.readIntLittleEndian(intBuff, 0));
/*  747: 892 */       length += 4;
/*  748:     */       
/*  749:     */ 
/*  750: 895 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  751: 896 */       localFileHeader.setCrc32(Raw.readIntLittleEndian(intBuff, 0));
/*  752: 897 */       localFileHeader.setCrcBuff((byte[])intBuff.clone());
/*  753: 898 */       length += 4;
/*  754:     */       
/*  755:     */ 
/*  756: 901 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  757: 902 */       longBuff = getLongByteFromIntByte(intBuff);
/*  758: 903 */       localFileHeader.setCompressedSize(Raw.readLongLittleEndian(longBuff, 0));
/*  759: 904 */       length += 4;
/*  760:     */       
/*  761:     */ 
/*  762: 907 */       readIntoBuff(this.zip4jRaf, intBuff);
/*  763: 908 */       longBuff = getLongByteFromIntByte(intBuff);
/*  764: 909 */       localFileHeader.setUncompressedSize(Raw.readLongLittleEndian(longBuff, 0));
/*  765: 910 */       length += 4;
/*  766:     */       
/*  767:     */ 
/*  768: 913 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*  769: 914 */       int fileNameLength = Raw.readShortLittleEndian(shortBuff, 0);
/*  770: 915 */       localFileHeader.setFileNameLength(fileNameLength);
/*  771: 916 */       length += 2;
/*  772:     */       
/*  773:     */ 
/*  774: 919 */       readIntoBuff(this.zip4jRaf, shortBuff);
/*  775: 920 */       int extraFieldLength = Raw.readShortLittleEndian(shortBuff, 0);
/*  776: 921 */       localFileHeader.setExtraFieldLength(extraFieldLength);
/*  777: 922 */       length += 2;
/*  778: 925 */       if (fileNameLength > 0)
/*  779:     */       {
/*  780: 926 */         byte[] fileNameBuf = new byte[fileNameLength];
/*  781: 927 */         readIntoBuff(this.zip4jRaf, fileNameBuf);
/*  782:     */         
/*  783:     */ 
/*  784:     */ 
/*  785: 931 */         String fileName = Zip4jUtil.decodeFileName(fileNameBuf, localFileHeader.isFileNameUTF8Encoded());
/*  786: 933 */         if (fileName == null) {
/*  787: 934 */           throw new ZipException("file name is null, cannot assign file name to local file header");
/*  788:     */         }
/*  789: 937 */         if (fileName.indexOf(":" + System.getProperty("file.separator")) >= 0) {
/*  790: 938 */           fileName = fileName.substring(fileName.indexOf(":" + System.getProperty("file.separator")) + 2);
/*  791:     */         }
/*  792: 941 */         localFileHeader.setFileName(fileName);
/*  793: 942 */         length += fileNameLength;
/*  794:     */       }
/*  795:     */       else
/*  796:     */       {
/*  797: 944 */         localFileHeader.setFileName(null);
/*  798:     */       }
/*  799: 948 */       readAndSaveExtraDataRecord(localFileHeader);
/*  800: 949 */       length += extraFieldLength;
/*  801:     */       
/*  802: 951 */       localFileHeader.setOffsetStartOfData(locHdrOffset + length);
/*  803:     */       
/*  804:     */ 
/*  805: 954 */       localFileHeader.setPassword(fileHeader.getPassword());
/*  806:     */       
/*  807: 956 */       readAndSaveZip64ExtendedInfo(localFileHeader);
/*  808:     */       
/*  809: 958 */       readAndSaveAESExtraDataRecord(localFileHeader);
/*  810: 960 */       if (localFileHeader.isEncrypted()) {
/*  811: 962 */         if (localFileHeader.getEncryptionMethod() != 99) {
/*  812: 965 */           if ((firstByte & 0x40) == 64) {
/*  813: 967 */             localFileHeader.setEncryptionMethod(1);
/*  814:     */           } else {
/*  815: 969 */             localFileHeader.setEncryptionMethod(0);
/*  816:     */           }
/*  817:     */         }
/*  818:     */       }
/*  819: 977 */       if (localFileHeader.getCrc32() <= 0L)
/*  820:     */       {
/*  821: 978 */         localFileHeader.setCrc32(fileHeader.getCrc32());
/*  822: 979 */         localFileHeader.setCrcBuff(fileHeader.getCrcBuff());
/*  823:     */       }
/*  824: 982 */       if (localFileHeader.getCompressedSize() <= 0L) {
/*  825: 983 */         localFileHeader.setCompressedSize(fileHeader.getCompressedSize());
/*  826:     */       }
/*  827: 986 */       if (localFileHeader.getUncompressedSize() <= 0L) {
/*  828: 987 */         localFileHeader.setUncompressedSize(fileHeader.getUncompressedSize());
/*  829:     */       }
/*  830: 990 */       return localFileHeader;
/*  831:     */     }
/*  832:     */     catch (IOException e)
/*  833:     */     {
/*  834: 992 */       throw new ZipException(e);
/*  835:     */     }
/*  836:     */   }
/*  837:     */   
/*  838:     */   private void readAndSaveAESExtraDataRecord(FileHeader fileHeader)
/*  839:     */     throws ZipException
/*  840:     */   {
/*  841:1002 */     if (fileHeader == null) {
/*  842:1003 */       throw new ZipException("file header is null in reading Zip64 Extended Info");
/*  843:     */     }
/*  844:1006 */     if ((fileHeader.getExtraDataRecords() == null) || (fileHeader.getExtraDataRecords().size() <= 0)) {
/*  845:1007 */       return;
/*  846:     */     }
/*  847:1010 */     AESExtraDataRecord aesExtraDataRecord = readAESExtraDataRecord(fileHeader.getExtraDataRecords());
/*  848:1011 */     if (aesExtraDataRecord != null)
/*  849:     */     {
/*  850:1012 */       fileHeader.setAesExtraDataRecord(aesExtraDataRecord);
/*  851:1013 */       fileHeader.setEncryptionMethod(99);
/*  852:     */     }
/*  853:     */   }
/*  854:     */   
/*  855:     */   private void readAndSaveAESExtraDataRecord(LocalFileHeader localFileHeader)
/*  856:     */     throws ZipException
/*  857:     */   {
/*  858:1023 */     if (localFileHeader == null) {
/*  859:1024 */       throw new ZipException("file header is null in reading Zip64 Extended Info");
/*  860:     */     }
/*  861:1027 */     if ((localFileHeader.getExtraDataRecords() == null) || (localFileHeader.getExtraDataRecords().size() <= 0)) {
/*  862:1028 */       return;
/*  863:     */     }
/*  864:1031 */     AESExtraDataRecord aesExtraDataRecord = readAESExtraDataRecord(localFileHeader.getExtraDataRecords());
/*  865:1032 */     if (aesExtraDataRecord != null)
/*  866:     */     {
/*  867:1033 */       localFileHeader.setAesExtraDataRecord(aesExtraDataRecord);
/*  868:1034 */       localFileHeader.setEncryptionMethod(99);
/*  869:     */     }
/*  870:     */   }
/*  871:     */   
/*  872:     */   private AESExtraDataRecord readAESExtraDataRecord(ArrayList extraDataRecords)
/*  873:     */     throws ZipException
/*  874:     */   {
/*  875:1046 */     if (extraDataRecords == null) {
/*  876:1047 */       return null;
/*  877:     */     }
/*  878:1050 */     for (int i = 0; i < extraDataRecords.size(); i++)
/*  879:     */     {
/*  880:1051 */       ExtraDataRecord extraDataRecord = (ExtraDataRecord)extraDataRecords.get(i);
/*  881:1052 */       if (extraDataRecord != null) {
/*  882:1056 */         if (extraDataRecord.getHeader() == 39169L)
/*  883:     */         {
/*  884:1058 */           if (extraDataRecord.getData() == null) {
/*  885:1059 */             throw new ZipException("corrput AES extra data records");
/*  886:     */           }
/*  887:1062 */           AESExtraDataRecord aesExtraDataRecord = new AESExtraDataRecord();
/*  888:     */           
/*  889:1064 */           aesExtraDataRecord.setSignature(39169L);
/*  890:1065 */           aesExtraDataRecord.setDataSize(extraDataRecord.getSizeOfData());
/*  891:     */           
/*  892:1067 */           byte[] aesData = extraDataRecord.getData();
/*  893:1068 */           aesExtraDataRecord.setVersionNumber(Raw.readShortLittleEndian(aesData, 0));
/*  894:1069 */           byte[] vendorIDBytes = new byte[2];
/*  895:1070 */           System.arraycopy(aesData, 2, vendorIDBytes, 0, 2);
/*  896:1071 */           aesExtraDataRecord.setVendorID(new String(vendorIDBytes));
/*  897:1072 */           aesExtraDataRecord.setAesStrength(aesData[4] & 0xFF);
/*  898:1073 */           aesExtraDataRecord.setCompressionMethod(Raw.readShortLittleEndian(aesData, 5));
/*  899:     */           
/*  900:1075 */           return aesExtraDataRecord;
/*  901:     */         }
/*  902:     */       }
/*  903:     */     }
/*  904:1079 */     return null;
/*  905:     */   }
/*  906:     */   
/*  907:     */   private byte[] readIntoBuff(RandomAccessFile zip4jRaf, byte[] buf)
/*  908:     */     throws ZipException
/*  909:     */   {
/*  910:     */     try
/*  911:     */     {
/*  912:1091 */       if (zip4jRaf.read(buf, 0, buf.length) != -1) {
/*  913:1092 */         return buf;
/*  914:     */       }
/*  915:1094 */       throw new ZipException("unexpected end of file when reading short buff");
/*  916:     */     }
/*  917:     */     catch (IOException e)
/*  918:     */     {
/*  919:1097 */       throw new ZipException("IOException when reading short buff", e);
/*  920:     */     }
/*  921:     */   }
/*  922:     */   
/*  923:     */   private byte[] getLongByteFromIntByte(byte[] intByte)
/*  924:     */     throws ZipException
/*  925:     */   {
/*  926:1108 */     if (intByte == null) {
/*  927:1109 */       throw new ZipException("input parameter is null, cannot expand to 8 bytes");
/*  928:     */     }
/*  929:1112 */     if (intByte.length != 4) {
/*  930:1113 */       throw new ZipException("invalid byte length, cannot expand to 8 bytes");
/*  931:     */     }
/*  932:1116 */     byte[] longBuff = { intByte[0], intByte[1], intByte[2], intByte[3], 0, 0, 0, 0 };
/*  933:1117 */     return longBuff;
/*  934:     */   }
/*  935:     */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.core.HeaderReader
 * JD-Core Version:    0.7.0.1
 */