/*   1:    */ package net.lingala.zip4j.zip;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileInputStream;
/*   5:    */ import java.io.FileNotFoundException;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.RandomAccessFile;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.HashMap;
/*  11:    */ import net.lingala.zip4j.exception.ZipException;
/*  12:    */ import net.lingala.zip4j.io.SplitOutputStream;
/*  13:    */ import net.lingala.zip4j.io.ZipOutputStream;
/*  14:    */ import net.lingala.zip4j.model.CentralDirectory;
/*  15:    */ import net.lingala.zip4j.model.EndCentralDirRecord;
/*  16:    */ import net.lingala.zip4j.model.FileHeader;
/*  17:    */ import net.lingala.zip4j.model.ZipModel;
/*  18:    */ import net.lingala.zip4j.model.ZipParameters;
/*  19:    */ import net.lingala.zip4j.progress.ProgressMonitor;
/*  20:    */ import net.lingala.zip4j.util.ArchiveMaintainer;
/*  21:    */ import net.lingala.zip4j.util.CRCUtil;
/*  22:    */ import net.lingala.zip4j.util.Zip4jUtil;
/*  23:    */ 
/*  24:    */ public class ZipEngine
/*  25:    */ {
/*  26:    */   private ZipModel zipModel;
/*  27:    */   
/*  28:    */   public ZipEngine(ZipModel zipModel)
/*  29:    */     throws ZipException
/*  30:    */   {
/*  31: 48 */     if (zipModel == null) {
/*  32: 49 */       throw new ZipException("zip model is null in ZipEngine constructor");
/*  33:    */     }
/*  34: 52 */     this.zipModel = zipModel;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void addFiles(final ArrayList fileList, final ZipParameters parameters, final ProgressMonitor progressMonitor, boolean runInThread)
/*  38:    */     throws ZipException
/*  39:    */   {
/*  40: 58 */     if ((fileList == null) || (parameters == null)) {
/*  41: 59 */       throw new ZipException("one of the input parameters is null when adding files");
/*  42:    */     }
/*  43: 62 */     if (fileList.size() <= 0) {
/*  44: 63 */       throw new ZipException("no files to add");
/*  45:    */     }
/*  46: 66 */     progressMonitor.setCurrentOperation(0);
/*  47: 67 */     progressMonitor.setState(1);
/*  48: 68 */     progressMonitor.setResult(1);
/*  49: 70 */     if (runInThread)
/*  50:    */     {
/*  51: 71 */       progressMonitor.setTotalWork(calculateTotalWork(fileList, parameters));
/*  52: 72 */       progressMonitor.setFileName(((File)fileList.get(0)).getAbsolutePath());
/*  53:    */       
/*  54: 74 */       Thread thread = new Thread("Zip4j")
/*  55:    */       {
/*  56:    */         public void run()
/*  57:    */         {
/*  58:    */           try
/*  59:    */           {
/*  60: 77 */             ZipEngine.this.initAddFiles(fileList, parameters, progressMonitor);
/*  61:    */           }
/*  62:    */           catch (ZipException localZipException) {}
/*  63:    */         }
/*  64: 81 */       };
/*  65: 82 */       thread.start();
/*  66:    */     }
/*  67:    */     else
/*  68:    */     {
/*  69: 85 */       initAddFiles(fileList, parameters, progressMonitor);
/*  70:    */     }
/*  71:    */   }
/*  72:    */   
/*  73:    */   private void initAddFiles(ArrayList fileList, ZipParameters parameters, ProgressMonitor progressMonitor)
/*  74:    */     throws ZipException
/*  75:    */   {
/*  76: 92 */     if ((fileList == null) || (parameters == null)) {
/*  77: 93 */       throw new ZipException("one of the input parameters is null when adding files");
/*  78:    */     }
/*  79: 96 */     if (fileList.size() <= 0) {
/*  80: 97 */       throw new ZipException("no files to add");
/*  81:    */     }
/*  82:100 */     if (this.zipModel.getEndCentralDirRecord() == null) {
/*  83:101 */       this.zipModel.setEndCentralDirRecord(createEndOfCentralDirectoryRecord());
/*  84:    */     }
/*  85:104 */     ZipOutputStream outputStream = null;
/*  86:105 */     InputStream inputStream = null;
/*  87:    */     try
/*  88:    */     {
/*  89:107 */       checkParameters(parameters);
/*  90:    */       
/*  91:109 */       removeFilesIfExists(fileList, parameters, progressMonitor);
/*  92:    */       
/*  93:111 */       boolean isZipFileAlreadExists = Zip4jUtil.checkFileExists(this.zipModel.getZipFile());
/*  94:    */       
/*  95:113 */       SplitOutputStream splitOutputStream = new SplitOutputStream(new File(this.zipModel.getZipFile()), this.zipModel.getSplitLength());
/*  96:114 */       outputStream = new ZipOutputStream(splitOutputStream, this.zipModel);
/*  97:116 */       if (isZipFileAlreadExists)
/*  98:    */       {
/*  99:117 */         if (this.zipModel.getEndCentralDirRecord() == null) {
/* 100:118 */           throw new ZipException("invalid end of central directory record");
/* 101:    */         }
/* 102:120 */         splitOutputStream.seek(this.zipModel.getEndCentralDirRecord().getOffsetOfStartOfCentralDir());
/* 103:    */       }
/* 104:122 */       byte[] readBuff = new byte[4096];
/* 105:123 */       int readLen = -1;
/* 106:124 */       for (int i = 0; i < fileList.size(); i++)
/* 107:    */       {
/* 108:126 */         if (progressMonitor.isCancelAllTasks())
/* 109:    */         {
/* 110:127 */           progressMonitor.setResult(3);
/* 111:128 */           progressMonitor.setState(0);
/* 112:129 */           return;
/* 113:    */         }
/* 114:132 */         ZipParameters fileParameters = (ZipParameters)parameters.clone();
/* 115:    */         
/* 116:134 */         progressMonitor.setFileName(((File)fileList.get(i)).getAbsolutePath());
/* 117:136 */         if (!((File)fileList.get(i)).isDirectory())
/* 118:    */         {
/* 119:137 */           if ((fileParameters.isEncryptFiles()) && (fileParameters.getEncryptionMethod() == 0))
/* 120:    */           {
/* 121:138 */             progressMonitor.setCurrentOperation(3);
/* 122:139 */             fileParameters.setSourceFileCRC((int)CRCUtil.computeFileCRC(((File)fileList.get(i)).getAbsolutePath(), progressMonitor));
/* 123:140 */             progressMonitor.setCurrentOperation(0);
/* 124:142 */             if (progressMonitor.isCancelAllTasks())
/* 125:    */             {
/* 126:143 */               progressMonitor.setResult(3);
/* 127:144 */               progressMonitor.setState(0);
/* 128:145 */               return;
/* 129:    */             }
/* 130:    */           }
/* 131:149 */           if (Zip4jUtil.getFileLengh((File)fileList.get(i)) == 0L) {
/* 132:150 */             fileParameters.setCompressionMethod(0);
/* 133:    */           }
/* 134:    */         }
/* 135:154 */         outputStream.putNextEntry((File)fileList.get(i), fileParameters);
/* 136:155 */         if (((File)fileList.get(i)).isDirectory())
/* 137:    */         {
/* 138:156 */           outputStream.closeEntry();
/* 139:    */         }
/* 140:    */         else
/* 141:    */         {
/* 142:160 */           inputStream = new FileInputStream((File)fileList.get(i));
/* 143:162 */           while ((readLen = inputStream.read(readBuff)) != -1)
/* 144:    */           {
/* 145:163 */             if (progressMonitor.isCancelAllTasks())
/* 146:    */             {
/* 147:164 */               progressMonitor.setResult(3);
/* 148:165 */               progressMonitor.setState(0);
/* 149:166 */               return;
/* 150:    */             }
/* 151:169 */             outputStream.write(readBuff, 0, readLen);
/* 152:170 */             progressMonitor.updateWorkCompleted(readLen);
/* 153:    */           }
/* 154:173 */           outputStream.closeEntry();
/* 155:175 */           if (inputStream != null) {
/* 156:176 */             inputStream.close();
/* 157:    */           }
/* 158:    */         }
/* 159:    */       }
/* 160:180 */       outputStream.finish();
/* 161:181 */       progressMonitor.endProgressMonitorSuccess(); return;
/* 162:    */     }
/* 163:    */     catch (ZipException e)
/* 164:    */     {
/* 165:183 */       progressMonitor.endProgressMonitorError(e);
/* 166:184 */       throw e;
/* 167:    */     }
/* 168:    */     catch (Exception e)
/* 169:    */     {
/* 170:186 */       progressMonitor.endProgressMonitorError(e);
/* 171:187 */       throw new ZipException(e);
/* 172:    */     }
/* 173:    */     finally
/* 174:    */     {
/* 175:189 */       if (inputStream != null) {
/* 176:    */         try
/* 177:    */         {
/* 178:191 */           inputStream.close();
/* 179:    */         }
/* 180:    */         catch (IOException localIOException8) {}
/* 181:    */       }
/* 182:196 */       if (outputStream != null) {
/* 183:    */         try
/* 184:    */         {
/* 185:198 */           outputStream.close();
/* 186:    */         }
/* 187:    */         catch (IOException localIOException9) {}
/* 188:    */       }
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void addStreamToZip(InputStream inputStream, ZipParameters parameters)
/* 193:    */     throws ZipException
/* 194:    */   {
/* 195:206 */     if ((inputStream == null) || (parameters == null)) {
/* 196:207 */       throw new ZipException("one of the input parameters is null, cannot add stream to zip");
/* 197:    */     }
/* 198:210 */     ZipOutputStream outputStream = null;
/* 199:    */     try
/* 200:    */     {
/* 201:213 */       checkParameters(parameters);
/* 202:    */       
/* 203:215 */       boolean isZipFileAlreadExists = Zip4jUtil.checkFileExists(this.zipModel.getZipFile());
/* 204:    */       
/* 205:217 */       SplitOutputStream splitOutputStream = new SplitOutputStream(new File(this.zipModel.getZipFile()), this.zipModel.getSplitLength());
/* 206:218 */       outputStream = new ZipOutputStream(splitOutputStream, this.zipModel);
/* 207:220 */       if (isZipFileAlreadExists)
/* 208:    */       {
/* 209:221 */         if (this.zipModel.getEndCentralDirRecord() == null) {
/* 210:222 */           throw new ZipException("invalid end of central directory record");
/* 211:    */         }
/* 212:224 */         splitOutputStream.seek(this.zipModel.getEndCentralDirRecord().getOffsetOfStartOfCentralDir());
/* 213:    */       }
/* 214:227 */       byte[] readBuff = new byte[4096];
/* 215:228 */       int readLen = -1;
/* 216:    */       
/* 217:230 */       outputStream.putNextEntry(null, parameters);
/* 218:232 */       if ((!parameters.getFileNameInZip().endsWith("/")) && 
/* 219:233 */         (!parameters.getFileNameInZip().endsWith("\\"))) {
/* 220:234 */         while ((readLen = inputStream.read(readBuff)) != -1) {
/* 221:235 */           outputStream.write(readBuff, 0, readLen);
/* 222:    */         }
/* 223:    */       }
/* 224:239 */       outputStream.closeEntry();
/* 225:240 */       outputStream.finish(); return;
/* 226:    */     }
/* 227:    */     catch (ZipException e)
/* 228:    */     {
/* 229:243 */       throw e;
/* 230:    */     }
/* 231:    */     catch (Exception e)
/* 232:    */     {
/* 233:245 */       throw new ZipException(e);
/* 234:    */     }
/* 235:    */     finally
/* 236:    */     {
/* 237:247 */       if (outputStream != null) {
/* 238:    */         try
/* 239:    */         {
/* 240:249 */           outputStream.close();
/* 241:    */         }
/* 242:    */         catch (IOException localIOException1) {}
/* 243:    */       }
/* 244:    */     }
/* 245:    */   }
/* 246:    */   
/* 247:    */   public void addFolderToZip(File file, ZipParameters parameters, ProgressMonitor progressMonitor, boolean runInThread)
/* 248:    */     throws ZipException
/* 249:    */   {
/* 250:259 */     if ((file == null) || (parameters == null)) {
/* 251:260 */       throw new ZipException("one of the input parameters is null, cannot add folder to zip");
/* 252:    */     }
/* 253:263 */     if (!Zip4jUtil.checkFileExists(file.getAbsolutePath())) {
/* 254:264 */       throw new ZipException("input folder does not exist");
/* 255:    */     }
/* 256:267 */     if (!file.isDirectory()) {
/* 257:268 */       throw new ZipException("input file is not a folder, user addFileToZip method to add files");
/* 258:    */     }
/* 259:271 */     if (!Zip4jUtil.checkFileReadAccess(file.getAbsolutePath())) {
/* 260:272 */       throw new ZipException("cannot read folder: " + file.getAbsolutePath());
/* 261:    */     }
/* 262:275 */     String rootFolderPath = null;
/* 263:276 */     if (parameters.isIncludeRootFolder())
/* 264:    */     {
/* 265:277 */       if (file.getAbsolutePath() != null) {
/* 266:278 */         rootFolderPath = file.getAbsoluteFile().getParentFile() != null ? file.getAbsoluteFile().getParentFile().getAbsolutePath() : "";
/* 267:    */       } else {
/* 268:280 */         rootFolderPath = file.getParentFile() != null ? file.getParentFile().getAbsolutePath() : "";
/* 269:    */       }
/* 270:    */     }
/* 271:    */     else {
/* 272:283 */       rootFolderPath = file.getAbsolutePath();
/* 273:    */     }
/* 274:286 */     parameters.setDefaultFolderPath(rootFolderPath);
/* 275:    */     
/* 276:288 */     ArrayList fileList = Zip4jUtil.getFilesInDirectoryRec(file, parameters.isReadHiddenFiles());
/* 277:290 */     if (parameters.isIncludeRootFolder())
/* 278:    */     {
/* 279:291 */       if (fileList == null) {
/* 280:292 */         fileList = new ArrayList();
/* 281:    */       }
/* 282:294 */       fileList.add(file);
/* 283:    */     }
/* 284:297 */     addFiles(fileList, parameters, progressMonitor, runInThread);
/* 285:    */   }
/* 286:    */   
/* 287:    */   private void checkParameters(ZipParameters parameters)
/* 288:    */     throws ZipException
/* 289:    */   {
/* 290:303 */     if (parameters == null) {
/* 291:304 */       throw new ZipException("cannot validate zip parameters");
/* 292:    */     }
/* 293:307 */     if ((parameters.getCompressionMethod() != 0) && 
/* 294:308 */       (parameters.getCompressionMethod() != 8)) {
/* 295:309 */       throw new ZipException("unsupported compression type");
/* 296:    */     }
/* 297:312 */     if ((parameters.getCompressionMethod() == 8) && 
/* 298:313 */       (parameters.getCompressionLevel() < 0) && (parameters.getCompressionLevel() > 9)) {
/* 299:314 */       throw new ZipException("invalid compression level. compression level dor deflate should be in the range of 0-9");
/* 300:    */     }
/* 301:318 */     if (parameters.isEncryptFiles())
/* 302:    */     {
/* 303:319 */       if ((parameters.getEncryptionMethod() != 0) && 
/* 304:320 */         (parameters.getEncryptionMethod() != 99)) {
/* 305:321 */         throw new ZipException("unsupported encryption method");
/* 306:    */       }
/* 307:324 */       if ((parameters.getPassword() == null) || (parameters.getPassword().length <= 0)) {
/* 308:325 */         throw new ZipException("input password is empty or null");
/* 309:    */       }
/* 310:    */     }
/* 311:    */     else
/* 312:    */     {
/* 313:328 */       parameters.setAesKeyStrength(-1);
/* 314:329 */       parameters.setEncryptionMethod(-1);
/* 315:    */     }
/* 316:    */   }
/* 317:    */   
/* 318:    */   private void removeFilesIfExists(ArrayList fileList, ZipParameters parameters, ProgressMonitor progressMonitor)
/* 319:    */     throws ZipException
/* 320:    */   {
/* 321:347 */     if ((this.zipModel == null) || (this.zipModel.getCentralDirectory() == null) || 
/* 322:348 */       (this.zipModel.getCentralDirectory().getFileHeaders() == null) || 
/* 323:349 */       (this.zipModel.getCentralDirectory().getFileHeaders().size() <= 0)) {
/* 324:351 */       return;
/* 325:    */     }
/* 326:353 */     RandomAccessFile outputStream = null;
/* 327:    */     try
/* 328:    */     {
/* 329:356 */       for (int i = 0; i < fileList.size(); i++)
/* 330:    */       {
/* 331:357 */         File file = (File)fileList.get(i);
/* 332:    */         
/* 333:359 */         String fileName = Zip4jUtil.getRelativeFileName(file.getAbsolutePath(), parameters
/* 334:360 */           .getRootFolderInZip(), parameters.getDefaultFolderPath());
/* 335:    */         
/* 336:362 */         FileHeader fileHeader = Zip4jUtil.getFileHeader(this.zipModel, fileName);
/* 337:363 */         if (fileHeader != null)
/* 338:    */         {
/* 339:365 */           if (outputStream != null)
/* 340:    */           {
/* 341:366 */             outputStream.close();
/* 342:367 */             outputStream = null;
/* 343:    */           }
/* 344:370 */           ArchiveMaintainer archiveMaintainer = new ArchiveMaintainer();
/* 345:371 */           progressMonitor.setCurrentOperation(2);
/* 346:372 */           HashMap retMap = archiveMaintainer.initRemoveZipFile(this.zipModel, fileHeader, progressMonitor);
/* 347:375 */           if (progressMonitor.isCancelAllTasks())
/* 348:    */           {
/* 349:376 */             progressMonitor.setResult(3);
/* 350:377 */             progressMonitor.setState(0);
/* 351:378 */             return;
/* 352:    */           }
/* 353:382 */           progressMonitor.setCurrentOperation(0);
/* 354:384 */           if (outputStream == null)
/* 355:    */           {
/* 356:385 */             outputStream = prepareFileOutputStream();
/* 357:387 */             if ((retMap != null) && 
/* 358:388 */               (retMap.get("offsetCentralDir") != null))
/* 359:    */             {
/* 360:389 */               long offsetCentralDir = -1L;
/* 361:    */               try
/* 362:    */               {
/* 363:392 */                 offsetCentralDir = Long.parseLong(
/* 364:393 */                   (String)retMap.get("offsetCentralDir"));
/* 365:    */               }
/* 366:    */               catch (NumberFormatException e)
/* 367:    */               {
/* 368:395 */                 throw new ZipException("NumberFormatException while parsing offset central directory. Cannot update already existing file header");
/* 369:    */               }
/* 370:    */               catch (Exception e)
/* 371:    */               {
/* 372:399 */                 throw new ZipException("Error while parsing offset central directory. Cannot update already existing file header");
/* 373:    */               }
/* 374:404 */               if (offsetCentralDir >= 0L) {
/* 375:405 */                 outputStream.seek(offsetCentralDir);
/* 376:    */               }
/* 377:    */             }
/* 378:    */           }
/* 379:    */         }
/* 380:    */       }
/* 381:    */       return;
/* 382:    */     }
/* 383:    */     catch (IOException e)
/* 384:    */     {
/* 385:413 */       throw new ZipException(e);
/* 386:    */     }
/* 387:    */     finally
/* 388:    */     {
/* 389:415 */       if (outputStream != null) {
/* 390:    */         try
/* 391:    */         {
/* 392:417 */           outputStream.close();
/* 393:    */         }
/* 394:    */         catch (IOException localIOException3) {}
/* 395:    */       }
/* 396:    */     }
/* 397:    */   }
/* 398:    */   
/* 399:    */   private RandomAccessFile prepareFileOutputStream()
/* 400:    */     throws ZipException
/* 401:    */   {
/* 402:426 */     String outPath = this.zipModel.getZipFile();
/* 403:427 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(outPath)) {
/* 404:428 */       throw new ZipException("invalid output path");
/* 405:    */     }
/* 406:    */     try
/* 407:    */     {
/* 408:432 */       File outFile = new File(outPath);
/* 409:433 */       if (!outFile.getParentFile().exists()) {
/* 410:434 */         outFile.getParentFile().mkdirs();
/* 411:    */       }
/* 412:436 */       return new RandomAccessFile(outFile, "rw");
/* 413:    */     }
/* 414:    */     catch (FileNotFoundException e)
/* 415:    */     {
/* 416:438 */       throw new ZipException(e);
/* 417:    */     }
/* 418:    */   }
/* 419:    */   
/* 420:    */   private EndCentralDirRecord createEndOfCentralDirectoryRecord()
/* 421:    */   {
/* 422:443 */     EndCentralDirRecord endCentralDirRecord = new EndCentralDirRecord();
/* 423:444 */     endCentralDirRecord.setSignature(101010256L);
/* 424:445 */     endCentralDirRecord.setNoOfThisDisk(0);
/* 425:446 */     endCentralDirRecord.setTotNoOfEntriesInCentralDir(0);
/* 426:447 */     endCentralDirRecord.setTotNoOfEntriesInCentralDirOnThisDisk(0);
/* 427:448 */     endCentralDirRecord.setOffsetOfStartOfCentralDir(0L);
/* 428:449 */     return endCentralDirRecord;
/* 429:    */   }
/* 430:    */   
/* 431:    */   private long calculateTotalWork(ArrayList fileList, ZipParameters parameters)
/* 432:    */     throws ZipException
/* 433:    */   {
/* 434:453 */     if (fileList == null) {
/* 435:454 */       throw new ZipException("file list is null, cannot calculate total work");
/* 436:    */     }
/* 437:457 */     long totalWork = 0L;
/* 438:459 */     for (int i = 0; i < fileList.size(); i++) {
/* 439:460 */       if (((fileList.get(i) instanceof File)) && 
/* 440:461 */         (((File)fileList.get(i)).exists()))
/* 441:    */       {
/* 442:462 */         if ((parameters.isEncryptFiles()) && 
/* 443:463 */           (parameters.getEncryptionMethod() == 0)) {
/* 444:464 */           totalWork += Zip4jUtil.getFileLengh((File)fileList.get(i)) * 2L;
/* 445:    */         } else {
/* 446:466 */           totalWork += Zip4jUtil.getFileLengh((File)fileList.get(i));
/* 447:    */         }
/* 448:469 */         if ((this.zipModel.getCentralDirectory() != null) && 
/* 449:470 */           (this.zipModel.getCentralDirectory().getFileHeaders() != null) && 
/* 450:471 */           (this.zipModel.getCentralDirectory().getFileHeaders().size() > 0))
/* 451:    */         {
/* 452:472 */           String relativeFileName = Zip4jUtil.getRelativeFileName(
/* 453:473 */             ((File)fileList.get(i)).getAbsolutePath(), parameters.getRootFolderInZip(), parameters.getDefaultFolderPath());
/* 454:474 */           FileHeader fileHeader = Zip4jUtil.getFileHeader(this.zipModel, relativeFileName);
/* 455:475 */           if (fileHeader != null) {
/* 456:476 */             totalWork += Zip4jUtil.getFileLengh(new File(this.zipModel.getZipFile())) - fileHeader.getCompressedSize();
/* 457:    */           }
/* 458:    */         }
/* 459:    */       }
/* 460:    */     }
/* 461:483 */     return totalWork;
/* 462:    */   }
/* 463:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.zip.ZipEngine
 * JD-Core Version:    0.7.0.1
 */