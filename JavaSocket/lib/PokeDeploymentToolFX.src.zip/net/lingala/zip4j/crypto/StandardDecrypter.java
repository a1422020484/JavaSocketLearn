/*  1:   */ package net.lingala.zip4j.crypto;
/*  2:   */ 
/*  3:   */ import net.lingala.zip4j.crypto.engine.ZipCryptoEngine;
/*  4:   */ import net.lingala.zip4j.exception.ZipException;
/*  5:   */ import net.lingala.zip4j.model.FileHeader;
/*  6:   */ 
/*  7:   */ public class StandardDecrypter
/*  8:   */   implements IDecrypter
/*  9:   */ {
/* 10:   */   private FileHeader fileHeader;
/* 11:28 */   private byte[] crc = new byte[4];
/* 12:   */   private ZipCryptoEngine zipCryptoEngine;
/* 13:   */   
/* 14:   */   public StandardDecrypter(FileHeader fileHeader, byte[] headerBytes)
/* 15:   */     throws ZipException
/* 16:   */   {
/* 17:32 */     if (fileHeader == null) {
/* 18:33 */       throw new ZipException("one of more of the input parameters were null in StandardDecryptor");
/* 19:   */     }
/* 20:36 */     this.fileHeader = fileHeader;
/* 21:37 */     this.zipCryptoEngine = new ZipCryptoEngine();
/* 22:38 */     init(headerBytes);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public int decryptData(byte[] buff)
/* 26:   */     throws ZipException
/* 27:   */   {
/* 28:42 */     return decryptData(buff, 0, buff.length);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int decryptData(byte[] buff, int start, int len)
/* 32:   */     throws ZipException
/* 33:   */   {
/* 34:46 */     if ((start < 0) || (len < 0)) {
/* 35:47 */       throw new ZipException("one of the input parameters were null in standard decrpyt data");
/* 36:   */     }
/* 37:   */     try
/* 38:   */     {
/* 39:51 */       for (int i = start; i < start + len; i++)
/* 40:   */       {
/* 41:52 */         int val = buff[i] & 0xFF;
/* 42:53 */         val = (val ^ this.zipCryptoEngine.decryptByte()) & 0xFF;
/* 43:54 */         this.zipCryptoEngine.updateKeys((byte)val);
/* 44:55 */         buff[i] = ((byte)val);
/* 45:   */       }
/* 46:57 */       return len;
/* 47:   */     }
/* 48:   */     catch (Exception e)
/* 49:   */     {
/* 50:59 */       throw new ZipException(e);
/* 51:   */     }
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void init(byte[] headerBytes)
/* 55:   */     throws ZipException
/* 56:   */   {
/* 57:64 */     byte[] crcBuff = this.fileHeader.getCrcBuff();
/* 58:65 */     this.crc[3] = ((byte)(crcBuff[3] & 0xFF));
/* 59:66 */     this.crc[2] = ((byte)(crcBuff[3] >> 8 & 0xFF));
/* 60:67 */     this.crc[1] = ((byte)(crcBuff[3] >> 16 & 0xFF));
/* 61:68 */     this.crc[0] = ((byte)(crcBuff[3] >> 24 & 0xFF));
/* 62:70 */     if ((this.crc[2] > 0) || (this.crc[1] > 0) || (this.crc[0] > 0)) {
/* 63:71 */       throw new IllegalStateException("Invalid CRC in File Header");
/* 64:   */     }
/* 65:73 */     if ((this.fileHeader.getPassword() == null) || (this.fileHeader.getPassword().length <= 0)) {
/* 66:74 */       throw new ZipException("Wrong password!", 5);
/* 67:   */     }
/* 68:77 */     this.zipCryptoEngine.initKeys(this.fileHeader.getPassword());
/* 69:   */     try
/* 70:   */     {
/* 71:80 */       int result = headerBytes[0];
/* 72:81 */       for (int i = 0; i < 12; i++)
/* 73:   */       {
/* 74:88 */         this.zipCryptoEngine.updateKeys((byte)(result ^ this.zipCryptoEngine.decryptByte()));
/* 75:89 */         if (i + 1 != 12) {
/* 76:90 */           result = headerBytes[(i + 1)];
/* 77:   */         }
/* 78:   */       }
/* 79:   */     }
/* 80:   */     catch (Exception e)
/* 81:   */     {
/* 82:93 */       throw new ZipException(e);
/* 83:   */     }
/* 84:   */   }
/* 85:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.StandardDecrypter
 * JD-Core Version:    0.7.0.1
 */