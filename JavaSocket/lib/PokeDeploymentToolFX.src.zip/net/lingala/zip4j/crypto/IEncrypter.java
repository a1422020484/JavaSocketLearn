package net.lingala.zip4j.crypto;

import net.lingala.zip4j.exception.ZipException;

public abstract interface IEncrypter
{
  public abstract int encryptData(byte[] paramArrayOfByte)
    throws ZipException;
  
  public abstract int encryptData(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws ZipException;
}


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.IEncrypter
 * JD-Core Version:    0.7.0.1
 */