/*  1:   */ package net.lingala.zip4j.crypto.engine;
/*  2:   */ 
/*  3:   */ public class ZipCryptoEngine
/*  4:   */ {
/*  5:21 */   private final int[] keys = new int[3];
/*  6:22 */   private static final int[] CRC_TABLE = new int[256];
/*  7:   */   
/*  8:   */   static
/*  9:   */   {
/* 10:25 */     for (int i = 0; i < 256; i++)
/* 11:   */     {
/* 12:26 */       int r = i;
/* 13:27 */       for (int j = 0; j < 8; j++) {
/* 14:28 */         if ((r & 0x1) == 1) {
/* 15:29 */           r = r >>> 1 ^ 0xEDB88320;
/* 16:   */         } else {
/* 17:31 */           r >>>= 1;
/* 18:   */         }
/* 19:   */       }
/* 20:34 */       CRC_TABLE[i] = r;
/* 21:   */     }
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void initKeys(char[] password)
/* 25:   */   {
/* 26:42 */     this.keys[0] = 305419896;
/* 27:43 */     this.keys[1] = 591751049;
/* 28:44 */     this.keys[2] = 878082192;
/* 29:45 */     for (int i = 0; i < password.length; i++) {
/* 30:46 */       updateKeys((byte)(password[i] & 0xFF));
/* 31:   */     }
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void updateKeys(byte charAt)
/* 35:   */   {
/* 36:51 */     this.keys[0] = crc32(this.keys[0], charAt);
/* 37:52 */     this.keys[1] += (this.keys[0] & 0xFF);
/* 38:53 */     this.keys[1] = (this.keys[1] * 134775813 + 1);
/* 39:54 */     this.keys[2] = crc32(this.keys[2], (byte)(this.keys[1] >> 24));
/* 40:   */   }
/* 41:   */   
/* 42:   */   private int crc32(int oldCrc, byte charAt)
/* 43:   */   {
/* 44:58 */     return oldCrc >>> 8 ^ CRC_TABLE[((oldCrc ^ charAt) & 0xFF)];
/* 45:   */   }
/* 46:   */   
/* 47:   */   public byte decryptByte()
/* 48:   */   {
/* 49:62 */     int temp = this.keys[2] | 0x2;
/* 50:63 */     return (byte)(temp * (temp ^ 0x1) >>> 8);
/* 51:   */   }
/* 52:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.engine.ZipCryptoEngine
 * JD-Core Version:    0.7.0.1
 */