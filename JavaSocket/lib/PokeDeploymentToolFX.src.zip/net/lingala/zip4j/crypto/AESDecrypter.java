/*   1:    */ package net.lingala.zip4j.crypto;
/*   2:    */ 
/*   3:    */ import java.util.Arrays;
/*   4:    */ import net.lingala.zip4j.crypto.PBKDF2.MacBasedPRF;
/*   5:    */ import net.lingala.zip4j.crypto.PBKDF2.PBKDF2Engine;
/*   6:    */ import net.lingala.zip4j.crypto.PBKDF2.PBKDF2Parameters;
/*   7:    */ import net.lingala.zip4j.crypto.engine.AESEngine;
/*   8:    */ import net.lingala.zip4j.exception.ZipException;
/*   9:    */ import net.lingala.zip4j.model.AESExtraDataRecord;
/*  10:    */ import net.lingala.zip4j.model.LocalFileHeader;
/*  11:    */ import net.lingala.zip4j.util.Raw;
/*  12:    */ 
/*  13:    */ public class AESDecrypter
/*  14:    */   implements IDecrypter
/*  15:    */ {
/*  16:    */   private LocalFileHeader localFileHeader;
/*  17:    */   private AESEngine aesEngine;
/*  18:    */   private MacBasedPRF mac;
/*  19: 39 */   private final int PASSWORD_VERIFIER_LENGTH = 2;
/*  20:    */   private int KEY_LENGTH;
/*  21:    */   private int MAC_LENGTH;
/*  22:    */   private int SALT_LENGTH;
/*  23:    */   private byte[] aesKey;
/*  24:    */   private byte[] macKey;
/*  25:    */   private byte[] derivedPasswordVerifier;
/*  26:    */   private byte[] storedMac;
/*  27: 49 */   private int nonce = 1;
/*  28:    */   private byte[] iv;
/*  29:    */   private byte[] counterBlock;
/*  30: 52 */   private int loopCount = 0;
/*  31:    */   
/*  32:    */   public AESDecrypter(LocalFileHeader localFileHeader, byte[] salt, byte[] passwordVerifier)
/*  33:    */     throws ZipException
/*  34:    */   {
/*  35: 57 */     if (localFileHeader == null) {
/*  36: 58 */       throw new ZipException("one of the input parameters is null in AESDecryptor Constructor");
/*  37:    */     }
/*  38: 61 */     this.localFileHeader = localFileHeader;
/*  39: 62 */     this.storedMac = null;
/*  40: 63 */     this.iv = new byte[16];
/*  41: 64 */     this.counterBlock = new byte[16];
/*  42: 65 */     init(salt, passwordVerifier);
/*  43:    */   }
/*  44:    */   
/*  45:    */   private void init(byte[] salt, byte[] passwordVerifier)
/*  46:    */     throws ZipException
/*  47:    */   {
/*  48: 69 */     if (this.localFileHeader == null) {
/*  49: 70 */       throw new ZipException("invalid file header in init method of AESDecryptor");
/*  50:    */     }
/*  51: 73 */     AESExtraDataRecord aesExtraDataRecord = this.localFileHeader.getAesExtraDataRecord();
/*  52: 74 */     if (aesExtraDataRecord == null) {
/*  53: 75 */       throw new ZipException("invalid aes extra data record - in init method of AESDecryptor");
/*  54:    */     }
/*  55: 78 */     switch (aesExtraDataRecord.getAesStrength())
/*  56:    */     {
/*  57:    */     case 1: 
/*  58: 80 */       this.KEY_LENGTH = 16;
/*  59: 81 */       this.MAC_LENGTH = 16;
/*  60: 82 */       this.SALT_LENGTH = 8;
/*  61: 83 */       break;
/*  62:    */     case 2: 
/*  63: 85 */       this.KEY_LENGTH = 24;
/*  64: 86 */       this.MAC_LENGTH = 24;
/*  65: 87 */       this.SALT_LENGTH = 12;
/*  66: 88 */       break;
/*  67:    */     case 3: 
/*  68: 90 */       this.KEY_LENGTH = 32;
/*  69: 91 */       this.MAC_LENGTH = 32;
/*  70: 92 */       this.SALT_LENGTH = 16;
/*  71: 93 */       break;
/*  72:    */     default: 
/*  73: 95 */       throw new ZipException("invalid aes key strength for file: " + this.localFileHeader.getFileName());
/*  74:    */     }
/*  75: 98 */     if ((this.localFileHeader.getPassword() == null) || (this.localFileHeader.getPassword().length <= 0)) {
/*  76: 99 */       throw new ZipException("empty or null password provided for AES Decryptor");
/*  77:    */     }
/*  78:102 */     byte[] derivedKey = deriveKey(salt, this.localFileHeader.getPassword());
/*  79:103 */     if ((derivedKey == null) || (derivedKey.length != this.KEY_LENGTH + this.MAC_LENGTH + 2)) {
/*  80:105 */       throw new ZipException("invalid derived key");
/*  81:    */     }
/*  82:108 */     this.aesKey = new byte[this.KEY_LENGTH];
/*  83:109 */     this.macKey = new byte[this.MAC_LENGTH];
/*  84:110 */     this.derivedPasswordVerifier = new byte[2];
/*  85:    */     
/*  86:112 */     System.arraycopy(derivedKey, 0, this.aesKey, 0, this.KEY_LENGTH);
/*  87:113 */     System.arraycopy(derivedKey, this.KEY_LENGTH, this.macKey, 0, this.MAC_LENGTH);
/*  88:114 */     System.arraycopy(derivedKey, this.KEY_LENGTH + this.MAC_LENGTH, this.derivedPasswordVerifier, 0, 2);
/*  89:116 */     if (this.derivedPasswordVerifier == null) {
/*  90:117 */       throw new ZipException("invalid derived password verifier for AES");
/*  91:    */     }
/*  92:120 */     if (!Arrays.equals(passwordVerifier, this.derivedPasswordVerifier)) {
/*  93:121 */       throw new ZipException("Wrong Password for file: " + this.localFileHeader.getFileName(), 5);
/*  94:    */     }
/*  95:124 */     this.aesEngine = new AESEngine(this.aesKey);
/*  96:125 */     this.mac = new MacBasedPRF("HmacSHA1");
/*  97:126 */     this.mac.init(this.macKey);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public int decryptData(byte[] buff, int start, int len)
/* 101:    */     throws ZipException
/* 102:    */   {
/* 103:131 */     if (this.aesEngine == null) {
/* 104:132 */       throw new ZipException("AES not initialized properly");
/* 105:    */     }
/* 106:    */     try
/* 107:    */     {
/* 108:137 */       for (int j = start; j < start + len; j += 16)
/* 109:    */       {
/* 110:138 */         this.loopCount = (j + 16 <= start + len ? 16 : start + len - j);
/* 111:    */         
/* 112:    */ 
/* 113:141 */         this.mac.update(buff, j, this.loopCount);
/* 114:142 */         Raw.prepareBuffAESIVBytes(this.iv, this.nonce, 16);
/* 115:143 */         this.aesEngine.processBlock(this.iv, this.counterBlock);
/* 116:145 */         for (int k = 0; k < this.loopCount; k++) {
/* 117:146 */           buff[(j + k)] = ((byte)(buff[(j + k)] ^ this.counterBlock[k]));
/* 118:    */         }
/* 119:149 */         this.nonce += 1;
/* 120:    */       }
/* 121:152 */       return len;
/* 122:    */     }
/* 123:    */     catch (ZipException e)
/* 124:    */     {
/* 125:155 */       throw e;
/* 126:    */     }
/* 127:    */     catch (Exception e)
/* 128:    */     {
/* 129:157 */       throw new ZipException(e);
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   public int decryptData(byte[] buff)
/* 134:    */     throws ZipException
/* 135:    */   {
/* 136:162 */     return decryptData(buff, 0, buff.length);
/* 137:    */   }
/* 138:    */   
/* 139:    */   private byte[] deriveKey(byte[] salt, char[] password)
/* 140:    */     throws ZipException
/* 141:    */   {
/* 142:    */     try
/* 143:    */     {
/* 144:167 */       PBKDF2Parameters p = new PBKDF2Parameters("HmacSHA1", "ISO-8859-1", salt, 1000);
/* 145:    */       
/* 146:169 */       PBKDF2Engine e = new PBKDF2Engine(p);
/* 147:170 */       return e.deriveKey(password, this.KEY_LENGTH + this.MAC_LENGTH + 2);
/* 148:    */     }
/* 149:    */     catch (Exception e)
/* 150:    */     {
/* 151:173 */       throw new ZipException(e);
/* 152:    */     }
/* 153:    */   }
/* 154:    */   
/* 155:    */   public int getPasswordVerifierLength()
/* 156:    */   {
/* 157:178 */     return 2;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public int getSaltLength()
/* 161:    */   {
/* 162:182 */     return this.SALT_LENGTH;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public byte[] getCalculatedAuthenticationBytes()
/* 166:    */   {
/* 167:186 */     return this.mac.doFinal();
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void setStoredMac(byte[] storedMac)
/* 171:    */   {
/* 172:190 */     this.storedMac = storedMac;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public byte[] getStoredMac()
/* 176:    */   {
/* 177:194 */     return this.storedMac;
/* 178:    */   }
/* 179:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.AESDecrypter
 * JD-Core Version:    0.7.0.1
 */