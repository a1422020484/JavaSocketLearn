/*   1:    */ package net.lingala.zip4j.crypto;
/*   2:    */ 
/*   3:    */ import java.util.Random;
/*   4:    */ import net.lingala.zip4j.crypto.engine.ZipCryptoEngine;
/*   5:    */ import net.lingala.zip4j.exception.ZipException;
/*   6:    */ 
/*   7:    */ public class StandardEncrypter
/*   8:    */   implements IEncrypter
/*   9:    */ {
/*  10:    */   private ZipCryptoEngine zipCryptoEngine;
/*  11:    */   private byte[] headerBytes;
/*  12:    */   
/*  13:    */   public StandardEncrypter(char[] password, int crc)
/*  14:    */     throws ZipException
/*  15:    */   {
/*  16: 31 */     if ((password == null) || (password.length <= 0)) {
/*  17: 32 */       throw new ZipException("input password is null or empty in standard encrpyter constructor");
/*  18:    */     }
/*  19: 35 */     this.zipCryptoEngine = new ZipCryptoEngine();
/*  20:    */     
/*  21: 37 */     this.headerBytes = new byte[12];
/*  22: 38 */     init(password, crc);
/*  23:    */   }
/*  24:    */   
/*  25:    */   private void init(char[] password, int crc)
/*  26:    */     throws ZipException
/*  27:    */   {
/*  28: 42 */     if ((password == null) || (password.length <= 0)) {
/*  29: 43 */       throw new ZipException("input password is null or empty, cannot initialize standard encrypter");
/*  30:    */     }
/*  31: 45 */     this.zipCryptoEngine.initKeys(password);
/*  32: 46 */     this.headerBytes = generateRandomBytes(12);
/*  33:    */     
/*  34: 48 */     this.zipCryptoEngine.initKeys(password);
/*  35:    */     
/*  36: 50 */     this.headerBytes[11] = ((byte)(crc >>> 24));
/*  37: 51 */     this.headerBytes[10] = ((byte)(crc >>> 16));
/*  38: 53 */     if (this.headerBytes.length < 12) {
/*  39: 54 */       throw new ZipException("invalid header bytes generated, cannot perform standard encryption");
/*  40:    */     }
/*  41: 57 */     encryptData(this.headerBytes);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public int encryptData(byte[] buff)
/*  45:    */     throws ZipException
/*  46:    */   {
/*  47: 61 */     if (buff == null) {
/*  48: 62 */       throw new NullPointerException();
/*  49:    */     }
/*  50: 64 */     return encryptData(buff, 0, buff.length);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public int encryptData(byte[] buff, int start, int len)
/*  54:    */     throws ZipException
/*  55:    */   {
/*  56: 69 */     if (len < 0) {
/*  57: 70 */       throw new ZipException("invalid length specified to decrpyt data");
/*  58:    */     }
/*  59:    */     try
/*  60:    */     {
/*  61: 74 */       for (int i = start; i < start + len; i++) {
/*  62: 75 */         buff[i] = encryptByte(buff[i]);
/*  63:    */       }
/*  64: 77 */       return len;
/*  65:    */     }
/*  66:    */     catch (Exception e)
/*  67:    */     {
/*  68: 79 */       throw new ZipException(e);
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   protected byte encryptByte(byte val)
/*  73:    */   {
/*  74: 84 */     byte temp_val = (byte)(val ^ this.zipCryptoEngine.decryptByte() & 0xFF);
/*  75: 85 */     this.zipCryptoEngine.updateKeys(val);
/*  76: 86 */     return temp_val;
/*  77:    */   }
/*  78:    */   
/*  79:    */   protected byte[] generateRandomBytes(int size)
/*  80:    */     throws ZipException
/*  81:    */   {
/*  82: 91 */     if (size <= 0) {
/*  83: 92 */       throw new ZipException("size is either 0 or less than 0, cannot generate header for standard encryptor");
/*  84:    */     }
/*  85: 95 */     byte[] buff = new byte[size];
/*  86:    */     
/*  87: 97 */     Random rand = new Random();
/*  88: 99 */     for (int i = 0; i < buff.length; i++) {
/*  89:102 */       buff[i] = encryptByte((byte)rand.nextInt(256));
/*  90:    */     }
/*  91:126 */     return buff;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public byte[] getHeaderBytes()
/*  95:    */   {
/*  96:130 */     return this.headerBytes;
/*  97:    */   }
/*  98:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.StandardEncrypter
 * JD-Core Version:    0.7.0.1
 */