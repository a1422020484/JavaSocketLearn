/*  1:   */ package net.lingala.zip4j.crypto.PBKDF2;
/*  2:   */ 
/*  3:   */ class BinTools
/*  4:   */ {
/*  5:   */   public static final String hex = "0123456789ABCDEF";
/*  6:   */   
/*  7:   */   public static String bin2hex(byte[] b)
/*  8:   */   {
/*  9:30 */     if (b == null) {
/* 10:32 */       return "";
/* 11:   */     }
/* 12:34 */     StringBuffer sb = new StringBuffer(2 * b.length);
/* 13:35 */     for (int i = 0; i < b.length; i++)
/* 14:   */     {
/* 15:37 */       int v = (256 + b[i]) % 256;
/* 16:38 */       sb.append("0123456789ABCDEF".charAt(v / 16 & 0xF));
/* 17:39 */       sb.append("0123456789ABCDEF".charAt(v % 16 & 0xF));
/* 18:   */     }
/* 19:41 */     return sb.toString();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static byte[] hex2bin(String s)
/* 23:   */   {
/* 24:46 */     String m = s;
/* 25:47 */     if (s == null) {
/* 26:50 */       m = "";
/* 27:52 */     } else if (s.length() % 2 != 0) {
/* 28:55 */       m = "0" + s;
/* 29:   */     }
/* 30:57 */     byte[] r = new byte[m.length() / 2];
/* 31:58 */     int i = 0;
/* 32:58 */     for (int n = 0; i < m.length(); n++)
/* 33:   */     {
/* 34:60 */       char h = m.charAt(i++);
/* 35:61 */       char l = m.charAt(i++);
/* 36:62 */       r[n] = ((byte)(hex2bin(h) * 16 + hex2bin(l)));
/* 37:   */     }
/* 38:64 */     return r;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public static int hex2bin(char c)
/* 42:   */   {
/* 43:69 */     if ((c >= '0') && (c <= '9')) {
/* 44:71 */       return c - '0';
/* 45:   */     }
/* 46:73 */     if ((c >= 'A') && (c <= 'F')) {
/* 47:75 */       return c - 'A' + 10;
/* 48:   */     }
/* 49:77 */     if ((c >= 'a') && (c <= 'f')) {
/* 50:79 */       return c - 'a' + 10;
/* 51:   */     }
/* 52:81 */     throw new IllegalArgumentException("Input string may only contain hex digits, but found '" + c + "'");
/* 53:   */   }
/* 54:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.PBKDF2.BinTools
 * JD-Core Version:    0.7.0.1
 */