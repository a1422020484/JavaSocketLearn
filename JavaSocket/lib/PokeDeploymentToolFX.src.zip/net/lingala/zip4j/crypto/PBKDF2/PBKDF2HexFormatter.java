/*  1:   */ package net.lingala.zip4j.crypto.PBKDF2;
/*  2:   */ 
/*  3:   */ class PBKDF2HexFormatter
/*  4:   */ {
/*  5:   */   public boolean fromString(PBKDF2Parameters p, String s)
/*  6:   */   {
/*  7:28 */     if ((p == null) || (s == null)) {
/*  8:30 */       return true;
/*  9:   */     }
/* 10:33 */     String[] p123 = s.split(":");
/* 11:34 */     if ((p123 == null) || (p123.length != 3)) {
/* 12:36 */       return true;
/* 13:   */     }
/* 14:39 */     byte[] salt = BinTools.hex2bin(p123[0]);
/* 15:40 */     int iterationCount = Integer.parseInt(p123[1]);
/* 16:41 */     byte[] bDK = BinTools.hex2bin(p123[2]);
/* 17:   */     
/* 18:43 */     p.setSalt(salt);
/* 19:44 */     p.setIterationCount(iterationCount);
/* 20:45 */     p.setDerivedKey(bDK);
/* 21:46 */     return false;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String toString(PBKDF2Parameters p)
/* 25:   */   {
/* 26:53 */     String s = BinTools.bin2hex(p.getSalt()) + ":" + String.valueOf(p.getIterationCount()) + ":" + BinTools.bin2hex(p.getDerivedKey());
/* 27:54 */     return s;
/* 28:   */   }
/* 29:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.PBKDF2.PBKDF2HexFormatter
 * JD-Core Version:    0.7.0.1
 */