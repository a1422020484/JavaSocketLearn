/*   1:    */ package net.lingala.zip4j.crypto.PBKDF2;
/*   2:    */ 
/*   3:    */ public class PBKDF2Parameters
/*   4:    */ {
/*   5:    */   protected byte[] salt;
/*   6:    */   protected int iterationCount;
/*   7:    */   protected String hashAlgorithm;
/*   8:    */   protected String hashCharset;
/*   9:    */   protected byte[] derivedKey;
/*  10:    */   
/*  11:    */   public PBKDF2Parameters()
/*  12:    */   {
/*  13: 36 */     this.hashAlgorithm = null;
/*  14: 37 */     this.hashCharset = "UTF-8";
/*  15: 38 */     this.salt = null;
/*  16: 39 */     this.iterationCount = 1000;
/*  17: 40 */     this.derivedKey = null;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public PBKDF2Parameters(String hashAlgorithm, String hashCharset, byte[] salt, int iterationCount)
/*  21:    */   {
/*  22: 46 */     this.hashAlgorithm = hashAlgorithm;
/*  23: 47 */     this.hashCharset = hashCharset;
/*  24: 48 */     this.salt = salt;
/*  25: 49 */     this.iterationCount = iterationCount;
/*  26: 50 */     this.derivedKey = null;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public PBKDF2Parameters(String hashAlgorithm, String hashCharset, byte[] salt, int iterationCount, byte[] derivedKey)
/*  30:    */   {
/*  31: 56 */     this.hashAlgorithm = hashAlgorithm;
/*  32: 57 */     this.hashCharset = hashCharset;
/*  33: 58 */     this.salt = salt;
/*  34: 59 */     this.iterationCount = iterationCount;
/*  35: 60 */     this.derivedKey = derivedKey;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public int getIterationCount()
/*  39:    */   {
/*  40: 65 */     return this.iterationCount;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void setIterationCount(int iterationCount)
/*  44:    */   {
/*  45: 70 */     this.iterationCount = iterationCount;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public byte[] getSalt()
/*  49:    */   {
/*  50: 75 */     return this.salt;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void setSalt(byte[] salt)
/*  54:    */   {
/*  55: 80 */     this.salt = salt;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public byte[] getDerivedKey()
/*  59:    */   {
/*  60: 85 */     return this.derivedKey;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void setDerivedKey(byte[] derivedKey)
/*  64:    */   {
/*  65: 90 */     this.derivedKey = derivedKey;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public String getHashAlgorithm()
/*  69:    */   {
/*  70: 95 */     return this.hashAlgorithm;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void setHashAlgorithm(String hashAlgorithm)
/*  74:    */   {
/*  75:100 */     this.hashAlgorithm = hashAlgorithm;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public String getHashCharset()
/*  79:    */   {
/*  80:105 */     return this.hashCharset;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void setHashCharset(String hashCharset)
/*  84:    */   {
/*  85:110 */     this.hashCharset = hashCharset;
/*  86:    */   }
/*  87:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.PBKDF2.PBKDF2Parameters
 * JD-Core Version:    0.7.0.1
 */