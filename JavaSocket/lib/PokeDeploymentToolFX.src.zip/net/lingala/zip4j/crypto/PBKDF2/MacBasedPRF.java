/*   1:    */ package net.lingala.zip4j.crypto.PBKDF2;
/*   2:    */ 
/*   3:    */ import java.security.InvalidKeyException;
/*   4:    */ import java.security.NoSuchAlgorithmException;
/*   5:    */ import java.security.NoSuchProviderException;
/*   6:    */ import javax.crypto.Mac;
/*   7:    */ import javax.crypto.spec.SecretKeySpec;
/*   8:    */ 
/*   9:    */ public class MacBasedPRF
/*  10:    */   implements PRF
/*  11:    */ {
/*  12:    */   protected Mac mac;
/*  13:    */   protected int hLen;
/*  14:    */   protected String macAlgorithm;
/*  15:    */   
/*  16:    */   public MacBasedPRF(String macAlgorithm)
/*  17:    */   {
/*  18: 41 */     this.macAlgorithm = macAlgorithm;
/*  19:    */     try
/*  20:    */     {
/*  21: 44 */       this.mac = Mac.getInstance(macAlgorithm);
/*  22: 45 */       this.hLen = this.mac.getMacLength();
/*  23:    */     }
/*  24:    */     catch (NoSuchAlgorithmException e)
/*  25:    */     {
/*  26: 49 */       throw new RuntimeException(e);
/*  27:    */     }
/*  28:    */   }
/*  29:    */   
/*  30:    */   public MacBasedPRF(String macAlgorithm, String provider)
/*  31:    */   {
/*  32: 55 */     this.macAlgorithm = macAlgorithm;
/*  33:    */     try
/*  34:    */     {
/*  35: 58 */       this.mac = Mac.getInstance(macAlgorithm, provider);
/*  36: 59 */       this.hLen = this.mac.getMacLength();
/*  37:    */     }
/*  38:    */     catch (NoSuchAlgorithmException e)
/*  39:    */     {
/*  40: 63 */       throw new RuntimeException(e);
/*  41:    */     }
/*  42:    */     catch (NoSuchProviderException e)
/*  43:    */     {
/*  44: 67 */       throw new RuntimeException(e);
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   public byte[] doFinal(byte[] M)
/*  49:    */   {
/*  50: 73 */     byte[] r = this.mac.doFinal(M);
/*  51: 74 */     return r;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public byte[] doFinal()
/*  55:    */   {
/*  56: 78 */     byte[] r = this.mac.doFinal();
/*  57: 79 */     return r;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public int getHLen()
/*  61:    */   {
/*  62: 84 */     return this.hLen;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void init(byte[] P)
/*  66:    */   {
/*  67:    */     try
/*  68:    */     {
/*  69: 91 */       this.mac.init(new SecretKeySpec(P, this.macAlgorithm));
/*  70:    */     }
/*  71:    */     catch (InvalidKeyException e)
/*  72:    */     {
/*  73: 95 */       throw new RuntimeException(e);
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void update(byte[] U)
/*  78:    */   {
/*  79:    */     try
/*  80:    */     {
/*  81:102 */       this.mac.update(U);
/*  82:    */     }
/*  83:    */     catch (IllegalStateException e)
/*  84:    */     {
/*  85:104 */       throw new RuntimeException(e);
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void update(byte[] U, int start, int len)
/*  90:    */   {
/*  91:    */     try
/*  92:    */     {
/*  93:111 */       this.mac.update(U, start, len);
/*  94:    */     }
/*  95:    */     catch (IllegalStateException e)
/*  96:    */     {
/*  97:113 */       throw new RuntimeException(e);
/*  98:    */     }
/*  99:    */   }
/* 100:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.PBKDF2.MacBasedPRF
 * JD-Core Version:    0.7.0.1
 */