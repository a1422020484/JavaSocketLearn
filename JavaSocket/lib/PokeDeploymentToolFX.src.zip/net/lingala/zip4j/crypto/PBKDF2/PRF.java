package net.lingala.zip4j.crypto.PBKDF2;

abstract interface PRF
{
  public abstract void init(byte[] paramArrayOfByte);
  
  public abstract byte[] doFinal(byte[] paramArrayOfByte);
  
  public abstract int getHLen();
}


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.PBKDF2.PRF
 * JD-Core Version:    0.7.0.1
 */