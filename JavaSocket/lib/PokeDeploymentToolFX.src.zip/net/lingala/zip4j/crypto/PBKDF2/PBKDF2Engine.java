/*   1:    */ package net.lingala.zip4j.crypto.PBKDF2;
/*   2:    */ 
/*   3:    */ import net.lingala.zip4j.util.Raw;
/*   4:    */ 
/*   5:    */ public class PBKDF2Engine
/*   6:    */ {
/*   7:    */   protected PBKDF2Parameters parameters;
/*   8:    */   protected PRF prf;
/*   9:    */   
/*  10:    */   public PBKDF2Engine()
/*  11:    */   {
/*  12: 34 */     this.parameters = null;
/*  13: 35 */     this.prf = null;
/*  14:    */   }
/*  15:    */   
/*  16:    */   public PBKDF2Engine(PBKDF2Parameters parameters)
/*  17:    */   {
/*  18: 40 */     this.parameters = parameters;
/*  19: 41 */     this.prf = null;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public PBKDF2Engine(PBKDF2Parameters parameters, PRF prf)
/*  23:    */   {
/*  24: 46 */     this.parameters = parameters;
/*  25: 47 */     this.prf = prf;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public byte[] deriveKey(char[] inputPassword)
/*  29:    */   {
/*  30: 52 */     return deriveKey(inputPassword, 0);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public byte[] deriveKey(char[] inputPassword, int dkLen)
/*  34:    */   {
/*  35: 57 */     byte[] r = null;
/*  36: 58 */     byte[] P = null;
/*  37: 59 */     if (inputPassword == null) {
/*  38: 61 */       throw new NullPointerException();
/*  39:    */     }
/*  40: 64 */     P = Raw.convertCharArrayToByteArray(inputPassword);
/*  41:    */     
/*  42: 66 */     assertPRF(P);
/*  43: 67 */     if (dkLen == 0) {
/*  44: 69 */       dkLen = this.prf.getHLen();
/*  45:    */     }
/*  46: 71 */     r = PBKDF2(this.prf, this.parameters.getSalt(), this.parameters.getIterationCount(), dkLen);
/*  47:    */     
/*  48: 73 */     return r;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean verifyKey(char[] inputPassword)
/*  52:    */   {
/*  53: 78 */     byte[] referenceKey = getParameters().getDerivedKey();
/*  54: 79 */     if ((referenceKey == null) || (referenceKey.length == 0)) {
/*  55: 81 */       return false;
/*  56:    */     }
/*  57: 83 */     byte[] inputKey = deriveKey(inputPassword, referenceKey.length);
/*  58: 85 */     if ((inputKey == null) || (inputKey.length != referenceKey.length)) {
/*  59: 87 */       return false;
/*  60:    */     }
/*  61: 89 */     for (int i = 0; i < inputKey.length; i++) {
/*  62: 91 */       if (inputKey[i] != referenceKey[i]) {
/*  63: 93 */         return false;
/*  64:    */       }
/*  65:    */     }
/*  66: 96 */     return true;
/*  67:    */   }
/*  68:    */   
/*  69:    */   protected void assertPRF(byte[] P)
/*  70:    */   {
/*  71:101 */     if (this.prf == null) {
/*  72:103 */       this.prf = new MacBasedPRF(this.parameters.getHashAlgorithm());
/*  73:    */     }
/*  74:105 */     this.prf.init(P);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public PRF getPseudoRandomFunction()
/*  78:    */   {
/*  79:110 */     return this.prf;
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected byte[] PBKDF2(PRF prf, byte[] S, int c, int dkLen)
/*  83:    */   {
/*  84:115 */     if (S == null) {
/*  85:117 */       S = new byte[0];
/*  86:    */     }
/*  87:119 */     int hLen = prf.getHLen();
/*  88:120 */     int l = ceil(dkLen, hLen);
/*  89:121 */     int r = dkLen - (l - 1) * hLen;
/*  90:122 */     byte[] T = new byte[l * hLen];
/*  91:123 */     int ti_offset = 0;
/*  92:124 */     for (int i = 1; i <= l; i++)
/*  93:    */     {
/*  94:126 */       _F(T, ti_offset, prf, S, c, i);
/*  95:127 */       ti_offset += hLen;
/*  96:    */     }
/*  97:129 */     if (r < hLen)
/*  98:    */     {
/*  99:132 */       byte[] DK = new byte[dkLen];
/* 100:133 */       System.arraycopy(T, 0, DK, 0, dkLen);
/* 101:134 */       return DK;
/* 102:    */     }
/* 103:136 */     return T;
/* 104:    */   }
/* 105:    */   
/* 106:    */   protected int ceil(int a, int b)
/* 107:    */   {
/* 108:141 */     int m = 0;
/* 109:142 */     if (a % b > 0) {
/* 110:144 */       m = 1;
/* 111:    */     }
/* 112:146 */     return a / b + m;
/* 113:    */   }
/* 114:    */   
/* 115:    */   protected void _F(byte[] dest, int offset, PRF prf, byte[] S, int c, int blockIndex)
/* 116:    */   {
/* 117:152 */     int hLen = prf.getHLen();
/* 118:153 */     byte[] U_r = new byte[hLen];
/* 119:    */     
/* 120:    */ 
/* 121:156 */     byte[] U_i = new byte[S.length + 4];
/* 122:157 */     System.arraycopy(S, 0, U_i, 0, S.length);
/* 123:158 */     INT(U_i, S.length, blockIndex);
/* 124:160 */     for (int i = 0; i < c; i++)
/* 125:    */     {
/* 126:162 */       U_i = prf.doFinal(U_i);
/* 127:163 */       xor(U_r, U_i);
/* 128:    */     }
/* 129:165 */     System.arraycopy(U_r, 0, dest, offset, hLen);
/* 130:    */   }
/* 131:    */   
/* 132:    */   protected void xor(byte[] dest, byte[] src)
/* 133:    */   {
/* 134:170 */     for (int i = 0; i < dest.length; i++)
/* 135:    */     {
/* 136:172 */       int tmp10_9 = i; byte[] tmp10_8 = dest;tmp10_8[tmp10_9] = ((byte)(tmp10_8[tmp10_9] ^ src[i]));
/* 137:    */     }
/* 138:    */   }
/* 139:    */   
/* 140:    */   protected void INT(byte[] dest, int offset, int i)
/* 141:    */   {
/* 142:178 */     dest[(offset + 0)] = ((byte)(i / 16777216));
/* 143:179 */     dest[(offset + 1)] = ((byte)(i / 65536));
/* 144:180 */     dest[(offset + 2)] = ((byte)(i / 256));
/* 145:181 */     dest[(offset + 3)] = ((byte)i);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public PBKDF2Parameters getParameters()
/* 149:    */   {
/* 150:186 */     return this.parameters;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void setParameters(PBKDF2Parameters parameters)
/* 154:    */   {
/* 155:191 */     this.parameters = parameters;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void setPseudoRandomFunction(PRF prf)
/* 159:    */   {
/* 160:196 */     this.prf = prf;
/* 161:    */   }
/* 162:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.PBKDF2.PBKDF2Engine
 * JD-Core Version:    0.7.0.1
 */