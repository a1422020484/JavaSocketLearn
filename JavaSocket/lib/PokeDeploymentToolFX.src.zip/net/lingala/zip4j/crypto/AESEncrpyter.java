/*   1:    */ package net.lingala.zip4j.crypto;
/*   2:    */ 
/*   3:    */ import java.util.Random;
/*   4:    */ import net.lingala.zip4j.crypto.PBKDF2.MacBasedPRF;
/*   5:    */ import net.lingala.zip4j.crypto.PBKDF2.PBKDF2Engine;
/*   6:    */ import net.lingala.zip4j.crypto.PBKDF2.PBKDF2Parameters;
/*   7:    */ import net.lingala.zip4j.crypto.engine.AESEngine;
/*   8:    */ import net.lingala.zip4j.exception.ZipException;
/*   9:    */ import net.lingala.zip4j.util.Raw;
/*  10:    */ 
/*  11:    */ public class AESEncrpyter
/*  12:    */   implements IEncrypter
/*  13:    */ {
/*  14:    */   private char[] password;
/*  15:    */   private int keyStrength;
/*  16:    */   private AESEngine aesEngine;
/*  17:    */   private MacBasedPRF mac;
/*  18:    */   private int KEY_LENGTH;
/*  19:    */   private int MAC_LENGTH;
/*  20:    */   private int SALT_LENGTH;
/*  21: 40 */   private final int PASSWORD_VERIFIER_LENGTH = 2;
/*  22:    */   private byte[] aesKey;
/*  23:    */   private byte[] macKey;
/*  24:    */   private byte[] derivedPasswordVerifier;
/*  25:    */   private byte[] saltBytes;
/*  26:    */   private boolean finished;
/*  27: 49 */   private int nonce = 1;
/*  28: 50 */   private int loopCount = 0;
/*  29:    */   private byte[] iv;
/*  30:    */   private byte[] counterBlock;
/*  31:    */   
/*  32:    */   public AESEncrpyter(char[] password, int keyStrength)
/*  33:    */     throws ZipException
/*  34:    */   {
/*  35: 56 */     if ((password == null) || (password.length == 0)) {
/*  36: 57 */       throw new ZipException("input password is empty or null in AES encrypter constructor");
/*  37:    */     }
/*  38: 59 */     if ((keyStrength != 1) && (keyStrength != 3)) {
/*  39: 61 */       throw new ZipException("Invalid key strength in AES encrypter constructor");
/*  40:    */     }
/*  41: 64 */     this.password = password;
/*  42: 65 */     this.keyStrength = keyStrength;
/*  43: 66 */     this.finished = false;
/*  44: 67 */     this.counterBlock = new byte[16];
/*  45: 68 */     this.iv = new byte[16];
/*  46: 69 */     init();
/*  47:    */   }
/*  48:    */   
/*  49:    */   private void init()
/*  50:    */     throws ZipException
/*  51:    */   {
/*  52: 73 */     switch (this.keyStrength)
/*  53:    */     {
/*  54:    */     case 1: 
/*  55: 75 */       this.KEY_LENGTH = 16;
/*  56: 76 */       this.MAC_LENGTH = 16;
/*  57: 77 */       this.SALT_LENGTH = 8;
/*  58: 78 */       break;
/*  59:    */     case 3: 
/*  60: 80 */       this.KEY_LENGTH = 32;
/*  61: 81 */       this.MAC_LENGTH = 32;
/*  62: 82 */       this.SALT_LENGTH = 16;
/*  63: 83 */       break;
/*  64:    */     default: 
/*  65: 85 */       throw new ZipException("invalid aes key strength, cannot determine key sizes");
/*  66:    */     }
/*  67: 88 */     this.saltBytes = generateSalt(this.SALT_LENGTH);
/*  68: 89 */     byte[] keyBytes = deriveKey(this.saltBytes, this.password);
/*  69: 91 */     if ((keyBytes == null) || (keyBytes.length != this.KEY_LENGTH + this.MAC_LENGTH + 2)) {
/*  70: 92 */       throw new ZipException("invalid key generated, cannot decrypt file");
/*  71:    */     }
/*  72: 95 */     this.aesKey = new byte[this.KEY_LENGTH];
/*  73: 96 */     this.macKey = new byte[this.MAC_LENGTH];
/*  74: 97 */     this.derivedPasswordVerifier = new byte[2];
/*  75:    */     
/*  76: 99 */     System.arraycopy(keyBytes, 0, this.aesKey, 0, this.KEY_LENGTH);
/*  77:100 */     System.arraycopy(keyBytes, this.KEY_LENGTH, this.macKey, 0, this.MAC_LENGTH);
/*  78:101 */     System.arraycopy(keyBytes, this.KEY_LENGTH + this.MAC_LENGTH, this.derivedPasswordVerifier, 0, 2);
/*  79:    */     
/*  80:103 */     this.aesEngine = new AESEngine(this.aesKey);
/*  81:104 */     this.mac = new MacBasedPRF("HmacSHA1");
/*  82:105 */     this.mac.init(this.macKey);
/*  83:    */   }
/*  84:    */   
/*  85:    */   private byte[] deriveKey(byte[] salt, char[] password)
/*  86:    */     throws ZipException
/*  87:    */   {
/*  88:    */     try
/*  89:    */     {
/*  90:110 */       PBKDF2Parameters p = new PBKDF2Parameters("HmacSHA1", "ISO-8859-1", salt, 1000);
/*  91:    */       
/*  92:112 */       PBKDF2Engine e = new PBKDF2Engine(p);
/*  93:113 */       return e.deriveKey(password, this.KEY_LENGTH + this.MAC_LENGTH + 2);
/*  94:    */     }
/*  95:    */     catch (Exception e)
/*  96:    */     {
/*  97:116 */       throw new ZipException(e);
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public int encryptData(byte[] buff)
/* 102:    */     throws ZipException
/* 103:    */   {
/* 104:122 */     if (buff == null) {
/* 105:123 */       throw new ZipException("input bytes are null, cannot perform AES encrpytion");
/* 106:    */     }
/* 107:125 */     return encryptData(buff, 0, buff.length);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public int encryptData(byte[] buff, int start, int len)
/* 111:    */     throws ZipException
/* 112:    */   {
/* 113:130 */     if (this.finished) {
/* 114:134 */       throw new ZipException("AES Encrypter is in finished state (A non 16 byte block has already been passed to encrypter)");
/* 115:    */     }
/* 116:137 */     if (len % 16 != 0) {
/* 117:138 */       this.finished = true;
/* 118:    */     }
/* 119:141 */     for (int j = start; j < start + len; j += 16)
/* 120:    */     {
/* 121:142 */       this.loopCount = (j + 16 <= start + len ? 16 : start + len - j);
/* 122:    */       
/* 123:    */ 
/* 124:145 */       Raw.prepareBuffAESIVBytes(this.iv, this.nonce, 16);
/* 125:146 */       this.aesEngine.processBlock(this.iv, this.counterBlock);
/* 126:148 */       for (int k = 0; k < this.loopCount; k++) {
/* 127:149 */         buff[(j + k)] = ((byte)(buff[(j + k)] ^ this.counterBlock[k]));
/* 128:    */       }
/* 129:152 */       this.mac.update(buff, j, this.loopCount);
/* 130:153 */       this.nonce += 1;
/* 131:    */     }
/* 132:156 */     return len;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static byte[] generateSalt(int size)
/* 136:    */     throws ZipException
/* 137:    */   {
/* 138:161 */     if ((size != 8) && (size != 16)) {
/* 139:162 */       throw new ZipException("invalid salt size, cannot generate salt");
/* 140:    */     }
/* 141:165 */     int rounds = 0;
/* 142:167 */     if (size == 8) {
/* 143:168 */       rounds = 2;
/* 144:    */     }
/* 145:169 */     if (size == 16) {
/* 146:170 */       rounds = 4;
/* 147:    */     }
/* 148:172 */     byte[] salt = new byte[size];
/* 149:173 */     for (int j = 0; j < rounds; j++)
/* 150:    */     {
/* 151:174 */       Random rand = new Random();
/* 152:175 */       int i = rand.nextInt();
/* 153:176 */       salt[(0 + j * 4)] = ((byte)(i >> 24));
/* 154:177 */       salt[(1 + j * 4)] = ((byte)(i >> 16));
/* 155:178 */       salt[(2 + j * 4)] = ((byte)(i >> 8));
/* 156:179 */       salt[(3 + j * 4)] = ((byte)i);
/* 157:    */     }
/* 158:181 */     return salt;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public byte[] getFinalMac()
/* 162:    */   {
/* 163:185 */     byte[] rawMacBytes = this.mac.doFinal();
/* 164:186 */     byte[] macBytes = new byte[10];
/* 165:187 */     System.arraycopy(rawMacBytes, 0, macBytes, 0, 10);
/* 166:188 */     return macBytes;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public byte[] getDerivedPasswordVerifier()
/* 170:    */   {
/* 171:192 */     return this.derivedPasswordVerifier;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public void setDerivedPasswordVerifier(byte[] derivedPasswordVerifier)
/* 175:    */   {
/* 176:196 */     this.derivedPasswordVerifier = derivedPasswordVerifier;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public byte[] getSaltBytes()
/* 180:    */   {
/* 181:200 */     return this.saltBytes;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public void setSaltBytes(byte[] saltBytes)
/* 185:    */   {
/* 186:204 */     this.saltBytes = saltBytes;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public int getSaltLength()
/* 190:    */   {
/* 191:208 */     return this.SALT_LENGTH;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public int getPasswordVeriifierLength()
/* 195:    */   {
/* 196:212 */     return 2;
/* 197:    */   }
/* 198:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.crypto.AESEncrpyter
 * JD-Core Version:    0.7.0.1
 */