/*   1:    */ package net.lingala.zip4j.util;
/*   2:    */ 
/*   3:    */ import java.io.DataInput;
/*   4:    */ import java.io.IOException;
/*   5:    */ import net.lingala.zip4j.exception.ZipException;
/*   6:    */ 
/*   7:    */ public class Raw
/*   8:    */ {
/*   9:    */   public static long readLongLittleEndian(byte[] array, int pos)
/*  10:    */   {
/*  11: 27 */     long temp = 0L;
/*  12: 28 */     temp |= array[(pos + 7)] & 0xFF;
/*  13: 29 */     temp <<= 8;
/*  14: 30 */     temp |= array[(pos + 6)] & 0xFF;
/*  15: 31 */     temp <<= 8;
/*  16: 32 */     temp |= array[(pos + 5)] & 0xFF;
/*  17: 33 */     temp <<= 8;
/*  18: 34 */     temp |= array[(pos + 4)] & 0xFF;
/*  19: 35 */     temp <<= 8;
/*  20: 36 */     temp |= array[(pos + 3)] & 0xFF;
/*  21: 37 */     temp <<= 8;
/*  22: 38 */     temp |= array[(pos + 2)] & 0xFF;
/*  23: 39 */     temp <<= 8;
/*  24: 40 */     temp |= array[(pos + 1)] & 0xFF;
/*  25: 41 */     temp <<= 8;
/*  26: 42 */     temp |= array[pos] & 0xFF;
/*  27: 43 */     return temp;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static int readLeInt(DataInput di, byte[] b)
/*  31:    */     throws ZipException
/*  32:    */   {
/*  33:    */     try
/*  34:    */     {
/*  35: 48 */       di.readFully(b, 0, 4);
/*  36:    */     }
/*  37:    */     catch (IOException e)
/*  38:    */     {
/*  39: 50 */       throw new ZipException(e);
/*  40:    */     }
/*  41: 52 */     return b[0] & 0xFF | (b[1] & 0xFF) << 8 | (b[2] & 0xFF | (b[3] & 0xFF) << 8) << 16;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static int readShortLittleEndian(byte[] b, int off)
/*  45:    */   {
/*  46: 57 */     return b[off] & 0xFF | (b[(off + 1)] & 0xFF) << 8;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static final short readShortBigEndian(byte[] array, int pos)
/*  50:    */   {
/*  51: 61 */     short temp = 0;
/*  52: 62 */     temp = (short)(temp | array[pos] & 0xFF);
/*  53: 63 */     temp = (short)(temp << 8);
/*  54: 64 */     temp = (short)(temp | array[(pos + 1)] & 0xFF);
/*  55: 65 */     return temp;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public static int readIntLittleEndian(byte[] b, int off)
/*  59:    */   {
/*  60: 69 */     return b[off] & 0xFF | (b[(off + 1)] & 0xFF) << 8 | (b[(off + 2)] & 0xFF | (b[(off + 3)] & 0xFF) << 8) << 16;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static byte[] toByteArray(int in, int outSize)
/*  64:    */   {
/*  65: 74 */     byte[] out = new byte[outSize];
/*  66: 75 */     byte[] intArray = toByteArray(in);
/*  67: 76 */     for (int i = 0; (i < intArray.length) && (i < outSize); i++) {
/*  68: 77 */       out[i] = intArray[i];
/*  69:    */     }
/*  70: 79 */     return out;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static byte[] toByteArray(int in)
/*  74:    */   {
/*  75: 83 */     byte[] out = new byte[4];
/*  76:    */     
/*  77: 85 */     out[0] = ((byte)in);
/*  78: 86 */     out[1] = ((byte)(in >> 8));
/*  79: 87 */     out[2] = ((byte)(in >> 16));
/*  80: 88 */     out[3] = ((byte)(in >> 24));
/*  81:    */     
/*  82: 90 */     return out;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static final void writeShortLittleEndian(byte[] array, int pos, short value)
/*  86:    */   {
/*  87: 95 */     array[(pos + 1)] = ((byte)(value >>> 8));
/*  88: 96 */     array[pos] = ((byte)(value & 0xFF));
/*  89:    */   }
/*  90:    */   
/*  91:    */   public static final void writeIntLittleEndian(byte[] array, int pos, int value)
/*  92:    */   {
/*  93:101 */     array[(pos + 3)] = ((byte)(value >>> 24));
/*  94:102 */     array[(pos + 2)] = ((byte)(value >>> 16));
/*  95:103 */     array[(pos + 1)] = ((byte)(value >>> 8));
/*  96:104 */     array[pos] = ((byte)(value & 0xFF));
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static void writeLongLittleEndian(byte[] array, int pos, long value)
/* 100:    */   {
/* 101:109 */     array[(pos + 7)] = ((byte)(int)(value >>> 56));
/* 102:110 */     array[(pos + 6)] = ((byte)(int)(value >>> 48));
/* 103:111 */     array[(pos + 5)] = ((byte)(int)(value >>> 40));
/* 104:112 */     array[(pos + 4)] = ((byte)(int)(value >>> 32));
/* 105:113 */     array[(pos + 3)] = ((byte)(int)(value >>> 24));
/* 106:114 */     array[(pos + 2)] = ((byte)(int)(value >>> 16));
/* 107:115 */     array[(pos + 1)] = ((byte)(int)(value >>> 8));
/* 108:116 */     array[pos] = ((byte)(int)(value & 0xFF));
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static byte bitArrayToByte(int[] bitArray)
/* 112:    */     throws ZipException
/* 113:    */   {
/* 114:120 */     if (bitArray == null) {
/* 115:121 */       throw new ZipException("bit array is null, cannot calculate byte from bits");
/* 116:    */     }
/* 117:124 */     if (bitArray.length != 8) {
/* 118:125 */       throw new ZipException("invalid bit array length, cannot calculate byte");
/* 119:    */     }
/* 120:128 */     if (!checkBits(bitArray)) {
/* 121:129 */       throw new ZipException("invalid bits provided, bits contain other values than 0 or 1");
/* 122:    */     }
/* 123:132 */     int retNum = 0;
/* 124:133 */     for (int i = 0; i < bitArray.length; i++) {
/* 125:134 */       retNum = (int)(retNum + Math.pow(2.0D, i) * bitArray[i]);
/* 126:    */     }
/* 127:137 */     return (byte)retNum;
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static boolean checkBits(int[] bitArray)
/* 131:    */   {
/* 132:141 */     for (int i = 0; i < bitArray.length; i++) {
/* 133:142 */       if ((bitArray[i] != 0) && (bitArray[i] != 1)) {
/* 134:143 */         return false;
/* 135:    */       }
/* 136:    */     }
/* 137:146 */     return true;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static void prepareBuffAESIVBytes(byte[] buff, int nonce, int length)
/* 141:    */   {
/* 142:150 */     buff[0] = ((byte)nonce);
/* 143:151 */     buff[1] = ((byte)(nonce >> 8));
/* 144:152 */     buff[2] = ((byte)(nonce >> 16));
/* 145:153 */     buff[3] = ((byte)(nonce >> 24));
/* 146:154 */     buff[4] = 0;
/* 147:155 */     buff[5] = 0;
/* 148:156 */     buff[6] = 0;
/* 149:157 */     buff[7] = 0;
/* 150:158 */     buff[8] = 0;
/* 151:159 */     buff[9] = 0;
/* 152:160 */     buff[10] = 0;
/* 153:161 */     buff[11] = 0;
/* 154:162 */     buff[12] = 0;
/* 155:163 */     buff[13] = 0;
/* 156:164 */     buff[14] = 0;
/* 157:165 */     buff[15] = 0;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static byte[] convertCharArrayToByteArray(char[] charArray)
/* 161:    */   {
/* 162:174 */     if (charArray == null) {
/* 163:175 */       throw new NullPointerException();
/* 164:    */     }
/* 165:178 */     byte[] bytes = new byte[charArray.length];
/* 166:179 */     for (int i = 0; i < charArray.length; i++) {
/* 167:180 */       bytes[i] = ((byte)charArray[i]);
/* 168:    */     }
/* 169:182 */     return bytes;
/* 170:    */   }
/* 171:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.util.Raw
 * JD-Core Version:    0.7.0.1
 */