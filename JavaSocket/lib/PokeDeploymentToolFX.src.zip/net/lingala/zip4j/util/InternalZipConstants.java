/*   1:    */ package net.lingala.zip4j.util;
/*   2:    */ 
/*   3:    */ public abstract interface InternalZipConstants
/*   4:    */ {
/*   5:    */   public static final long LOCSIG = 67324752L;
/*   6:    */   public static final long EXTSIG = 134695760L;
/*   7:    */   public static final long CENSIG = 33639248L;
/*   8:    */   public static final long ENDSIG = 101010256L;
/*   9:    */   public static final long DIGSIG = 84233040L;
/*  10:    */   public static final long ARCEXTDATREC = 134630224L;
/*  11:    */   public static final long SPLITSIG = 134695760L;
/*  12:    */   public static final long ZIP64ENDCENDIRLOC = 117853008L;
/*  13:    */   public static final long ZIP64ENDCENDIRREC = 101075792L;
/*  14:    */   public static final int EXTRAFIELDZIP64LENGTH = 1;
/*  15:    */   public static final int AESSIG = 39169;
/*  16:    */   public static final int LOCHDR = 30;
/*  17:    */   public static final int EXTHDR = 16;
/*  18:    */   public static final int CENHDR = 46;
/*  19:    */   public static final int ENDHDR = 22;
/*  20:    */   public static final int LOCVER = 4;
/*  21:    */   public static final int LOCFLG = 6;
/*  22:    */   public static final int LOCHOW = 8;
/*  23:    */   public static final int LOCTIM = 10;
/*  24:    */   public static final int LOCCRC = 14;
/*  25:    */   public static final int LOCSIZ = 18;
/*  26:    */   public static final int LOCLEN = 22;
/*  27:    */   public static final int LOCNAM = 26;
/*  28:    */   public static final int LOCEXT = 28;
/*  29:    */   public static final int EXTCRC = 4;
/*  30:    */   public static final int EXTSIZ = 8;
/*  31:    */   public static final int EXTLEN = 12;
/*  32:    */   public static final int CENVEM = 4;
/*  33:    */   public static final int CENVER = 6;
/*  34:    */   public static final int CENFLG = 8;
/*  35:    */   public static final int CENHOW = 10;
/*  36:    */   public static final int CENTIM = 12;
/*  37:    */   public static final int CENCRC = 16;
/*  38:    */   public static final int CENSIZ = 20;
/*  39:    */   public static final int CENLEN = 24;
/*  40:    */   public static final int CENNAM = 28;
/*  41:    */   public static final int CENEXT = 30;
/*  42:    */   public static final int CENCOM = 32;
/*  43:    */   public static final int CENDSK = 34;
/*  44:    */   public static final int CENATT = 36;
/*  45:    */   public static final int CENATX = 38;
/*  46:    */   public static final int CENOFF = 42;
/*  47:    */   public static final int ENDSUB = 8;
/*  48:    */   public static final int ENDTOT = 10;
/*  49:    */   public static final int ENDSIZ = 12;
/*  50:    */   public static final int ENDOFF = 16;
/*  51:    */   public static final int ENDCOM = 20;
/*  52:    */   public static final int STD_DEC_HDR_SIZE = 12;
/*  53:    */   public static final int AES_AUTH_LENGTH = 10;
/*  54:    */   public static final int AES_BLOCK_SIZE = 16;
/*  55:    */   public static final int MIN_SPLIT_LENGTH = 65536;
/*  56:    */   public static final long ZIP_64_LIMIT = 4294967295L;
/*  57:    */   public static final String OFFSET_CENTRAL_DIR = "offsetCentralDir";
/*  58:    */   public static final String VERSION = "1.3.2";
/*  59:    */   public static final int MODE_ZIP = 1;
/*  60:    */   public static final int MODE_UNZIP = 2;
/*  61:    */   public static final String WRITE_MODE = "rw";
/*  62:    */   public static final String READ_MODE = "r";
/*  63:    */   public static final int BUFF_SIZE = 4096;
/*  64:    */   public static final int FILE_MODE_NONE = 0;
/*  65:    */   public static final int FILE_MODE_READ_ONLY = 1;
/*  66:    */   public static final int FILE_MODE_HIDDEN = 2;
/*  67:    */   public static final int FILE_MODE_ARCHIVE = 32;
/*  68:    */   public static final int FILE_MODE_READ_ONLY_HIDDEN = 3;
/*  69:    */   public static final int FILE_MODE_READ_ONLY_ARCHIVE = 33;
/*  70:    */   public static final int FILE_MODE_HIDDEN_ARCHIVE = 34;
/*  71:    */   public static final int FILE_MODE_READ_ONLY_HIDDEN_ARCHIVE = 35;
/*  72:    */   public static final int FILE_MODE_SYSTEM = 38;
/*  73:    */   public static final int FOLDER_MODE_NONE = 16;
/*  74:    */   public static final int FOLDER_MODE_HIDDEN = 18;
/*  75:    */   public static final int FOLDER_MODE_ARCHIVE = 48;
/*  76:    */   public static final int FOLDER_MODE_HIDDEN_ARCHIVE = 50;
/*  77:    */   public static final int UPDATE_LFH_CRC = 14;
/*  78:    */   public static final int UPDATE_LFH_COMP_SIZE = 18;
/*  79:    */   public static final int UPDATE_LFH_UNCOMP_SIZE = 22;
/*  80:    */   public static final int LIST_TYPE_FILE = 1;
/*  81:    */   public static final int LIST_TYPE_STRING = 2;
/*  82:    */   public static final int UFT8_NAMES_FLAG = 2048;
/*  83:    */   public static final String CHARSET_UTF8 = "UTF8";
/*  84:    */   public static final String CHARSET_CP850 = "Cp850";
/*  85:    */   public static final String CHARSET_COMMENTS_DEFAULT = "windows-1254";
/*  86:165 */   public static final String CHARSET_DEFAULT = System.getProperty("file.encoding");
/*  87:167 */   public static final String FILE_SEPARATOR = System.getProperty("file.separator");
/*  88:    */   public static final String ZIP_FILE_SEPARATOR = "/";
/*  89:    */   public static final String THREAD_NAME = "Zip4j";
/*  90:    */   public static final int MAX_ALLOWED_ZIP_COMMENT_LENGTH = 65535;
/*  91:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.util.InternalZipConstants
 * JD-Core Version:    0.7.0.1
 */