/*   1:    */ package net.lingala.zip4j.util;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.UnsupportedEncodingException;
/*   5:    */ import java.nio.ByteBuffer;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.Calendar;
/*   9:    */ import java.util.Date;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.TimeZone;
/*  12:    */ import net.lingala.zip4j.exception.ZipException;
/*  13:    */ import net.lingala.zip4j.model.CentralDirectory;
/*  14:    */ import net.lingala.zip4j.model.EndCentralDirRecord;
/*  15:    */ import net.lingala.zip4j.model.FileHeader;
/*  16:    */ import net.lingala.zip4j.model.ZipModel;
/*  17:    */ 
/*  18:    */ public class Zip4jUtil
/*  19:    */ {
/*  20:    */   public static boolean isStringNotNullAndNotEmpty(String str)
/*  21:    */   {
/*  22: 31 */     if ((str == null) || (str.trim().length() <= 0)) {
/*  23: 32 */       return false;
/*  24:    */     }
/*  25: 35 */     return true;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static boolean checkOutputFolder(String path)
/*  29:    */     throws ZipException
/*  30:    */   {
/*  31: 39 */     if (!isStringNotNullAndNotEmpty(path)) {
/*  32: 40 */       throw new ZipException(new NullPointerException("output path is null"));
/*  33:    */     }
/*  34: 43 */     File file = new File(path);
/*  35: 45 */     if (file.exists())
/*  36:    */     {
/*  37: 47 */       if (!file.isDirectory()) {
/*  38: 48 */         throw new ZipException("output folder is not valid");
/*  39:    */       }
/*  40: 51 */       if (!file.canWrite()) {
/*  41: 52 */         throw new ZipException("no write access to output folder");
/*  42:    */       }
/*  43:    */     }
/*  44:    */     else
/*  45:    */     {
/*  46:    */       try
/*  47:    */       {
/*  48: 56 */         file.mkdirs();
/*  49: 57 */         if (!file.isDirectory()) {
/*  50: 58 */           throw new ZipException("output folder is not valid");
/*  51:    */         }
/*  52: 61 */         if (!file.canWrite()) {
/*  53: 62 */           throw new ZipException("no write access to destination folder");
/*  54:    */         }
/*  55:    */       }
/*  56:    */       catch (Exception e)
/*  57:    */       {
/*  58: 73 */         throw new ZipException("Cannot create destination folder");
/*  59:    */       }
/*  60:    */     }
/*  61: 77 */     return true;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static boolean checkFileReadAccess(String path)
/*  65:    */     throws ZipException
/*  66:    */   {
/*  67: 81 */     if (!isStringNotNullAndNotEmpty(path)) {
/*  68: 82 */       throw new ZipException("path is null");
/*  69:    */     }
/*  70: 85 */     if (!checkFileExists(path)) {
/*  71: 86 */       throw new ZipException("file does not exist: " + path);
/*  72:    */     }
/*  73:    */     try
/*  74:    */     {
/*  75: 90 */       File file = new File(path);
/*  76: 91 */       return file.canRead();
/*  77:    */     }
/*  78:    */     catch (Exception e)
/*  79:    */     {
/*  80: 93 */       throw new ZipException("cannot read zip file");
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static boolean checkFileWriteAccess(String path)
/*  85:    */     throws ZipException
/*  86:    */   {
/*  87: 98 */     if (!isStringNotNullAndNotEmpty(path)) {
/*  88: 99 */       throw new ZipException("path is null");
/*  89:    */     }
/*  90:102 */     if (!checkFileExists(path)) {
/*  91:103 */       throw new ZipException("file does not exist: " + path);
/*  92:    */     }
/*  93:    */     try
/*  94:    */     {
/*  95:107 */       File file = new File(path);
/*  96:108 */       return file.canWrite();
/*  97:    */     }
/*  98:    */     catch (Exception e)
/*  99:    */     {
/* 100:110 */       throw new ZipException("cannot read zip file");
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static boolean checkFileExists(String path)
/* 105:    */     throws ZipException
/* 106:    */   {
/* 107:115 */     if (!isStringNotNullAndNotEmpty(path)) {
/* 108:116 */       throw new ZipException("path is null");
/* 109:    */     }
/* 110:119 */     File file = new File(path);
/* 111:120 */     return checkFileExists(file);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public static boolean checkFileExists(File file)
/* 115:    */     throws ZipException
/* 116:    */   {
/* 117:124 */     if (file == null) {
/* 118:125 */       throw new ZipException("cannot check if file exists: input file is null");
/* 119:    */     }
/* 120:127 */     return file.exists();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public static boolean isWindows()
/* 124:    */   {
/* 125:131 */     String os = System.getProperty("os.name").toLowerCase();
/* 126:132 */     return os.indexOf("win") >= 0;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public static void setFileReadOnly(File file)
/* 130:    */     throws ZipException
/* 131:    */   {
/* 132:136 */     if (file == null) {
/* 133:137 */       throw new ZipException("input file is null. cannot set read only file attribute");
/* 134:    */     }
/* 135:140 */     if (file.exists()) {
/* 136:141 */       file.setReadOnly();
/* 137:    */     }
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static void setFileHidden(File file)
/* 141:    */     throws ZipException
/* 142:    */   {}
/* 143:    */   
/* 144:    */   public static void setFileArchive(File file)
/* 145:    */     throws ZipException
/* 146:    */   {}
/* 147:    */   
/* 148:    */   public static void setFileSystemMode(File file)
/* 149:    */     throws ZipException
/* 150:    */   {}
/* 151:    */   
/* 152:    */   public static long getLastModifiedFileTime(File file, TimeZone timeZone)
/* 153:    */     throws ZipException
/* 154:    */   {
/* 155:208 */     if (file == null) {
/* 156:209 */       throw new ZipException("input file is null, cannot read last modified file time");
/* 157:    */     }
/* 158:212 */     if (!file.exists()) {
/* 159:213 */       throw new ZipException("input file does not exist, cannot read last modified file time");
/* 160:    */     }
/* 161:216 */     return file.lastModified();
/* 162:    */   }
/* 163:    */   
/* 164:    */   public static String getFileNameFromFilePath(File file)
/* 165:    */     throws ZipException
/* 166:    */   {
/* 167:220 */     if (file == null) {
/* 168:221 */       throw new ZipException("input file is null, cannot get file name");
/* 169:    */     }
/* 170:224 */     if (file.isDirectory()) {
/* 171:225 */       return null;
/* 172:    */     }
/* 173:228 */     return file.getName();
/* 174:    */   }
/* 175:    */   
/* 176:    */   public static long getFileLengh(String file)
/* 177:    */     throws ZipException
/* 178:    */   {
/* 179:232 */     if (!isStringNotNullAndNotEmpty(file)) {
/* 180:233 */       throw new ZipException("invalid file name");
/* 181:    */     }
/* 182:236 */     return getFileLengh(new File(file));
/* 183:    */   }
/* 184:    */   
/* 185:    */   public static long getFileLengh(File file)
/* 186:    */     throws ZipException
/* 187:    */   {
/* 188:240 */     if (file == null) {
/* 189:241 */       throw new ZipException("input file is null, cannot calculate file length");
/* 190:    */     }
/* 191:244 */     if (file.isDirectory()) {
/* 192:245 */       return -1L;
/* 193:    */     }
/* 194:248 */     return file.length();
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static long javaToDosTime(long time)
/* 198:    */   {
/* 199:258 */     Calendar cal = Calendar.getInstance();
/* 200:259 */     cal.setTimeInMillis(time);
/* 201:    */     
/* 202:261 */     int year = cal.get(1);
/* 203:262 */     if (year < 1980) {
/* 204:263 */       return 2162688L;
/* 205:    */     }
/* 206:267 */     return year - 1980 << 25 | cal.get(2) + 1 << 21 | cal.get(5) << 16 | cal.get(11) << 11 | cal.get(12) << 5 | cal.get(13) >> 1;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public static long dosToJavaTme(int dosTime)
/* 210:    */   {
/* 211:276 */     int sec = 2 * (dosTime & 0x1F);
/* 212:277 */     int min = dosTime >> 5 & 0x3F;
/* 213:278 */     int hrs = dosTime >> 11 & 0x1F;
/* 214:279 */     int day = dosTime >> 16 & 0x1F;
/* 215:280 */     int mon = (dosTime >> 21 & 0xF) - 1;
/* 216:281 */     int year = (dosTime >> 25 & 0x7F) + 1980;
/* 217:    */     
/* 218:283 */     Calendar cal = Calendar.getInstance();
/* 219:284 */     cal.set(year, mon, day, hrs, min, sec);
/* 220:285 */     cal.set(14, 0);
/* 221:286 */     return cal.getTime().getTime();
/* 222:    */   }
/* 223:    */   
/* 224:    */   public static FileHeader getFileHeader(ZipModel zipModel, String fileName)
/* 225:    */     throws ZipException
/* 226:    */   {
/* 227:290 */     if (zipModel == null) {
/* 228:291 */       throw new ZipException("zip model is null, cannot determine file header for fileName: " + fileName);
/* 229:    */     }
/* 230:294 */     if (!isStringNotNullAndNotEmpty(fileName)) {
/* 231:295 */       throw new ZipException("file name is null, cannot determine file header for fileName: " + fileName);
/* 232:    */     }
/* 233:298 */     FileHeader fileHeader = null;
/* 234:299 */     fileHeader = getFileHeaderWithExactMatch(zipModel, fileName);
/* 235:301 */     if (fileHeader == null)
/* 236:    */     {
/* 237:302 */       fileName = fileName.replaceAll("\\\\", "/");
/* 238:303 */       fileHeader = getFileHeaderWithExactMatch(zipModel, fileName);
/* 239:305 */       if (fileHeader == null)
/* 240:    */       {
/* 241:306 */         fileName = fileName.replaceAll("/", "\\\\");
/* 242:307 */         fileHeader = getFileHeaderWithExactMatch(zipModel, fileName);
/* 243:    */       }
/* 244:    */     }
/* 245:311 */     return fileHeader;
/* 246:    */   }
/* 247:    */   
/* 248:    */   public static FileHeader getFileHeaderWithExactMatch(ZipModel zipModel, String fileName)
/* 249:    */     throws ZipException
/* 250:    */   {
/* 251:315 */     if (zipModel == null) {
/* 252:316 */       throw new ZipException("zip model is null, cannot determine file header with exact match for fileName: " + fileName);
/* 253:    */     }
/* 254:319 */     if (!isStringNotNullAndNotEmpty(fileName)) {
/* 255:320 */       throw new ZipException("file name is null, cannot determine file header with exact match for fileName: " + fileName);
/* 256:    */     }
/* 257:323 */     if (zipModel.getCentralDirectory() == null) {
/* 258:324 */       throw new ZipException("central directory is null, cannot determine file header with exact match for fileName: " + fileName);
/* 259:    */     }
/* 260:327 */     if (zipModel.getCentralDirectory().getFileHeaders() == null) {
/* 261:328 */       throw new ZipException("file Headers are null, cannot determine file header with exact match for fileName: " + fileName);
/* 262:    */     }
/* 263:331 */     if (zipModel.getCentralDirectory().getFileHeaders().size() <= 0) {
/* 264:332 */       return null;
/* 265:    */     }
/* 266:334 */     ArrayList fileHeaders = zipModel.getCentralDirectory().getFileHeaders();
/* 267:335 */     for (int i = 0; i < fileHeaders.size(); i++)
/* 268:    */     {
/* 269:336 */       FileHeader fileHeader = (FileHeader)fileHeaders.get(i);
/* 270:337 */       String fileNameForHdr = fileHeader.getFileName();
/* 271:338 */       if (isStringNotNullAndNotEmpty(fileNameForHdr)) {
/* 272:342 */         if (fileName.equalsIgnoreCase(fileNameForHdr)) {
/* 273:343 */           return fileHeader;
/* 274:    */         }
/* 275:    */       }
/* 276:    */     }
/* 277:347 */     return null;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public static int getIndexOfFileHeader(ZipModel zipModel, FileHeader fileHeader)
/* 281:    */     throws ZipException
/* 282:    */   {
/* 283:353 */     if ((zipModel == null) || (fileHeader == null)) {
/* 284:354 */       throw new ZipException("input parameters is null, cannot determine index of file header");
/* 285:    */     }
/* 286:357 */     if (zipModel.getCentralDirectory() == null) {
/* 287:358 */       throw new ZipException("central directory is null, ccannot determine index of file header");
/* 288:    */     }
/* 289:361 */     if (zipModel.getCentralDirectory().getFileHeaders() == null) {
/* 290:362 */       throw new ZipException("file Headers are null, cannot determine index of file header");
/* 291:    */     }
/* 292:365 */     if (zipModel.getCentralDirectory().getFileHeaders().size() <= 0) {
/* 293:366 */       return -1;
/* 294:    */     }
/* 295:368 */     String fileName = fileHeader.getFileName();
/* 296:370 */     if (!isStringNotNullAndNotEmpty(fileName)) {
/* 297:371 */       throw new ZipException("file name in file header is empty or null, cannot determine index of file header");
/* 298:    */     }
/* 299:374 */     ArrayList fileHeaders = zipModel.getCentralDirectory().getFileHeaders();
/* 300:375 */     for (int i = 0; i < fileHeaders.size(); i++)
/* 301:    */     {
/* 302:376 */       FileHeader fileHeaderTmp = (FileHeader)fileHeaders.get(i);
/* 303:377 */       String fileNameForHdr = fileHeaderTmp.getFileName();
/* 304:378 */       if (isStringNotNullAndNotEmpty(fileNameForHdr)) {
/* 305:382 */         if (fileName.equalsIgnoreCase(fileNameForHdr)) {
/* 306:383 */           return i;
/* 307:    */         }
/* 308:    */       }
/* 309:    */     }
/* 310:386 */     return -1;
/* 311:    */   }
/* 312:    */   
/* 313:    */   public static ArrayList getFilesInDirectoryRec(File path, boolean readHiddenFiles)
/* 314:    */     throws ZipException
/* 315:    */   {
/* 316:392 */     if (path == null) {
/* 317:393 */       throw new ZipException("input path is null, cannot read files in the directory");
/* 318:    */     }
/* 319:396 */     ArrayList result = new ArrayList();
/* 320:397 */     File[] filesAndDirs = path.listFiles();
/* 321:398 */     List filesDirs = Arrays.asList(filesAndDirs);
/* 322:400 */     if (!path.canRead()) {
/* 323:401 */       return result;
/* 324:    */     }
/* 325:404 */     for (int i = 0; i < filesDirs.size(); i++)
/* 326:    */     {
/* 327:405 */       File file = (File)filesDirs.get(i);
/* 328:406 */       if ((!file.isHidden()) || (readHiddenFiles))
/* 329:    */       {
/* 330:410 */         result.add(file);
/* 331:411 */         if (file.isDirectory())
/* 332:    */         {
/* 333:412 */           List deeperList = getFilesInDirectoryRec(file, readHiddenFiles);
/* 334:413 */           result.addAll(deeperList);
/* 335:    */         }
/* 336:    */       }
/* 337:    */     }
/* 338:416 */     return result;
/* 339:    */   }
/* 340:    */   
/* 341:    */   public static String getZipFileNameWithoutExt(String zipFile)
/* 342:    */     throws ZipException
/* 343:    */   {
/* 344:420 */     if (!isStringNotNullAndNotEmpty(zipFile)) {
/* 345:421 */       throw new ZipException("zip file name is empty or null, cannot determine zip file name");
/* 346:    */     }
/* 347:423 */     String tmpFileName = zipFile;
/* 348:424 */     if (zipFile.indexOf(System.getProperty("file.separator")) >= 0) {
/* 349:425 */       tmpFileName = zipFile.substring(zipFile.lastIndexOf(System.getProperty("file.separator")));
/* 350:    */     }
/* 351:428 */     if (tmpFileName.indexOf(".") > 0) {
/* 352:429 */       tmpFileName = tmpFileName.substring(0, tmpFileName.lastIndexOf("."));
/* 353:    */     }
/* 354:431 */     return tmpFileName;
/* 355:    */   }
/* 356:    */   
/* 357:    */   public static byte[] convertCharset(String str)
/* 358:    */     throws ZipException
/* 359:    */   {
/* 360:    */     try
/* 361:    */     {
/* 362:436 */       byte[] converted = null;
/* 363:437 */       String charSet = detectCharSet(str);
/* 364:438 */       if (charSet.equals("Cp850")) {
/* 365:439 */         converted = str.getBytes("Cp850");
/* 366:440 */       } else if (charSet.equals("UTF8")) {
/* 367:441 */         converted = str.getBytes("UTF8");
/* 368:    */       }
/* 369:443 */       return str.getBytes();
/* 370:    */     }
/* 371:    */     catch (UnsupportedEncodingException err)
/* 372:    */     {
/* 373:448 */       return str.getBytes();
/* 374:    */     }
/* 375:    */     catch (Exception e)
/* 376:    */     {
/* 377:450 */       throw new ZipException(e);
/* 378:    */     }
/* 379:    */   }
/* 380:    */   
/* 381:    */   public static String decodeFileName(byte[] data, boolean isUTF8)
/* 382:    */   {
/* 383:464 */     if (isUTF8) {
/* 384:    */       try
/* 385:    */       {
/* 386:466 */         return new String(data, "UTF8");
/* 387:    */       }
/* 388:    */       catch (UnsupportedEncodingException e)
/* 389:    */       {
/* 390:468 */         return new String(data);
/* 391:    */       }
/* 392:    */     }
/* 393:471 */     return getCp850EncodedString(data);
/* 394:    */   }
/* 395:    */   
/* 396:    */   public static String getCp850EncodedString(byte[] data)
/* 397:    */   {
/* 398:    */     try
/* 399:    */     {
/* 400:483 */       return new String(data, "Cp850");
/* 401:    */     }
/* 402:    */     catch (UnsupportedEncodingException e) {}
/* 403:486 */     return new String(data);
/* 404:    */   }
/* 405:    */   
/* 406:    */   public static String getAbsoluteFilePath(String filePath)
/* 407:    */     throws ZipException
/* 408:    */   {
/* 409:496 */     if (!isStringNotNullAndNotEmpty(filePath)) {
/* 410:497 */       throw new ZipException("filePath is null or empty, cannot get absolute file path");
/* 411:    */     }
/* 412:500 */     File file = new File(filePath);
/* 413:501 */     return file.getAbsolutePath();
/* 414:    */   }
/* 415:    */   
/* 416:    */   public static boolean checkArrayListTypes(ArrayList sourceList, int type)
/* 417:    */     throws ZipException
/* 418:    */   {
/* 419:512 */     if (sourceList == null) {
/* 420:513 */       throw new ZipException("input arraylist is null, cannot check types");
/* 421:    */     }
/* 422:516 */     if (sourceList.size() <= 0) {
/* 423:517 */       return true;
/* 424:    */     }
/* 425:520 */     boolean invalidFound = false;
/* 426:522 */     switch (type)
/* 427:    */     {
/* 428:    */     case 1: 
/* 429:524 */       for (int i = 0; i < sourceList.size(); i++) {
/* 430:525 */         if (!(sourceList.get(i) instanceof File))
/* 431:    */         {
/* 432:526 */           invalidFound = true;
/* 433:527 */           break;
/* 434:    */         }
/* 435:    */       }
/* 436:530 */       break;
/* 437:    */     case 2: 
/* 438:532 */       for (int i = 0; i < sourceList.size(); i++) {
/* 439:533 */         if (!(sourceList.get(i) instanceof String))
/* 440:    */         {
/* 441:534 */           invalidFound = true;
/* 442:535 */           break;
/* 443:    */         }
/* 444:    */       }
/* 445:538 */       break;
/* 446:    */     }
/* 447:542 */     return !invalidFound;
/* 448:    */   }
/* 449:    */   
/* 450:    */   public static String detectCharSet(String str)
/* 451:    */     throws ZipException
/* 452:    */   {
/* 453:553 */     if (str == null) {
/* 454:554 */       throw new ZipException("input string is null, cannot detect charset");
/* 455:    */     }
/* 456:    */     try
/* 457:    */     {
/* 458:558 */       byte[] byteString = str.getBytes("Cp850");
/* 459:559 */       String tempString = new String(byteString, "Cp850");
/* 460:561 */       if (str.equals(tempString)) {
/* 461:562 */         return "Cp850";
/* 462:    */       }
/* 463:565 */       byteString = str.getBytes("UTF8");
/* 464:566 */       tempString = new String(byteString, "UTF8");
/* 465:568 */       if (str.equals(tempString)) {
/* 466:569 */         return "UTF8";
/* 467:    */       }
/* 468:572 */       return InternalZipConstants.CHARSET_DEFAULT;
/* 469:    */     }
/* 470:    */     catch (UnsupportedEncodingException e)
/* 471:    */     {
/* 472:574 */       return InternalZipConstants.CHARSET_DEFAULT;
/* 473:    */     }
/* 474:    */     catch (Exception e) {}
/* 475:576 */     return InternalZipConstants.CHARSET_DEFAULT;
/* 476:    */   }
/* 477:    */   
/* 478:    */   public static int getEncodedStringLength(String str)
/* 479:    */     throws ZipException
/* 480:    */   {
/* 481:589 */     if (!isStringNotNullAndNotEmpty(str)) {
/* 482:590 */       throw new ZipException("input string is null, cannot calculate encoded String length");
/* 483:    */     }
/* 484:593 */     String charset = detectCharSet(str);
/* 485:594 */     return getEncodedStringLength(str, charset);
/* 486:    */   }
/* 487:    */   
/* 488:    */   public static int getEncodedStringLength(String str, String charset)
/* 489:    */     throws ZipException
/* 490:    */   {
/* 491:605 */     if (!isStringNotNullAndNotEmpty(str)) {
/* 492:606 */       throw new ZipException("input string is null, cannot calculate encoded String length");
/* 493:    */     }
/* 494:609 */     if (!isStringNotNullAndNotEmpty(charset)) {
/* 495:610 */       throw new ZipException("encoding is not defined, cannot calculate string length");
/* 496:    */     }
/* 497:613 */     ByteBuffer byteBuffer = null;
/* 498:    */     try
/* 499:    */     {
/* 500:616 */       if (charset.equals("Cp850")) {
/* 501:617 */         byteBuffer = ByteBuffer.wrap(str.getBytes("Cp850"));
/* 502:618 */       } else if (charset.equals("UTF8")) {
/* 503:619 */         byteBuffer = ByteBuffer.wrap(str.getBytes("UTF8"));
/* 504:    */       } else {
/* 505:621 */         byteBuffer = ByteBuffer.wrap(str.getBytes(charset));
/* 506:    */       }
/* 507:    */     }
/* 508:    */     catch (UnsupportedEncodingException e)
/* 509:    */     {
/* 510:624 */       byteBuffer = ByteBuffer.wrap(str.getBytes());
/* 511:    */     }
/* 512:    */     catch (Exception e)
/* 513:    */     {
/* 514:626 */       throw new ZipException(e);
/* 515:    */     }
/* 516:629 */     return byteBuffer.limit();
/* 517:    */   }
/* 518:    */   
/* 519:    */   public static boolean isSupportedCharset(String charset)
/* 520:    */     throws ZipException
/* 521:    */   {
/* 522:639 */     if (!isStringNotNullAndNotEmpty(charset)) {
/* 523:640 */       throw new ZipException("charset is null or empty, cannot check if it is supported");
/* 524:    */     }
/* 525:    */     try
/* 526:    */     {
/* 527:644 */       new String("a".getBytes(), charset);
/* 528:645 */       return true;
/* 529:    */     }
/* 530:    */     catch (UnsupportedEncodingException e)
/* 531:    */     {
/* 532:647 */       return false;
/* 533:    */     }
/* 534:    */     catch (Exception e)
/* 535:    */     {
/* 536:649 */       throw new ZipException(e);
/* 537:    */     }
/* 538:    */   }
/* 539:    */   
/* 540:    */   public static ArrayList getSplitZipFiles(ZipModel zipModel)
/* 541:    */     throws ZipException
/* 542:    */   {
/* 543:654 */     if (zipModel == null) {
/* 544:655 */       throw new ZipException("cannot get split zip files: zipmodel is null");
/* 545:    */     }
/* 546:658 */     if (zipModel.getEndCentralDirRecord() == null) {
/* 547:659 */       return null;
/* 548:    */     }
/* 549:662 */     ArrayList retList = new ArrayList();
/* 550:663 */     String currZipFile = zipModel.getZipFile();
/* 551:664 */     String zipFileName = new File(currZipFile).getName();
/* 552:665 */     String partFile = null;
/* 553:667 */     if (!isStringNotNullAndNotEmpty(currZipFile)) {
/* 554:668 */       throw new ZipException("cannot get split zip files: zipfile is null");
/* 555:    */     }
/* 556:671 */     if (!zipModel.isSplitArchive())
/* 557:    */     {
/* 558:672 */       retList.add(currZipFile);
/* 559:673 */       return retList;
/* 560:    */     }
/* 561:676 */     int numberOfThisDisk = zipModel.getEndCentralDirRecord().getNoOfThisDisk();
/* 562:678 */     if (numberOfThisDisk == 0)
/* 563:    */     {
/* 564:679 */       retList.add(currZipFile);
/* 565:680 */       return retList;
/* 566:    */     }
/* 567:682 */     for (int i = 0; i <= numberOfThisDisk; i++) {
/* 568:683 */       if (i == numberOfThisDisk)
/* 569:    */       {
/* 570:684 */         retList.add(zipModel.getZipFile());
/* 571:    */       }
/* 572:    */       else
/* 573:    */       {
/* 574:686 */         String fileExt = ".z0";
/* 575:687 */         if (i > 9) {
/* 576:688 */           fileExt = ".z";
/* 577:    */         }
/* 578:690 */         partFile = zipFileName.indexOf(".") >= 0 ? currZipFile.substring(0, currZipFile.lastIndexOf(".")) : currZipFile;
/* 579:691 */         partFile = partFile + fileExt + (i + 1);
/* 580:692 */         retList.add(partFile);
/* 581:    */       }
/* 582:    */     }
/* 583:696 */     return retList;
/* 584:    */   }
/* 585:    */   
/* 586:    */   public static String getRelativeFileName(String file, String rootFolderInZip, String rootFolderPath)
/* 587:    */     throws ZipException
/* 588:    */   {
/* 589:700 */     if (!isStringNotNullAndNotEmpty(file)) {
/* 590:701 */       throw new ZipException("input file path/name is empty, cannot calculate relative file name");
/* 591:    */     }
/* 592:704 */     String fileName = null;
/* 593:706 */     if (isStringNotNullAndNotEmpty(rootFolderPath))
/* 594:    */     {
/* 595:708 */       File rootFolderFile = new File(rootFolderPath);
/* 596:    */       
/* 597:710 */       String rootFolderFileRef = rootFolderFile.getPath();
/* 598:712 */       if (!rootFolderFileRef.endsWith(InternalZipConstants.FILE_SEPARATOR)) {
/* 599:713 */         rootFolderFileRef = rootFolderFileRef + InternalZipConstants.FILE_SEPARATOR;
/* 600:    */       }
/* 601:716 */       String tmpFileName = file.substring(rootFolderFileRef.length());
/* 602:717 */       if (tmpFileName.startsWith(System.getProperty("file.separator"))) {
/* 603:718 */         tmpFileName = tmpFileName.substring(1);
/* 604:    */       }
/* 605:721 */       File tmpFile = new File(file);
/* 606:723 */       if (tmpFile.isDirectory())
/* 607:    */       {
/* 608:724 */         tmpFileName = tmpFileName.replaceAll("\\\\", "/");
/* 609:725 */         tmpFileName = tmpFileName + "/";
/* 610:    */       }
/* 611:    */       else
/* 612:    */       {
/* 613:727 */         String bkFileName = tmpFileName.substring(0, tmpFileName.lastIndexOf(tmpFile.getName()));
/* 614:728 */         bkFileName = bkFileName.replaceAll("\\\\", "/");
/* 615:729 */         tmpFileName = bkFileName + tmpFile.getName();
/* 616:    */       }
/* 617:732 */       fileName = tmpFileName;
/* 618:    */     }
/* 619:    */     else
/* 620:    */     {
/* 621:734 */       File relFile = new File(file);
/* 622:735 */       if (relFile.isDirectory()) {
/* 623:736 */         fileName = relFile.getName() + "/";
/* 624:    */       } else {
/* 625:738 */         fileName = getFileNameFromFilePath(new File(file));
/* 626:    */       }
/* 627:    */     }
/* 628:742 */     if (isStringNotNullAndNotEmpty(rootFolderInZip)) {
/* 629:743 */       fileName = rootFolderInZip + fileName;
/* 630:    */     }
/* 631:746 */     if (!isStringNotNullAndNotEmpty(fileName)) {
/* 632:747 */       throw new ZipException("Error determining file name");
/* 633:    */     }
/* 634:750 */     return fileName;
/* 635:    */   }
/* 636:    */   
/* 637:    */   public static long[] getAllHeaderSignatures()
/* 638:    */   {
/* 639:754 */     long[] allSigs = new long[11];
/* 640:    */     
/* 641:756 */     allSigs[0] = 67324752L;
/* 642:757 */     allSigs[1] = 134695760L;
/* 643:758 */     allSigs[2] = 33639248L;
/* 644:759 */     allSigs[3] = 101010256L;
/* 645:760 */     allSigs[4] = 84233040L;
/* 646:761 */     allSigs[5] = 134630224L;
/* 647:762 */     allSigs[6] = 134695760L;
/* 648:763 */     allSigs[7] = 117853008L;
/* 649:764 */     allSigs[8] = 101075792L;
/* 650:765 */     allSigs[9] = 1L;
/* 651:766 */     allSigs[10] = 39169L;
/* 652:    */     
/* 653:768 */     return allSigs;
/* 654:    */   }
/* 655:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.util.Zip4jUtil
 * JD-Core Version:    0.7.0.1
 */