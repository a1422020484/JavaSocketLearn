/*   1:    */ package net.lingala.zip4j.util;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileNotFoundException;
/*   5:    */ import java.io.FileOutputStream;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.OutputStream;
/*   8:    */ import java.io.RandomAccessFile;
/*   9:    */ import java.io.UnsupportedEncodingException;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import net.lingala.zip4j.core.HeaderReader;
/*  13:    */ import net.lingala.zip4j.core.HeaderWriter;
/*  14:    */ import net.lingala.zip4j.exception.ZipException;
/*  15:    */ import net.lingala.zip4j.io.SplitOutputStream;
/*  16:    */ import net.lingala.zip4j.model.CentralDirectory;
/*  17:    */ import net.lingala.zip4j.model.EndCentralDirRecord;
/*  18:    */ import net.lingala.zip4j.model.FileHeader;
/*  19:    */ import net.lingala.zip4j.model.LocalFileHeader;
/*  20:    */ import net.lingala.zip4j.model.Zip64EndCentralDirLocator;
/*  21:    */ import net.lingala.zip4j.model.Zip64EndCentralDirRecord;
/*  22:    */ import net.lingala.zip4j.model.Zip64ExtendedInfo;
/*  23:    */ import net.lingala.zip4j.model.ZipModel;
/*  24:    */ import net.lingala.zip4j.progress.ProgressMonitor;
/*  25:    */ 
/*  26:    */ public class ArchiveMaintainer
/*  27:    */ {
/*  28:    */   public HashMap removeZipFile(final ZipModel zipModel, final FileHeader fileHeader, final ProgressMonitor progressMonitor, boolean runInThread)
/*  29:    */     throws ZipException
/*  30:    */   {
/*  31: 48 */     if (runInThread)
/*  32:    */     {
/*  33: 49 */       Thread thread = new Thread("Zip4j")
/*  34:    */       {
/*  35:    */         public void run()
/*  36:    */         {
/*  37:    */           try
/*  38:    */           {
/*  39: 52 */             ArchiveMaintainer.this.initRemoveZipFile(zipModel, fileHeader, progressMonitor);
/*  40: 53 */             progressMonitor.endProgressMonitorSuccess();
/*  41:    */           }
/*  42:    */           catch (ZipException localZipException) {}
/*  43:    */         }
/*  44: 57 */       };
/*  45: 58 */       thread.start();
/*  46: 59 */       return null;
/*  47:    */     }
/*  48: 61 */     HashMap retMap = initRemoveZipFile(zipModel, fileHeader, progressMonitor);
/*  49: 62 */     progressMonitor.endProgressMonitorSuccess();
/*  50: 63 */     return retMap;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public HashMap initRemoveZipFile(ZipModel zipModel, FileHeader fileHeader, ProgressMonitor progressMonitor)
/*  54:    */     throws ZipException
/*  55:    */   {
/*  56: 71 */     if ((fileHeader == null) || (zipModel == null)) {
/*  57: 72 */       throw new ZipException("input parameters is null in maintain zip file, cannot remove file from archive");
/*  58:    */     }
/*  59: 75 */     OutputStream outputStream = null;
/*  60: 76 */     File zipFile = null;
/*  61: 77 */     RandomAccessFile inputStream = null;
/*  62: 78 */     boolean successFlag = false;
/*  63: 79 */     String tmpZipFileName = null;
/*  64: 80 */     HashMap retMap = new HashMap();
/*  65:    */     try
/*  66:    */     {
/*  67: 83 */       int indexOfFileHeader = Zip4jUtil.getIndexOfFileHeader(zipModel, fileHeader);
/*  68: 85 */       if (indexOfFileHeader < 0) {
/*  69: 86 */         throw new ZipException("file header not found in zip model, cannot remove file");
/*  70:    */       }
/*  71: 89 */       if (zipModel.isSplitArchive()) {
/*  72: 90 */         throw new ZipException("This is a split archive. Zip file format does not allow updating split/spanned files");
/*  73:    */       }
/*  74: 93 */       long currTime = System.currentTimeMillis();
/*  75: 94 */       tmpZipFileName = zipModel.getZipFile() + currTime % 1000L;
/*  76: 95 */       File tmpFile = new File(tmpZipFileName);
/*  77: 97 */       while (tmpFile.exists())
/*  78:    */       {
/*  79: 98 */         currTime = System.currentTimeMillis();
/*  80: 99 */         tmpZipFileName = zipModel.getZipFile() + currTime % 1000L;
/*  81:100 */         tmpFile = new File(tmpZipFileName);
/*  82:    */       }
/*  83:    */       try
/*  84:    */       {
/*  85:104 */         outputStream = new SplitOutputStream(new File(tmpZipFileName));
/*  86:    */       }
/*  87:    */       catch (FileNotFoundException e1)
/*  88:    */       {
/*  89:106 */         throw new ZipException(e1);
/*  90:    */       }
/*  91:109 */       zipFile = new File(zipModel.getZipFile());
/*  92:    */       
/*  93:111 */       inputStream = createFileHandler(zipModel, "r");
/*  94:    */       
/*  95:113 */       HeaderReader headerReader = new HeaderReader(inputStream);
/*  96:114 */       LocalFileHeader localFileHeader = headerReader.readLocalFileHeader(fileHeader);
/*  97:115 */       if (localFileHeader == null) {
/*  98:116 */         throw new ZipException("invalid local file header, cannot remove file from archive");
/*  99:    */       }
/* 100:119 */       long offsetLocalFileHeader = fileHeader.getOffsetLocalHeader();
/* 101:121 */       if ((fileHeader.getZip64ExtendedInfo() != null) && 
/* 102:122 */         (fileHeader.getZip64ExtendedInfo().getOffsetLocalHeader() != -1L)) {
/* 103:123 */         offsetLocalFileHeader = fileHeader.getZip64ExtendedInfo().getOffsetLocalHeader();
/* 104:    */       }
/* 105:126 */       long offsetEndOfCompressedFile = -1L;
/* 106:    */       
/* 107:128 */       long offsetStartCentralDir = zipModel.getEndCentralDirRecord().getOffsetOfStartOfCentralDir();
/* 108:129 */       if ((zipModel.isZip64Format()) && 
/* 109:130 */         (zipModel.getZip64EndCentralDirRecord() != null)) {
/* 110:131 */         offsetStartCentralDir = zipModel.getZip64EndCentralDirRecord().getOffsetStartCenDirWRTStartDiskNo();
/* 111:    */       }
/* 112:135 */       ArrayList fileHeaderList = zipModel.getCentralDirectory().getFileHeaders();
/* 113:    */       FileHeader nextFileHeader;
/* 114:137 */       if (indexOfFileHeader == fileHeaderList.size() - 1)
/* 115:    */       {
/* 116:138 */         offsetEndOfCompressedFile = offsetStartCentralDir - 1L;
/* 117:    */       }
/* 118:    */       else
/* 119:    */       {
/* 120:140 */         nextFileHeader = (FileHeader)fileHeaderList.get(indexOfFileHeader + 1);
/* 121:141 */         if (nextFileHeader != null)
/* 122:    */         {
/* 123:142 */           offsetEndOfCompressedFile = nextFileHeader.getOffsetLocalHeader() - 1L;
/* 124:143 */           if ((nextFileHeader.getZip64ExtendedInfo() != null) && 
/* 125:144 */             (nextFileHeader.getZip64ExtendedInfo().getOffsetLocalHeader() != -1L)) {
/* 126:145 */             offsetEndOfCompressedFile = nextFileHeader.getZip64ExtendedInfo().getOffsetLocalHeader() - 1L;
/* 127:    */           }
/* 128:    */         }
/* 129:    */       }
/* 130:150 */       if ((offsetLocalFileHeader < 0L) || (offsetEndOfCompressedFile < 0L)) {
/* 131:151 */         throw new ZipException("invalid offset for start and end of local file, cannot remove file");
/* 132:    */       }
/* 133:154 */       if (indexOfFileHeader == 0)
/* 134:    */       {
/* 135:155 */         if (zipModel.getCentralDirectory().getFileHeaders().size() > 1) {
/* 136:157 */           copyFile(inputStream, outputStream, offsetEndOfCompressedFile + 1L, offsetStartCentralDir, progressMonitor);
/* 137:    */         }
/* 138:    */       }
/* 139:159 */       else if (indexOfFileHeader == fileHeaderList.size() - 1)
/* 140:    */       {
/* 141:160 */         copyFile(inputStream, outputStream, 0L, offsetLocalFileHeader, progressMonitor);
/* 142:    */       }
/* 143:    */       else
/* 144:    */       {
/* 145:162 */         copyFile(inputStream, outputStream, 0L, offsetLocalFileHeader, progressMonitor);
/* 146:163 */         copyFile(inputStream, outputStream, offsetEndOfCompressedFile + 1L, offsetStartCentralDir, progressMonitor);
/* 147:    */       }
/* 148:166 */       if (progressMonitor.isCancelAllTasks())
/* 149:    */       {
/* 150:167 */         progressMonitor.setResult(3);
/* 151:168 */         progressMonitor.setState(0);
/* 152:    */         File newZipFile;
/* 153:169 */         return null;
/* 154:    */       }
/* 155:172 */       zipModel.getEndCentralDirRecord().setOffsetOfStartOfCentralDir(((SplitOutputStream)outputStream).getFilePointer());
/* 156:173 */       zipModel.getEndCentralDirRecord().setTotNoOfEntriesInCentralDir(zipModel
/* 157:174 */         .getEndCentralDirRecord().getTotNoOfEntriesInCentralDir() - 1);
/* 158:175 */       zipModel.getEndCentralDirRecord().setTotNoOfEntriesInCentralDirOnThisDisk(zipModel
/* 159:176 */         .getEndCentralDirRecord().getTotNoOfEntriesInCentralDirOnThisDisk() - 1);
/* 160:    */       
/* 161:178 */       zipModel.getCentralDirectory().getFileHeaders().remove(indexOfFileHeader);
/* 162:180 */       for (int i = indexOfFileHeader; i < zipModel.getCentralDirectory().getFileHeaders().size(); i++)
/* 163:    */       {
/* 164:181 */         long offsetLocalHdr = ((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(i)).getOffsetLocalHeader();
/* 165:182 */         if ((((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(i)).getZip64ExtendedInfo() != null) && 
/* 166:183 */           (((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(i)).getZip64ExtendedInfo().getOffsetLocalHeader() != -1L)) {
/* 167:184 */           offsetLocalHdr = ((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(i)).getZip64ExtendedInfo().getOffsetLocalHeader();
/* 168:    */         }
/* 169:187 */         ((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(i)).setOffsetLocalHeader(offsetLocalHdr - (offsetEndOfCompressedFile - offsetLocalFileHeader) - 1L);
/* 170:    */       }
/* 171:191 */       HeaderWriter headerWriter = new HeaderWriter();
/* 172:192 */       headerWriter.finalizeZipFile(zipModel, outputStream);
/* 173:    */       
/* 174:194 */       successFlag = true;
/* 175:    */       
/* 176:196 */       retMap.put("offsetCentralDir", 
/* 177:197 */         Long.toString(zipModel.getEndCentralDirRecord().getOffsetOfStartOfCentralDir()));
/* 178:    */     }
/* 179:    */     catch (ZipException e)
/* 180:    */     {
/* 181:    */       File newZipFile;
/* 182:200 */       progressMonitor.endProgressMonitorError(e);
/* 183:201 */       throw e;
/* 184:    */     }
/* 185:    */     catch (Exception e)
/* 186:    */     {
/* 187:203 */       progressMonitor.endProgressMonitorError(e);
/* 188:204 */       throw new ZipException(e);
/* 189:    */     }
/* 190:    */     finally
/* 191:    */     {
/* 192:    */       try
/* 193:    */       {
/* 194:207 */         if (inputStream != null) {
/* 195:208 */           inputStream.close();
/* 196:    */         }
/* 197:209 */         if (outputStream != null) {
/* 198:210 */           outputStream.close();
/* 199:    */         }
/* 200:    */       }
/* 201:    */       catch (IOException e)
/* 202:    */       {
/* 203:212 */         throw new ZipException("cannot close input stream or output stream when trying to delete a file from zip file");
/* 204:    */       }
/* 205:215 */       if (successFlag)
/* 206:    */       {
/* 207:216 */         restoreFileName(zipFile, tmpZipFileName);
/* 208:    */       }
/* 209:    */       else
/* 210:    */       {
/* 211:218 */         File newZipFile = new File(tmpZipFileName);
/* 212:219 */         newZipFile.delete();
/* 213:    */       }
/* 214:    */     }
/* 215:223 */     return retMap;
/* 216:    */   }
/* 217:    */   
/* 218:    */   private void restoreFileName(File zipFile, String tmpZipFileName)
/* 219:    */     throws ZipException
/* 220:    */   {
/* 221:227 */     if (zipFile.delete())
/* 222:    */     {
/* 223:229 */       File newZipFile = new File(tmpZipFileName);
/* 224:230 */       if (!newZipFile.renameTo(zipFile)) {
/* 225:231 */         throw new ZipException("cannot rename modified zip file");
/* 226:    */       }
/* 227:    */     }
/* 228:    */     else
/* 229:    */     {
/* 230:234 */       throw new ZipException("cannot delete old zip file");
/* 231:    */     }
/* 232:    */   }
/* 233:    */   
/* 234:    */   private void copyFile(RandomAccessFile inputStream, OutputStream outputStream, long start, long end, ProgressMonitor progressMonitor)
/* 235:    */     throws ZipException
/* 236:    */   {
/* 237:241 */     if ((inputStream == null) || (outputStream == null)) {
/* 238:242 */       throw new ZipException("input or output stream is null, cannot copy file");
/* 239:    */     }
/* 240:245 */     if (start < 0L) {
/* 241:246 */       throw new ZipException("starting offset is negative, cannot copy file");
/* 242:    */     }
/* 243:249 */     if (end < 0L) {
/* 244:250 */       throw new ZipException("end offset is negative, cannot copy file");
/* 245:    */     }
/* 246:253 */     if (start > end) {
/* 247:254 */       throw new ZipException("start offset is greater than end offset, cannot copy file");
/* 248:    */     }
/* 249:257 */     if (start == end) {
/* 250:258 */       return;
/* 251:    */     }
/* 252:261 */     if (progressMonitor.isCancelAllTasks())
/* 253:    */     {
/* 254:262 */       progressMonitor.setResult(3);
/* 255:263 */       progressMonitor.setState(0);
/* 256:264 */       return;
/* 257:    */     }
/* 258:    */     try
/* 259:    */     {
/* 260:268 */       inputStream.seek(start);
/* 261:    */       
/* 262:270 */       int readLen = -2;
/* 263:    */       
/* 264:272 */       long bytesRead = 0L;
/* 265:273 */       long bytesToRead = end - start;
/* 266:    */       byte[] buff;
/* 267:    */       byte[] buff;
/* 268:275 */       if (end - start < 4096L) {
/* 269:276 */         buff = new byte[(int)(end - start)];
/* 270:    */       } else {
/* 271:278 */         buff = new byte[4096];
/* 272:    */       }
/* 273:281 */       while ((readLen = inputStream.read(buff)) != -1)
/* 274:    */       {
/* 275:282 */         outputStream.write(buff, 0, readLen);
/* 276:    */         
/* 277:284 */         progressMonitor.updateWorkCompleted(readLen);
/* 278:285 */         if (progressMonitor.isCancelAllTasks())
/* 279:    */         {
/* 280:286 */           progressMonitor.setResult(3);
/* 281:287 */           return;
/* 282:    */         }
/* 283:290 */         bytesRead += readLen;
/* 284:292 */         if (bytesRead == bytesToRead) {
/* 285:    */           break;
/* 286:    */         }
/* 287:294 */         if (bytesRead + buff.length > bytesToRead) {
/* 288:295 */           buff = new byte[(int)(bytesToRead - bytesRead)];
/* 289:    */         }
/* 290:    */       }
/* 291:    */     }
/* 292:    */     catch (IOException e)
/* 293:    */     {
/* 294:300 */       throw new ZipException(e);
/* 295:    */     }
/* 296:    */     catch (Exception e)
/* 297:    */     {
/* 298:302 */       throw new ZipException(e);
/* 299:    */     }
/* 300:    */   }
/* 301:    */   
/* 302:    */   private RandomAccessFile createFileHandler(ZipModel zipModel, String mode)
/* 303:    */     throws ZipException
/* 304:    */   {
/* 305:307 */     if ((zipModel == null) || (!Zip4jUtil.isStringNotNullAndNotEmpty(zipModel.getZipFile()))) {
/* 306:308 */       throw new ZipException("input parameter is null in getFilePointer, cannot create file handler to remove file");
/* 307:    */     }
/* 308:    */     try
/* 309:    */     {
/* 310:312 */       return new RandomAccessFile(new File(zipModel.getZipFile()), mode);
/* 311:    */     }
/* 312:    */     catch (FileNotFoundException e)
/* 313:    */     {
/* 314:314 */       throw new ZipException(e);
/* 315:    */     }
/* 316:    */   }
/* 317:    */   
/* 318:    */   public void mergeSplitZipFiles(final ZipModel zipModel, final File outputZipFile, final ProgressMonitor progressMonitor, boolean runInThread)
/* 319:    */     throws ZipException
/* 320:    */   {
/* 321:325 */     if (runInThread)
/* 322:    */     {
/* 323:326 */       Thread thread = new Thread("Zip4j")
/* 324:    */       {
/* 325:    */         public void run()
/* 326:    */         {
/* 327:    */           try
/* 328:    */           {
/* 329:329 */             ArchiveMaintainer.this.initMergeSplitZipFile(zipModel, outputZipFile, progressMonitor);
/* 330:    */           }
/* 331:    */           catch (ZipException localZipException) {}
/* 332:    */         }
/* 333:333 */       };
/* 334:334 */       thread.start();
/* 335:    */     }
/* 336:    */     else
/* 337:    */     {
/* 338:336 */       initMergeSplitZipFile(zipModel, outputZipFile, progressMonitor);
/* 339:    */     }
/* 340:    */   }
/* 341:    */   
/* 342:    */   private void initMergeSplitZipFile(ZipModel zipModel, File outputZipFile, ProgressMonitor progressMonitor)
/* 343:    */     throws ZipException
/* 344:    */   {
/* 345:342 */     if (zipModel == null)
/* 346:    */     {
/* 347:343 */       ZipException e = new ZipException("one of the input parameters is null, cannot merge split zip file");
/* 348:344 */       progressMonitor.endProgressMonitorError(e);
/* 349:345 */       throw e;
/* 350:    */     }
/* 351:348 */     if (!zipModel.isSplitArchive())
/* 352:    */     {
/* 353:349 */       ZipException e = new ZipException("archive not a split zip file");
/* 354:350 */       progressMonitor.endProgressMonitorError(e);
/* 355:351 */       throw e;
/* 356:    */     }
/* 357:354 */     OutputStream outputStream = null;
/* 358:355 */     RandomAccessFile inputStream = null;
/* 359:356 */     ArrayList fileSizeList = new ArrayList();
/* 360:357 */     long totBytesWritten = 0L;
/* 361:358 */     boolean splitSigRemoved = false;
/* 362:    */     try
/* 363:    */     {
/* 364:361 */       int totNoOfSplitFiles = zipModel.getEndCentralDirRecord().getNoOfThisDisk();
/* 365:363 */       if (totNoOfSplitFiles <= 0) {
/* 366:364 */         throw new ZipException("corrupt zip model, archive not a split zip file");
/* 367:    */       }
/* 368:367 */       outputStream = prepareOutputStreamForMerge(outputZipFile);
/* 369:368 */       for (int i = 0; i <= totNoOfSplitFiles; i++)
/* 370:    */       {
/* 371:369 */         inputStream = createSplitZipFileHandler(zipModel, i);
/* 372:    */         
/* 373:371 */         int start = 0;
/* 374:372 */         Long end = new Long(inputStream.length());
/* 375:374 */         if ((i == 0) && 
/* 376:375 */           (zipModel.getCentralDirectory() != null) && 
/* 377:376 */           (zipModel.getCentralDirectory().getFileHeaders() != null) && 
/* 378:377 */           (zipModel.getCentralDirectory().getFileHeaders().size() > 0))
/* 379:    */         {
/* 380:378 */           byte[] buff = new byte[4];
/* 381:379 */           inputStream.seek(0L);
/* 382:380 */           inputStream.read(buff);
/* 383:381 */           if (Raw.readIntLittleEndian(buff, 0) == 134695760L)
/* 384:    */           {
/* 385:382 */             start = 4;
/* 386:383 */             splitSigRemoved = true;
/* 387:    */           }
/* 388:    */         }
/* 389:388 */         if (i == totNoOfSplitFiles) {
/* 390:389 */           end = new Long(zipModel.getEndCentralDirRecord().getOffsetOfStartOfCentralDir());
/* 391:    */         }
/* 392:392 */         copyFile(inputStream, outputStream, start, end.longValue(), progressMonitor);
/* 393:393 */         totBytesWritten += end.longValue() - start;
/* 394:394 */         if (progressMonitor.isCancelAllTasks())
/* 395:    */         {
/* 396:395 */           progressMonitor.setResult(3);
/* 397:396 */           progressMonitor.setState(0);
/* 398:397 */           return;
/* 399:    */         }
/* 400:400 */         fileSizeList.add(end);
/* 401:    */         try
/* 402:    */         {
/* 403:403 */           inputStream.close();
/* 404:    */         }
/* 405:    */         catch (IOException localIOException3) {}
/* 406:    */       }
/* 407:409 */       ZipModel newZipModel = (ZipModel)zipModel.clone();
/* 408:410 */       newZipModel.getEndCentralDirRecord().setOffsetOfStartOfCentralDir(totBytesWritten);
/* 409:    */       
/* 410:412 */       updateSplitZipModel(newZipModel, fileSizeList, splitSigRemoved);
/* 411:    */       
/* 412:414 */       HeaderWriter headerWriter = new HeaderWriter();
/* 413:415 */       headerWriter.finalizeZipFileWithoutValidations(newZipModel, outputStream);
/* 414:    */       
/* 415:417 */       progressMonitor.endProgressMonitorSuccess(); return;
/* 416:    */     }
/* 417:    */     catch (IOException e)
/* 418:    */     {
/* 419:420 */       progressMonitor.endProgressMonitorError(e);
/* 420:421 */       throw new ZipException(e);
/* 421:    */     }
/* 422:    */     catch (Exception e)
/* 423:    */     {
/* 424:423 */       progressMonitor.endProgressMonitorError(e);
/* 425:424 */       throw new ZipException(e);
/* 426:    */     }
/* 427:    */     finally
/* 428:    */     {
/* 429:426 */       if (outputStream != null) {
/* 430:    */         try
/* 431:    */         {
/* 432:428 */           outputStream.close();
/* 433:    */         }
/* 434:    */         catch (IOException localIOException6) {}
/* 435:    */       }
/* 436:434 */       if (inputStream != null) {
/* 437:    */         try
/* 438:    */         {
/* 439:436 */           inputStream.close();
/* 440:    */         }
/* 441:    */         catch (IOException localIOException7) {}
/* 442:    */       }
/* 443:    */     }
/* 444:    */   }
/* 445:    */   
/* 446:    */   private RandomAccessFile createSplitZipFileHandler(ZipModel zipModel, int partNumber)
/* 447:    */     throws ZipException
/* 448:    */   {
/* 449:451 */     if (zipModel == null) {
/* 450:452 */       throw new ZipException("zip model is null, cannot create split file handler");
/* 451:    */     }
/* 452:455 */     if (partNumber < 0) {
/* 453:456 */       throw new ZipException("invlaid part number, cannot create split file handler");
/* 454:    */     }
/* 455:    */     try
/* 456:    */     {
/* 457:460 */       String curZipFile = zipModel.getZipFile();
/* 458:461 */       String partFile = null;
/* 459:462 */       if (partNumber == zipModel.getEndCentralDirRecord().getNoOfThisDisk()) {
/* 460:463 */         partFile = zipModel.getZipFile();
/* 461:465 */       } else if (partNumber >= 9) {
/* 462:466 */         partFile = curZipFile.substring(0, curZipFile.lastIndexOf(".")) + ".z" + (partNumber + 1);
/* 463:    */       } else {
/* 464:468 */         partFile = curZipFile.substring(0, curZipFile.lastIndexOf(".")) + ".z0" + (partNumber + 1);
/* 465:    */       }
/* 466:471 */       File tmpFile = new File(partFile);
/* 467:473 */       if (!Zip4jUtil.checkFileExists(tmpFile)) {
/* 468:474 */         throw new ZipException("split file does not exist: " + partFile);
/* 469:    */       }
/* 470:477 */       return new RandomAccessFile(tmpFile, "r");
/* 471:    */     }
/* 472:    */     catch (FileNotFoundException e)
/* 473:    */     {
/* 474:479 */       throw new ZipException(e);
/* 475:    */     }
/* 476:    */     catch (Exception e)
/* 477:    */     {
/* 478:481 */       throw new ZipException(e);
/* 479:    */     }
/* 480:    */   }
/* 481:    */   
/* 482:    */   private OutputStream prepareOutputStreamForMerge(File outFile)
/* 483:    */     throws ZipException
/* 484:    */   {
/* 485:487 */     if (outFile == null) {
/* 486:488 */       throw new ZipException("outFile is null, cannot create outputstream");
/* 487:    */     }
/* 488:    */     try
/* 489:    */     {
/* 490:492 */       return new FileOutputStream(outFile);
/* 491:    */     }
/* 492:    */     catch (FileNotFoundException e)
/* 493:    */     {
/* 494:494 */       throw new ZipException(e);
/* 495:    */     }
/* 496:    */     catch (Exception e)
/* 497:    */     {
/* 498:496 */       throw new ZipException(e);
/* 499:    */     }
/* 500:    */   }
/* 501:    */   
/* 502:    */   private void updateSplitZipModel(ZipModel zipModel, ArrayList fileSizeList, boolean splitSigRemoved)
/* 503:    */     throws ZipException
/* 504:    */   {
/* 505:501 */     if (zipModel == null) {
/* 506:502 */       throw new ZipException("zip model is null, cannot update split zip model");
/* 507:    */     }
/* 508:505 */     zipModel.setSplitArchive(false);
/* 509:506 */     updateSplitFileHeader(zipModel, fileSizeList, splitSigRemoved);
/* 510:507 */     updateSplitEndCentralDirectory(zipModel);
/* 511:508 */     if (zipModel.isZip64Format())
/* 512:    */     {
/* 513:509 */       updateSplitZip64EndCentralDirLocator(zipModel, fileSizeList);
/* 514:510 */       updateSplitZip64EndCentralDirRec(zipModel, fileSizeList);
/* 515:    */     }
/* 516:    */   }
/* 517:    */   
/* 518:    */   private void updateSplitFileHeader(ZipModel zipModel, ArrayList fileSizeList, boolean splitSigRemoved)
/* 519:    */     throws ZipException
/* 520:    */   {
/* 521:    */     try
/* 522:    */     {
/* 523:517 */       if (zipModel.getCentralDirectory() == null) {
/* 524:518 */         throw new ZipException("corrupt zip model - getCentralDirectory, cannot update split zip model");
/* 525:    */       }
/* 526:521 */       int fileHeaderCount = zipModel.getCentralDirectory().getFileHeaders().size();
/* 527:522 */       int splitSigOverhead = 0;
/* 528:523 */       if (splitSigRemoved) {
/* 529:524 */         splitSigOverhead = 4;
/* 530:    */       }
/* 531:526 */       for (int i = 0; i < fileHeaderCount; i++)
/* 532:    */       {
/* 533:527 */         long offsetLHToAdd = 0L;
/* 534:529 */         for (int j = 0; j < ((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(i)).getDiskNumberStart(); j++) {
/* 535:530 */           offsetLHToAdd += ((Long)fileSizeList.get(j)).longValue();
/* 536:    */         }
/* 537:532 */         ((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(i)).setOffsetLocalHeader(
/* 538:533 */           ((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(i)).getOffsetLocalHeader() + offsetLHToAdd - splitSigOverhead);
/* 539:    */         
/* 540:535 */         ((FileHeader)zipModel.getCentralDirectory().getFileHeaders().get(i)).setDiskNumberStart(0);
/* 541:    */       }
/* 542:    */     }
/* 543:    */     catch (ZipException e)
/* 544:    */     {
/* 545:539 */       throw e;
/* 546:    */     }
/* 547:    */     catch (Exception e)
/* 548:    */     {
/* 549:541 */       throw new ZipException(e);
/* 550:    */     }
/* 551:    */   }
/* 552:    */   
/* 553:    */   private void updateSplitEndCentralDirectory(ZipModel zipModel)
/* 554:    */     throws ZipException
/* 555:    */   {
/* 556:    */     try
/* 557:    */     {
/* 558:547 */       if (zipModel == null) {
/* 559:548 */         throw new ZipException("zip model is null - cannot update end of central directory for split zip model");
/* 560:    */       }
/* 561:551 */       if (zipModel.getCentralDirectory() == null) {
/* 562:552 */         throw new ZipException("corrupt zip model - getCentralDirectory, cannot update split zip model");
/* 563:    */       }
/* 564:555 */       zipModel.getEndCentralDirRecord().setNoOfThisDisk(0);
/* 565:556 */       zipModel.getEndCentralDirRecord().setNoOfThisDiskStartOfCentralDir(0);
/* 566:557 */       zipModel.getEndCentralDirRecord().setTotNoOfEntriesInCentralDir(zipModel
/* 567:558 */         .getCentralDirectory().getFileHeaders().size());
/* 568:559 */       zipModel.getEndCentralDirRecord().setTotNoOfEntriesInCentralDirOnThisDisk(zipModel
/* 569:560 */         .getCentralDirectory().getFileHeaders().size());
/* 570:    */     }
/* 571:    */     catch (ZipException e)
/* 572:    */     {
/* 573:563 */       throw e;
/* 574:    */     }
/* 575:    */     catch (Exception e)
/* 576:    */     {
/* 577:565 */       throw new ZipException(e);
/* 578:    */     }
/* 579:    */   }
/* 580:    */   
/* 581:    */   private void updateSplitZip64EndCentralDirLocator(ZipModel zipModel, ArrayList fileSizeList)
/* 582:    */     throws ZipException
/* 583:    */   {
/* 584:570 */     if (zipModel == null) {
/* 585:571 */       throw new ZipException("zip model is null, cannot update split Zip64 end of central directory locator");
/* 586:    */     }
/* 587:574 */     if (zipModel.getZip64EndCentralDirLocator() == null) {
/* 588:575 */       return;
/* 589:    */     }
/* 590:578 */     zipModel.getZip64EndCentralDirLocator().setNoOfDiskStartOfZip64EndOfCentralDirRec(0);
/* 591:579 */     long offsetZip64EndCentralDirRec = 0L;
/* 592:581 */     for (int i = 0; i < fileSizeList.size(); i++) {
/* 593:582 */       offsetZip64EndCentralDirRec += ((Long)fileSizeList.get(i)).longValue();
/* 594:    */     }
/* 595:584 */     zipModel.getZip64EndCentralDirLocator().setOffsetZip64EndOfCentralDirRec(zipModel
/* 596:585 */       .getZip64EndCentralDirLocator().getOffsetZip64EndOfCentralDirRec() + offsetZip64EndCentralDirRec);
/* 597:    */     
/* 598:587 */     zipModel.getZip64EndCentralDirLocator().setTotNumberOfDiscs(1);
/* 599:    */   }
/* 600:    */   
/* 601:    */   private void updateSplitZip64EndCentralDirRec(ZipModel zipModel, ArrayList fileSizeList)
/* 602:    */     throws ZipException
/* 603:    */   {
/* 604:591 */     if (zipModel == null) {
/* 605:592 */       throw new ZipException("zip model is null, cannot update split Zip64 end of central directory record");
/* 606:    */     }
/* 607:595 */     if (zipModel.getZip64EndCentralDirRecord() == null) {
/* 608:596 */       return;
/* 609:    */     }
/* 610:599 */     zipModel.getZip64EndCentralDirRecord().setNoOfThisDisk(0);
/* 611:600 */     zipModel.getZip64EndCentralDirRecord().setNoOfThisDiskStartOfCentralDir(0);
/* 612:601 */     zipModel.getZip64EndCentralDirRecord().setTotNoOfEntriesInCentralDirOnThisDisk(zipModel
/* 613:602 */       .getEndCentralDirRecord().getTotNoOfEntriesInCentralDir());
/* 614:    */     
/* 615:604 */     long offsetStartCenDirWRTStartDiskNo = 0L;
/* 616:606 */     for (int i = 0; i < fileSizeList.size(); i++) {
/* 617:607 */       offsetStartCenDirWRTStartDiskNo += ((Long)fileSizeList.get(i)).longValue();
/* 618:    */     }
/* 619:610 */     zipModel.getZip64EndCentralDirRecord().setOffsetStartCenDirWRTStartDiskNo(zipModel
/* 620:611 */       .getZip64EndCentralDirRecord().getOffsetStartCenDirWRTStartDiskNo() + offsetStartCenDirWRTStartDiskNo);
/* 621:    */   }
/* 622:    */   
/* 623:    */   public void setComment(ZipModel zipModel, String comment)
/* 624:    */     throws ZipException
/* 625:    */   {
/* 626:616 */     if (comment == null) {
/* 627:617 */       throw new ZipException("comment is null, cannot update Zip file with comment");
/* 628:    */     }
/* 629:620 */     if (zipModel == null) {
/* 630:621 */       throw new ZipException("zipModel is null, cannot update Zip file with comment");
/* 631:    */     }
/* 632:624 */     String encodedComment = comment;
/* 633:625 */     byte[] commentBytes = comment.getBytes();
/* 634:626 */     int commentLength = comment.length();
/* 635:628 */     if (Zip4jUtil.isSupportedCharset("windows-1254")) {
/* 636:    */       try
/* 637:    */       {
/* 638:630 */         encodedComment = new String(comment.getBytes("windows-1254"), "windows-1254");
/* 639:631 */         commentBytes = encodedComment.getBytes("windows-1254");
/* 640:632 */         commentLength = encodedComment.length();
/* 641:    */       }
/* 642:    */       catch (UnsupportedEncodingException e)
/* 643:    */       {
/* 644:634 */         encodedComment = comment;
/* 645:635 */         commentBytes = comment.getBytes();
/* 646:636 */         commentLength = comment.length();
/* 647:    */       }
/* 648:    */     }
/* 649:640 */     if (commentLength > 65535) {
/* 650:641 */       throw new ZipException("comment length exceeds maximum length");
/* 651:    */     }
/* 652:644 */     zipModel.getEndCentralDirRecord().setComment(encodedComment);
/* 653:645 */     zipModel.getEndCentralDirRecord().setCommentBytes(commentBytes);
/* 654:646 */     zipModel.getEndCentralDirRecord().setCommentLength(commentLength);
/* 655:    */     
/* 656:648 */     SplitOutputStream outputStream = null;
/* 657:    */     try
/* 658:    */     {
/* 659:651 */       HeaderWriter headerWriter = new HeaderWriter();
/* 660:652 */       outputStream = new SplitOutputStream(zipModel.getZipFile());
/* 661:654 */       if (zipModel.isZip64Format()) {
/* 662:655 */         outputStream.seek(zipModel.getZip64EndCentralDirRecord().getOffsetStartCenDirWRTStartDiskNo());
/* 663:    */       } else {
/* 664:657 */         outputStream.seek(zipModel.getEndCentralDirRecord().getOffsetOfStartOfCentralDir());
/* 665:    */       }
/* 666:660 */       headerWriter.finalizeZipFileWithoutValidations(zipModel, outputStream); return;
/* 667:    */     }
/* 668:    */     catch (FileNotFoundException e)
/* 669:    */     {
/* 670:662 */       throw new ZipException(e);
/* 671:    */     }
/* 672:    */     catch (IOException e)
/* 673:    */     {
/* 674:664 */       throw new ZipException(e);
/* 675:    */     }
/* 676:    */     finally
/* 677:    */     {
/* 678:666 */       if (outputStream != null) {
/* 679:    */         try
/* 680:    */         {
/* 681:668 */           outputStream.close();
/* 682:    */         }
/* 683:    */         catch (IOException localIOException2) {}
/* 684:    */       }
/* 685:    */     }
/* 686:    */   }
/* 687:    */   
/* 688:    */   public void initProgressMonitorForRemoveOp(ZipModel zipModel, FileHeader fileHeader, ProgressMonitor progressMonitor)
/* 689:    */     throws ZipException
/* 690:    */   {
/* 691:678 */     if ((zipModel == null) || (fileHeader == null) || (progressMonitor == null)) {
/* 692:679 */       throw new ZipException("one of the input parameters is null, cannot calculate total work");
/* 693:    */     }
/* 694:682 */     progressMonitor.setCurrentOperation(2);
/* 695:683 */     progressMonitor.setFileName(fileHeader.getFileName());
/* 696:684 */     progressMonitor.setTotalWork(calculateTotalWorkForRemoveOp(zipModel, fileHeader));
/* 697:685 */     progressMonitor.setState(1);
/* 698:    */   }
/* 699:    */   
/* 700:    */   private long calculateTotalWorkForRemoveOp(ZipModel zipModel, FileHeader fileHeader)
/* 701:    */     throws ZipException
/* 702:    */   {
/* 703:689 */     return Zip4jUtil.getFileLengh(new File(zipModel.getZipFile())) - fileHeader.getCompressedSize();
/* 704:    */   }
/* 705:    */   
/* 706:    */   public void initProgressMonitorForMergeOp(ZipModel zipModel, ProgressMonitor progressMonitor)
/* 707:    */     throws ZipException
/* 708:    */   {
/* 709:693 */     if (zipModel == null) {
/* 710:694 */       throw new ZipException("zip model is null, cannot calculate total work for merge op");
/* 711:    */     }
/* 712:697 */     progressMonitor.setCurrentOperation(4);
/* 713:698 */     progressMonitor.setFileName(zipModel.getZipFile());
/* 714:699 */     progressMonitor.setTotalWork(calculateTotalWorkForMergeOp(zipModel));
/* 715:700 */     progressMonitor.setState(1);
/* 716:    */   }
/* 717:    */   
/* 718:    */   private long calculateTotalWorkForMergeOp(ZipModel zipModel)
/* 719:    */     throws ZipException
/* 720:    */   {
/* 721:704 */     long totSize = 0L;
/* 722:705 */     if (zipModel.isSplitArchive())
/* 723:    */     {
/* 724:706 */       int totNoOfSplitFiles = zipModel.getEndCentralDirRecord().getNoOfThisDisk();
/* 725:707 */       String partFile = null;
/* 726:708 */       String curZipFile = zipModel.getZipFile();
/* 727:709 */       int partNumber = 0;
/* 728:710 */       for (int i = 0; i <= totNoOfSplitFiles; i++)
/* 729:    */       {
/* 730:711 */         if (partNumber == zipModel.getEndCentralDirRecord().getNoOfThisDisk()) {
/* 731:712 */           partFile = zipModel.getZipFile();
/* 732:714 */         } else if (partNumber >= 9) {
/* 733:715 */           partFile = curZipFile.substring(0, curZipFile.lastIndexOf(".")) + ".z" + (partNumber + 1);
/* 734:    */         } else {
/* 735:717 */           partFile = curZipFile.substring(0, curZipFile.lastIndexOf(".")) + ".z0" + (partNumber + 1);
/* 736:    */         }
/* 737:721 */         totSize += Zip4jUtil.getFileLengh(new File(partFile));
/* 738:    */       }
/* 739:    */     }
/* 740:725 */     return totSize;
/* 741:    */   }
/* 742:    */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.util.ArchiveMaintainer
 * JD-Core Version:    0.7.0.1
 */