/*  1:   */ package net.lingala.zip4j.util;
/*  2:   */ 
/*  3:   */ import java.io.File;
/*  4:   */ import java.io.FileInputStream;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.io.InputStream;
/*  7:   */ import java.util.zip.CRC32;
/*  8:   */ import net.lingala.zip4j.exception.ZipException;
/*  9:   */ import net.lingala.zip4j.progress.ProgressMonitor;
/* 10:   */ 
/* 11:   */ public class CRCUtil
/* 12:   */ {
/* 13:   */   private static final int BUF_SIZE = 16384;
/* 14:   */   
/* 15:   */   public static long computeFileCRC(String inputFile)
/* 16:   */     throws ZipException
/* 17:   */   {
/* 18:33 */     return computeFileCRC(inputFile, null);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public static long computeFileCRC(String inputFile, ProgressMonitor progressMonitor)
/* 22:   */     throws ZipException
/* 23:   */   {
/* 24:44 */     if (!Zip4jUtil.isStringNotNullAndNotEmpty(inputFile)) {
/* 25:45 */       throw new ZipException("input file is null or empty, cannot calculate CRC for the file");
/* 26:   */     }
/* 27:47 */     InputStream inputStream = null;
/* 28:   */     try
/* 29:   */     {
/* 30:49 */       Zip4jUtil.checkFileReadAccess(inputFile);
/* 31:   */       
/* 32:51 */       inputStream = new FileInputStream(new File(inputFile));
/* 33:   */       
/* 34:53 */       byte[] buff = new byte[16384];
/* 35:54 */       int readLen = -2;
/* 36:55 */       CRC32 crc32 = new CRC32();
/* 37:   */       long l;
/* 38:57 */       while ((readLen = inputStream.read(buff)) != -1)
/* 39:   */       {
/* 40:58 */         crc32.update(buff, 0, readLen);
/* 41:59 */         if (progressMonitor != null)
/* 42:   */         {
/* 43:60 */           progressMonitor.updateWorkCompleted(readLen);
/* 44:61 */           if (progressMonitor.isCancelAllTasks())
/* 45:   */           {
/* 46:62 */             progressMonitor.setResult(3);
/* 47:63 */             progressMonitor.setState(0);
/* 48:64 */             return 0L;
/* 49:   */           }
/* 50:   */         }
/* 51:   */       }
/* 52:69 */       return crc32.getValue();
/* 53:   */     }
/* 54:   */     catch (IOException e)
/* 55:   */     {
/* 56:71 */       throw new ZipException(e);
/* 57:   */     }
/* 58:   */     catch (Exception e)
/* 59:   */     {
/* 60:73 */       throw new ZipException(e);
/* 61:   */     }
/* 62:   */     finally
/* 63:   */     {
/* 64:75 */       if (inputStream != null) {
/* 65:   */         try
/* 66:   */         {
/* 67:77 */           inputStream.close();
/* 68:   */         }
/* 69:   */         catch (IOException e)
/* 70:   */         {
/* 71:79 */           throw new ZipException("error while closing the file after calculating crc");
/* 72:   */         }
/* 73:   */       }
/* 74:   */     }
/* 75:   */   }
/* 76:   */ }


/* Location:           D:\任务\口袋妖怪简体发布\安卓\安卓\PokeDeploymentToolFX.jar
 * Qualified Name:     net.lingala.zip4j.util.CRCUtil
 * JD-Core Version:    0.7.0.1
 */